package com.aether.assistant.data

data class MemoryEntry(
    val id: Long,
    val content: String,
    val createdAt: Long
)

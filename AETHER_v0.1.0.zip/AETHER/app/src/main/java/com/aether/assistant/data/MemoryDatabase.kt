package com.aether.assistant.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Local-only storage. No network permission or remote sync is used in this first release. */
class MemoryDatabase(context: Context) : SQLiteOpenHelper(
    context.applicationContext,
    DATABASE_NAME,
    null,
    DATABASE_VERSION
) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """CREATE TABLE $TABLE_ENTRIES (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_CONTENT TEXT NOT NULL,
                $COLUMN_CREATED_AT INTEGER NOT NULL
            )""".trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Schema migrations will be added here before changing the database structure.
    }

    suspend fun getEntries(): List<MemoryEntry> = withContext(Dispatchers.IO) {
        val entries = mutableListOf<MemoryEntry>()
        readableDatabase.query(
            TABLE_ENTRIES,
            arrayOf(COLUMN_ID, COLUMN_CONTENT, COLUMN_CREATED_AT),
            null,
            null,
            null,
            null,
            "$COLUMN_CREATED_AT DESC"
        ).use { cursor ->
            val idIndex = cursor.getColumnIndexOrThrow(COLUMN_ID)
            val contentIndex = cursor.getColumnIndexOrThrow(COLUMN_CONTENT)
            val createdAtIndex = cursor.getColumnIndexOrThrow(COLUMN_CREATED_AT)
            while (cursor.moveToNext()) {
                entries += MemoryEntry(
                    id = cursor.getLong(idIndex),
                    content = cursor.getString(contentIndex),
                    createdAt = cursor.getLong(createdAtIndex)
                )
            }
        }
        entries
    }

    suspend fun addEntry(content: String): Long = withContext(Dispatchers.IO) {
        val values = ContentValues().apply {
            put(COLUMN_CONTENT, content)
            put(COLUMN_CREATED_AT, System.currentTimeMillis())
        }
        writableDatabase.insertOrThrow(TABLE_ENTRIES, null, values)
    }

    suspend fun deleteEntry(id: Long): Boolean = withContext(Dispatchers.IO) {
        writableDatabase.delete(TABLE_ENTRIES, "$COLUMN_ID = ?", arrayOf(id.toString())) > 0
    }

    suspend fun clearAll(): Int = withContext(Dispatchers.IO) {
        writableDatabase.delete(TABLE_ENTRIES, null, null)
    }

    companion object {
        private const val DATABASE_NAME = "aether_memory.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_ENTRIES = "memory_entries"
        private const val COLUMN_ID = "id"
        private const val COLUMN_CONTENT = "content"
        private const val COLUMN_CREATED_AT = "created_at"
    }
}

package com.aether.assistant.data

import android.content.Context

class AetherRepository(context: Context) {
    private val memoryDatabase = MemoryDatabase(context)

    suspend fun memories(): List<MemoryEntry> = memoryDatabase.getEntries()

    suspend fun saveMemory(content: String): Long = memoryDatabase.addEntry(content)

    suspend fun deleteMemory(id: Long): Boolean = memoryDatabase.deleteEntry(id)

    suspend fun clearMemories(): Int = memoryDatabase.clearAll()

    fun close() = memoryDatabase.close()
}

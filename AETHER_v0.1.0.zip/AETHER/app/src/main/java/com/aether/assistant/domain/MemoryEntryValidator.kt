package com.aether.assistant.domain

object MemoryEntryValidator {
    const val MAX_LENGTH = 4_000

    fun normalize(input: String): String? {
        val normalized = input.trim()
        if (normalized.isEmpty() || normalized.length > MAX_LENGTH) return null
        return normalized
    }
}

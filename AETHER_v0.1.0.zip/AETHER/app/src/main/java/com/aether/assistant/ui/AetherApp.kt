package com.aether.assistant.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ArrowForward
import androidx.compose.material.icons.outlined.BookmarkBorder
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.HourglassEmpty
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.MicNone
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material.icons.outlined.Shield
import androidx.compose.material.icons.outlined.Storage
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardOptions
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.aether.assistant.data.AetherRepository
import com.aether.assistant.data.MemoryEntry
import com.aether.assistant.domain.CapabilityCatalog
import com.aether.assistant.domain.CapabilityState
import com.aether.assistant.domain.MemoryEntryValidator
import com.aether.assistant.ui.theme.AetherCyan
import com.aether.assistant.ui.theme.AetherGreen
import com.aether.assistant.ui.theme.AetherMuted
import com.aether.assistant.ui.theme.AetherSurface
import com.aether.assistant.ui.theme.AetherText
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

private enum class Destination(val label: String) {
    HOME("Accueil"), MODULES("Modules"), MEMORY("Mémoire"), SETTINGS("Réglages")
}

@Composable
fun AetherApp(repository: AetherRepository) {
    var destination by rememberSaveable { mutableStateOf(Destination.HOME) }
    var memories by remember { mutableStateOf<List<MemoryEntry>>(emptyList()) }
    var refreshMemory by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()

    LaunchedEffect(refreshMemory) {
        memories = repository.memories()
    }

    Scaffold(
        containerColor = Color(0xFF070C14),
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B1420), tonalElevation = 0.dp) {
                Destination.entries.forEach { item ->
                    val icon = when (item) {
                        Destination.HOME -> Icons.Outlined.Home
                        Destination.MODULES -> Icons.Outlined.Apps
                        Destination.MEMORY -> Icons.Outlined.BookmarkBorder
                        Destination.SETTINGS -> Icons.Outlined.Settings
                    }
                    NavigationBarItem(
                        selected = destination == item,
                        onClick = { destination = item },
                        icon = { Icon(icon, contentDescription = item.label) },
                        label = { Text(item.label, fontSize = 11.sp) },
                        alwaysShowLabel = true
                    )
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFF070C14))
        ) {
            TopIdentity()
            when (destination) {
                Destination.HOME -> HomeScreen(
                    memoryCount = memories.size,
                    onOpenModules = { destination = Destination.MODULES },
                    onOpenMemory = { destination = Destination.MEMORY }
                )
                Destination.MODULES -> ModulesScreen()
                Destination.MEMORY -> MemoryScreen(
                    memories = memories,
                    onSave = { value ->
                        val normalized = MemoryEntryValidator.normalize(value)
                        if (normalized != null) {
                            repository.saveMemory(normalized)
                            refreshMemory++
                            true
                        } else false
                    },
                    onDelete = { id ->
                        scope.launch {
                            repository.deleteMemory(id)
                            refreshMemory++
                        }
                    },
                    onClear = {
                        scope.launch {
                            repository.clearMemories()
                            refreshMemory++
                        }
                    }
                )
                Destination.SETTINGS -> SettingsScreen()
            }
        }
    }
}

@Composable
private fun TopIdentity() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 22.dp, end = 22.dp, top = 17.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(38.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFF102B3B)),
            contentAlignment = Alignment.Center
        ) {
            Text("A", color = AetherCyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.width(11.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(1.dp)) {
            Text("AETHER", color = AetherText, fontWeight = FontWeight.Bold, fontSize = 17.sp, letterSpacing = 2.4.sp)
            Text("PERSONAL INTELLIGENCE SYSTEM", color = AetherMuted, fontSize = 8.sp, letterSpacing = 1.15.sp)
        }
        Box(
            modifier = Modifier
                .clip(CircleShape)
                .background(Color(0xFF102A27))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
            Text("FOUNDATION", color = AetherGreen, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun HomeScreen(
    memoryCount: Int,
    onOpenModules: () -> Unit,
    onOpenMemory: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                Spacer(Modifier.height(5.dp))
                CoreOrb()
                Spacer(Modifier.height(4.dp))
                Text("SYSTÈME INITIALISÉ", color = AetherCyan, fontSize = 10.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(5.dp))
                Text("Le socle AETHER est prêt.", color = AetherText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Text("Les capacités intelligentes seront activées progressivement.", color = AetherMuted, fontSize = 12.sp)
            }
        }
        item {
            SectionLabel("ÉTAT DU SYSTÈME", "01 / CORE")
            Card(
                colors = CardDefaults.cardColors(containerColor = AetherSurface),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    StateLine("Stockage local", "Opérationnel", true)
                    StateLine("Catalogue des capacités", "Opérationnel", true)
                    StateLine("Moteur conversationnel", "À connecter", false)
                    StateLine("Activation vocale", "Phase 2", false)
                    StateLine("Intégrations Android", "À configurer", false)
                }
            }
        }
        item {
            SectionLabel("ACCÈS RAPIDE", "02 / SHORTCUTS")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickCard(
                    title = "Modules",
                    detail = "8 capacités prévues",
                    icon = Icons.Outlined.Apps,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenModules
                )
                QuickCard(
                    title = "Mémoire",
                    detail = "$memoryCount élément(s) sauvegardé(s)",
                    icon = Icons.Outlined.Storage,
                    modifier = Modifier.weight(1f),
                    onClick = onOpenMemory
                )
            }
        }
        item {
            SectionLabel("PROCHAINE ÉTAPE", "03 / ROADMAP")
            Card(
                colors = CardDefaults.cardColors(containerColor = Color(0xFF102638)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Outlined.MicNone, contentDescription = null, tint = AetherCyan, modifier = Modifier.size(30.dp))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("AETHER VOICE", color = AetherText, fontWeight = FontWeight.SemiBold)
                        Text("Préparer l'interaction vocale et le mot d'activation.", color = AetherMuted, fontSize = 12.sp)
                    }
                    Icon(Icons.Outlined.ArrowForward, contentDescription = null, tint = AetherCyan)
                }
            }
        }
        item {
            Text(
                "Version 0.1.0 · Socle local · Aucune écoute microphone dans cette version",
                color = AetherMuted,
                fontSize = 10.sp,
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun CoreOrb() {
    Canvas(Modifier.size(184.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.minDimension / 2f
        drawCircle(AetherCyan.copy(alpha = 0.045f), radius = radius * 0.92f, center = center)
        drawCircle(AetherCyan.copy(alpha = 0.13f), radius = radius * 0.77f, center = center, style = Stroke(width = 1.2.dp.toPx()))
        drawCircle(AetherCyan.copy(alpha = 0.28f), radius = radius * 0.60f, center = center, style = Stroke(width = 1.1.dp.toPx()))
        drawCircle(AetherCyan.copy(alpha = 0.16f), radius = radius * 0.42f, center = center)
        drawCircle(Color(0xFF102F42), radius = radius * 0.31f, center = center)
        drawCircle(AetherCyan, radius = radius * 0.10f, center = center)
        drawArc(
            color = AetherCyan.copy(alpha = 0.85f),
            startAngle = 214f,
            sweepAngle = 92f,
            useCenter = false,
            topLeft = Offset(center.x - radius * 0.83f, center.y - radius * 0.83f),
            size = androidx.compose.ui.geometry.Size(radius * 1.66f, radius * 1.66f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round)
        )
        drawLine(AetherCyan.copy(alpha = 0.30f), Offset(center.x - radius * 0.78f, center.y), Offset(center.x + radius * 0.78f, center.y), strokeWidth = 0.7.dp.toPx())
        drawLine(AetherCyan.copy(alpha = 0.30f), Offset(center.x, center.y - radius * 0.78f), Offset(center.x, center.y + radius * 0.78f), strokeWidth = 0.7.dp.toPx())
    }
}

@Composable
private fun SectionLabel(title: String, code: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        Text(title, color = AetherMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
        Spacer(Modifier.weight(1f))
        Text(code, color = Color(0xFF49677C), fontSize = 9.sp, letterSpacing = 1.sp)
    }
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun StateLine(label: String, status: String, active: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(if (active) AetherGreen else Color(0xFF8A9AAA)))
        Spacer(Modifier.width(10.dp))
        Text(label, color = AetherText, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(status, color = if (active) AetherGreen else AetherMuted, fontSize = 11.sp)
    }
}

@Composable
private fun QuickCard(
    title: String,
    detail: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = AetherSurface),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(icon, contentDescription = null, tint = AetherCyan, modifier = Modifier.size(22.dp))
            Text(title, color = AetherText, fontWeight = FontWeight.SemiBold)
            Text(detail, color = AetherMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun ModulesScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(11.dp)
    ) {
        item {
            Text("Capacités AETHER", color = AetherText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Une architecture modulaire conçue pour évoluer.", color = AetherMuted, fontSize = 12.sp)
            Spacer(Modifier.height(7.dp))
        }
        items(CapabilityCatalog.all, key = { it.id }) { capability ->
            CapabilityCard(capability)
        }
    }
}

@Composable
private fun CapabilityCard(capability: Capability) {
    val ready = capability.state == CapabilityState.FOUNDATION_READY
    Card(
        colors = CardDefaults.cardColors(containerColor = AetherSurface),
        shape = RoundedCornerShape(15.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(42.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF142A3B)),
                contentAlignment = Alignment.Center
            ) {
                Text(capability.name.take(1), color = AetherCyan, fontWeight = FontWeight.Bold, fontSize = 20.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(capability.name, color = AetherText, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.7.sp)
                Text(capability.subtitle, color = AetherCyan, fontSize = 11.sp)
                Text(capability.description, color = AetherMuted, fontSize = 11.sp, lineHeight = 15.sp)
            }
            Spacer(Modifier.width(7.dp))
            Icon(
                if (ready) Icons.Outlined.CheckCircle else Icons.Outlined.HourglassEmpty,
                contentDescription = null,
                tint = if (ready) AetherGreen else AetherMuted,
                modifier = Modifier.size(18.dp)
            )
        }
    }
}

@Composable
private fun MemoryScreen(
    memories: List<MemoryEntry>,
    onSave: suspend (String) -> Boolean,
    onDelete: (Long) -> Unit,
    onClear: () -> Unit
) {
    var draft by rememberSaveable { mutableStateOf("") }
    var feedback by rememberSaveable { mutableStateOf<String?>(null) }
    var isSaving by remember { mutableStateOf(false) }
    val saveScope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(9.dp))
        Text("Mémoire personnelle", color = AetherText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("Seuls les éléments que tu enregistres sont conservés.", color = AetherMuted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Card(colors = CardDefaults.cardColors(containerColor = AetherSurface), shape = RoundedCornerShape(17.dp)) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Nouvelle mémoire", color = AetherText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                BasicTextField(
                    value = draft,
                    onValueChange = { draft = it.take(MemoryEntryValidator.MAX_LENGTH + 1) },
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(11.dp)).background(Color(0xFF0A121E)).padding(12.dp),
                    textStyle = MaterialTheme.typography.bodyMedium.copy(color = AetherText),
                    minLines = 3,
                    maxLines = 5,
                    keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences),
                    decorationBox = { inner ->
                        Box {
                            if (draft.isEmpty()) Text("Écris une information à conserver…", color = AetherMuted, fontSize = 13.sp)
                            inner()
                        }
                    }
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("${draft.length}/${MemoryEntryValidator.MAX_LENGTH}", color = AetherMuted, fontSize = 10.sp, modifier = Modifier.weight(1f))
                    Button(
                        onClick = {
                            saveScope.launch {
                                isSaving = true
                                try {
                                    val saved = onSave(draft)
                                    feedback = if (saved) "Enregistré localement." else "Ajoute un texte (4 000 caractères maximum)."
                                    if (saved) draft = ""
                                } catch (_: Exception) {
                                    feedback = "Impossible d'enregistrer pour le moment."
                                } finally {
                                    isSaving = false
                                }
                            }
                        },
                        enabled = draft.isNotBlank() && !isSaving,
                        colors = ButtonDefaults.buttonColors(containerColor = AetherCyan, contentColor = Color(0xFF00131B))
                    ) {
                        Icon(Icons.Outlined.Add, contentDescription = null, modifier = Modifier.size(17.dp))
                        Spacer(Modifier.width(5.dp))
                        Text(if (isSaving) "Enregistrement…" else "Enregistrer")
                    }
                }
                feedback?.let { Text(it, color = AetherCyan, fontSize = 11.sp) }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("ÉLÉMENTS ENREGISTRÉS · ${memories.size}", color = AetherMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp, modifier = Modifier.weight(1f))
            if (memories.isNotEmpty()) {
                TextButton(onClick = onClear) { Text("Tout effacer", color = Color(0xFFFF9B9B), fontSize = 11.sp) }
            }
        }
        if (memories.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(top = 35.dp)) {
                    Icon(Icons.Outlined.BookmarkBorder, contentDescription = null, tint = AetherMuted, modifier = Modifier.size(34.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("Ta mémoire est vide", color = AetherText, fontWeight = FontWeight.SemiBold)
                    Text("Les éléments enregistrés apparaîtront ici.", color = AetherMuted, fontSize = 11.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(memories, key = { it.id }) { entry ->
                    Card(colors = CardDefaults.cardColors(containerColor = AetherSurface), shape = RoundedCornerShape(14.dp)) {
                        Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(entry.content, color = AetherText, fontSize = 13.sp, lineHeight = 18.sp)
                                Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(entry.createdAt)), color = AetherMuted, fontSize = 10.sp)
                            }
                            TextButton(onClick = { onDelete(entry.id) }, contentPadding = PaddingValues(5.dp)) {
                                Icon(Icons.Outlined.DeleteOutline, contentDescription = "Supprimer", tint = Color(0xFFFF9B9B), modifier = Modifier.size(19.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen() {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(20.dp),
        verticalArrangement = Arrangement.spacedBy(13.dp)
    ) {
        item {
            Text("Réglages", color = AetherText, fontSize = 23.sp, fontWeight = FontWeight.Bold)
            Text("Confidentialité et informations techniques.", color = AetherMuted, fontSize = 12.sp)
        }
        item {
            SettingInfoCard(
                icon = Icons.Outlined.Lock,
                title = "Stockage local",
                detail = "Les mémoires sont enregistrées dans la base de données privée de l'application sur cet appareil."
            )
        }
        item {
            SettingInfoCard(
                icon = Icons.Outlined.MicNone,
                title = "Microphone",
                detail = "Aucune écoute microphone n'est active dans cette version. L'activation vocale sera développée dans une prochaine phase."
            )
        }
        item {
            SettingInfoCard(
                icon = Icons.Outlined.Shield,
                title = "Permissions",
                detail = "Aucune permission sensible n'est demandée dans cette première version. Les accès seront ajoutés au fur et à mesure des modules."
            )
        }
        item {
            SettingInfoCard(
                icon = Icons.Outlined.Info,
                title = "Version",
                detail = "AETHER 0.1.0 · Socle Android natif · Base locale et catalogue modulaire."
            )
        }
        item {
            Text("AETHER ne se connecte à aucun serveur dans cette livraison. Le moteur IA, la synchronisation et les intégrations sont encore à développer.", color = AetherMuted, fontSize = 11.sp, lineHeight = 16.sp)
        }
    }
}

@Composable
private fun SettingInfoCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    detail: String
) {
    Card(colors = CardDefaults.cardColors(containerColor = AetherSurface), shape = RoundedCornerShape(15.dp)) {
        Row(Modifier.padding(15.dp), verticalAlignment = Alignment.Top) {
            Icon(icon, contentDescription = null, tint = AetherCyan, modifier = Modifier.size(23.dp))
            Spacer(Modifier.width(12.dp))
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text(title, color = AetherText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                Text(detail, color = AetherMuted, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }
    }
}

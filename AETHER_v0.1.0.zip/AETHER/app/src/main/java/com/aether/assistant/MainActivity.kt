package com.aether.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.aether.assistant.data.AetherRepository
import com.aether.assistant.ui.AetherApp
import com.aether.assistant.ui.theme.AetherTheme

class MainActivity : ComponentActivity() {
    private lateinit var repository: AetherRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        repository = AetherRepository(applicationContext)
        setContent {
            AetherTheme {
                AetherApp(repository = repository)
            }
        }
    }

    override fun onDestroy() {
        if (::repository.isInitialized) repository.close()
        super.onDestroy()
    }
}

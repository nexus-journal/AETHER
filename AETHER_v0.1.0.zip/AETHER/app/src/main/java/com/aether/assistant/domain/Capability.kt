package com.aether.assistant.domain

enum class CapabilityState {
    FOUNDATION_READY,
    PLANNED
}

data class Capability(
    val id: String,
    val name: String,
    val subtitle: String,
    val description: String,
    val state: CapabilityState
)

object CapabilityCatalog {
    val all: List<Capability> = listOf(
        Capability(
            id = "memory",
            name = "MEMORY CORE",
            subtitle = "Mémoire personnelle",
            description = "Enregistrer et retrouver les informations que tu choisis de conserver.",
            state = CapabilityState.FOUNDATION_READY
        ),
        Capability(
            id = "morph",
            name = "MORPH STUDIO",
            subtitle = "Création d'outils",
            description = "Transformer un besoin en interface ou outil interactif adapté.",
            state = CapabilityState.PLANNED
        ),
        Capability(
            id = "autopilot",
            name = "AUTOPILOT",
            subtitle = "Missions complètes",
            description = "Organiser des tâches en étapes et préparer leur exécution sous contrôle.",
            state = CapabilityState.PLANNED
        ),
        Capability(
            id = "vision",
            name = "REALITY LENS",
            subtitle = "Perception visuelle",
            description = "Analyser les images, documents et éléments que tu partages.",
            state = CapabilityState.PLANNED
        ),
        Capability(
            id = "future-lab",
            name = "FUTURE LAB",
            subtitle = "Simulation",
            description = "Comparer plusieurs scénarios et rendre visibles leurs hypothèses.",
            state = CapabilityState.PLANNED
        ),
        Capability(
            id = "truth",
            name = "TRUTH ENGINE",
            subtitle = "Vérification",
            description = "Confronter les sources, relever les contradictions et signaler l'incertitude.",
            state = CapabilityState.PLANNED
        ),
        Capability(
            id = "context",
            name = "CONTEXT AWARE",
            subtitle = "Contexte personnel",
            description = "Relier les demandes aux projets et informations que tu autorises.",
            state = CapabilityState.PLANNED
        ),
        Capability(
            id = "local",
            name = "LOCAL CORE",
            subtitle = "Intelligence locale",
            description = "Faire fonctionner certaines capacités sans connexion Internet.",
            state = CapabilityState.PLANNED
        )
    )

    fun find(id: String): Capability? = all.firstOrNull { it.id == id }
}

package com.aether.assistant.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AetherBackground = Color(0xFF070C14)
val AetherSurface = Color(0xFF101A28)
val AetherSurfaceVariant = Color(0xFF172638)
val AetherCyan = Color(0xFF49D9F7)
val AetherText = Color(0xFFE7F2FA)
val AetherMuted = Color(0xFF91A6B8)
val AetherGreen = Color(0xFF70E0B0)

private val AetherColors = darkColorScheme(
    primary = AetherCyan,
    onPrimary = Color(0xFF00131B),
    secondary = Color(0xFF7EBCDA),
    background = AetherBackground,
    onBackground = AetherText,
    surface = AetherSurface,
    onSurface = AetherText,
    surfaceVariant = AetherSurfaceVariant,
    onSurfaceVariant = AetherMuted,
    outline = Color(0xFF294052)
)

@Composable
fun AetherTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = AetherColors, content = content)
}

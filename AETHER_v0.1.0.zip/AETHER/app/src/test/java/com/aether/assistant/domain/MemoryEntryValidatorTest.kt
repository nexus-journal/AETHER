package com.aether.assistant.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MemoryEntryValidatorTest {
    @Test
    fun trimsSurroundingWhitespace() {
        assertEquals("Une idée à garder", MemoryEntryValidator.normalize("  Une idée à garder  "))
    }

    @Test
    fun rejectsBlankEntries() {
        assertNull(MemoryEntryValidator.normalize("   \n  "))
    }

    @Test
    fun rejectsEntriesAboveMaximumLength() {
        assertNull(MemoryEntryValidator.normalize("a".repeat(MemoryEntryValidator.MAX_LENGTH + 1)))
    }

    @Test
    fun acceptsMaximumLength() {
        assertEquals(
            MemoryEntryValidator.MAX_LENGTH,
            MemoryEntryValidator.normalize("a".repeat(MemoryEntryValidator.MAX_LENGTH))?.length
        )
    }
}

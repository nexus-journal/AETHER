package com.aether.assistant.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class CapabilityCatalogTest {
    @Test
    fun exposesEightPlannedCoreCapabilities() {
        assertEquals(8, CapabilityCatalog.all.size)
    }

    @Test
    fun memoryIsTheOnlyFoundationCapabilityInThisDelivery() {
        val ready = CapabilityCatalog.all.filter { it.state == CapabilityState.FOUNDATION_READY }
        assertEquals(listOf("memory"), ready.map { it.id })
    }

    @Test
    fun everyCapabilityHasAStableUniqueId() {
        val ids = CapabilityCatalog.all.map { it.id }
        assertEquals(ids.size, ids.toSet().size)
        assertTrue(ids.all { it.isNotBlank() })
    }

    @Test
    fun canFindMorphModule() {
        assertNotNull(CapabilityCatalog.find("morph"))
    }
}

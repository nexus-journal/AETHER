# AETHER — Personal Intelligence System

**Première livraison : 0.1.0 — fondation Android native**

AETHER est un projet Android natif conçu pour évoluer vers un assistant personnel modulaire. Cette première livraison pose une base réelle et vérifiable : application native, interface sombre, catalogue de capacités, mémoire locale et compilation automatisée.

## État réel de cette version

### Fonctionnel
- Application Android native en Kotlin et Jetpack Compose.
- Interface AETHER avec navigation Accueil / Modules / Mémoire / Réglages.
- Catalogue de huit capacités avec leur état de développement.
- Mémoire personnelle stockée dans une base SQLite privée à l'application.
- Ajout et suppression d'éléments de mémoire.
- Validation des notes (texte non vide, maximum 4 000 caractères).
- Tests unitaires de la validation et du catalogue.
- Workflow GitHub Actions pour lancer les tests et produire un APK debug.

### Pas encore implémenté
- Modèle d'intelligence artificielle et conversation réelle.
- Activation vocale « AETHER » ou écoute en arrière-plan.
- Synthèse vocale et reconnaissance vocale.
- Accès aux notifications, contacts, calendrier, fichiers ou autres applications.
- MORPH, Autopilot, Vision, Truth Engine et Future Lab opérationnels.
- Synchronisation cloud ou compte utilisateur.

Aucune permission microphone, caméra, localisation ou accès aux notifications n'est demandée dans cette version. L'application ne dispose pas de permission Internet dans son manifeste. La mémoire n'est pas incluse dans les sauvegardes Android (`allowBackup=false`). Elle est dans l'espace privé de l'application, mais n'est pas chiffrée par AETHER dans cette première version : ne stocke pas encore d'informations extrêmement sensibles.

## Technologies
- Kotlin 2.4.21
- Android Gradle Plugin 8.13.2
- Gradle 8.13
- Jetpack Compose BOM 2026.09.00
- AndroidX Core 1.19.1
- Java 17
- `minSdk 28`, `targetSdk 36`, `compileSdk 36`

Les versions sont choisies pour rester dans les plages de compatibilité publiées. Voir les liens officiels dans `docs/ARCHITECTURE.md`.

## Générer l'APK avec GitHub Actions

1. Créer un dépôt GitHub vide nommé `AETHER`.
2. Importer le contenu de ce dossier à la racine du dépôt.
3. Ouvrir l'onglet **Actions** du dépôt.
4. Lancer **AETHER Android Build** avec **Run workflow**, ou pousser un commit sur `main`.
5. Lorsque le workflow est terminé, ouvrir son exécution et récupérer l'artefact `AETHER-debug-apk`.
6. Extraire le ZIP de l'artefact et installer `app-debug.apk` sur le téléphone.

Le workflow exécute les tests unitaires avant de compiler l'APK. Si une étape échoue, l'APK n'est pas présenté comme réussi.

## Identifiant Android

`com.aether.assistant.debug` pour les builds debug.

## Principe de développement

Une capacité n'est affichée comme prête que si elle existe réellement. Le catalogue décrit les fonctions prévues, sans prétendre que les modules IA ou vocaux sont déjà actifs.

# Feuille de route AETHER

## 0.1.0 — Fondation (livraison initiale)
- [x] Projet Android natif Kotlin / Compose
- [x] Identité visuelle AETHER et navigation
- [x] Catalogue des 8 capacités
- [x] Mémoire SQLite locale avec ajout / suppression
- [x] Règle de validation des mémoires
- [x] Tests unitaires de base
- [x] Compilation et tests via GitHub Actions

## 0.2.0 — Voice Foundation
- [ ] Étude et prototype `VoiceInteractionService`
- [ ] Vérification du statut d'assistant Android par défaut
- [ ] Microphone avec autorisation explicite et indicateur visible
- [ ] Reconnaissance vocale déclenchée manuellement
- [ ] Premier prototype de mot-clé local avec sherpa-onnx
- [ ] Tests écran verrouillé / arrière-plan / économies d'énergie sur appareil réel

## 0.3.0 — AETHER Core
- [ ] Interface conversationnelle fonctionnelle
- [ ] Passerelle vers un modèle IA local ou distant
- [ ] Outils internes appelables de manière structurée
- [ ] Mémoire interrogeable et gestion de préférences
- [ ] Journal d'exécution et confirmations avant actions sensibles

## 0.4.0 — MORPH et Autopilot
- [ ] Génération d'outils interactifs dans un environnement contrôlé
- [ ] Décomposition des missions en étapes
- [ ] Validation utilisateur avant les actions importantes
- [ ] Sauvegarde et reprise des missions

## 0.5.0 — Perception et intégrations
- [ ] Analyse d'images et documents partagés
- [ ] Intégrations Android ajoutées progressivement
- [ ] Registre de permissions par capacité
- [ ] Recherche et vérification de sources

## Règle de livraison
Chaque version doit compiler, passer les tests et décrire clairement les fonctions réellement disponibles. Une fonction planifiée ne doit jamais être présentée comme opérationnelle.

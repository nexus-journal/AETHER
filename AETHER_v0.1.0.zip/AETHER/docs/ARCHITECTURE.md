# Architecture AETHER — livraison 0.1.0

## Couches actuelles

- `ui/` : écrans Compose, navigation et identité visuelle.
- `domain/` : catalogue des capacités et règles de validation indépendantes d'Android.
- `data/` : modèle de mémoire, SQLite et façade de dépôt.
- `MainActivity.kt` : point d'entrée Android.

Cette première livraison reste volontairement dans un seul module Gradle (`:app`) pour simplifier l'import initial et la compilation distante. Les packages sont déjà séparés. Lorsque les interfaces internes seront stabilisées, les couches seront extraites en modules Gradle distincts (`:core:domain`, `:core:data`, `:core:capabilities`, `:feature:assistant`, etc.). Cela évite de figer trop tôt des frontières techniques encore en évolution.

## Données et confidentialité

- La mémoire est stockée dans `aether_memory.db`, dans le répertoire privé de l'application.
- Les opérations SQLite sont exécutées sur `Dispatchers.IO`.
- L'application n'a pas de permission Internet ni de permission micro/caméra/localisation dans cette livraison.
- Les sauvegardes Android sont désactivées pour éviter qu'une sauvegarde système copie les mémoires hors de l'appareil.
- La base SQLite n'est pas chiffrée par AETHER dans cette version ; elle bénéficie du bac à sable privé Android, mais ne doit pas recevoir de secrets sensibles.
- Les futures permissions devront être demandées au moment où une capacité en a réellement besoin.

## Architecture cible

1. **Android Host** : application native, cycle de vie, navigation, notifications et intégrations système autorisées.
2. **Capability Registry** : registre versionné des capacités, permissions requises et état de disponibilité.
3. **Agent Runtime** : orchestration de tâches, outils, reprise après erreur et journal d'exécution.
4. **Memory Layer** : données structurées, recherche locale, rétention et suppression contrôlées.
5. **Voice Layer** : activation, reconnaissance, synthèse et interface de session vocale.
6. **Model Gateway** : choix entre modèle local et fournisseur distant, sans secrets dans l'APK.
7. **MORPH Runtime** : génération d'interfaces/outils dans un espace isolé, avec permissions limitées.

## Ressources examinées

- sherpa-onnx : https://github.com/k2-fsa/sherpa-onnx — reconnaissance, synthèse et détection de mots-clés, notamment Android.
- Koog : https://github.com/JetBrains/koog — framework Kotlin pour agents et outils.
- Google AI Edge Gallery : https://github.com/google-ai-edge/gallery — expérimentation de modèles exécutés sur appareil.
- Now in Android : https://github.com/android/nowinandroid — référence d'architecture d'application Android Kotlin/Compose.

Ces projets sont des références à évaluer et intégrer module par module, pas des dépendances déjà intégrées à AETHER.

## Références de versions

- AGP et Gradle : https://developer.android.com/build/releases/about-agp
- Compatibilité Kotlin Gradle Plugin : https://kotlinlang.org/docs/gradle-configure-project.html
- Compose BOM : https://developer.android.com/develop/ui/compose/bom
- AndroidX releases : https://developer.android.com/jetpack/androidx/releases
- Restrictions de services au premier plan : https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start

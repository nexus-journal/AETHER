package com.aether.assistant

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.content.ContextCompat
import java.text.Normalizer
import java.util.Locale
import java.util.UUID

/**
 * Opt-in hands-free mode. It repeatedly uses Android's speech-recognition service to
 * detect the AETHER wake phrase. This is NOT a low-power DSP hotword detector.
 * The foreground notification is always visible while microphone capture is active.
 */
class VoiceWakeService : Service() {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var textToSpeech: TextToSpeech? = null
    private var ttsReady = false
    private var active = false
    private var awaitingCommand = false
    private var processing = false
    private var restartPosted = false
    private var wakeLock: PowerManager.WakeLock? = null
    private var pendingSpeech: String? = null

    private lateinit var memoryStore: MemoryStore
    private lateinit var taskStore: TaskStore
    private lateinit var conversationStore: ConversationStore
    private lateinit var aiSettingsStore: AiSettingsStore
    private lateinit var experienceStore: ExperiencePreferencesStore
    private val aiClient = AetherAiClient()

    override fun onCreate() {
        super.onCreate()
        memoryStore = MemoryStore(this)
        taskStore = TaskStore(this)
        conversationStore = ConversationStore(this)
        aiSettingsStore = AiSettingsStore(this)
        experienceStore = ExperiencePreferencesStore(this)
        createNotificationChannel()
        initializeSpeechOutput()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            updateRunningState(false)
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val notification = buildNotification("Initialisation de la reconnaissance vocale…")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }
        } catch (_: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }

        active = true
        updateRunningState(true)
        acquireWakeLock()
        createRecognizer()
        handler.postDelayed({ startListening() }, 500L)
        updateNotification("Écoute active · dis « ${WakePhrase.label(experienceStore.load().wakePhrase)} » pour commencer")
        return START_NOT_STICKY
    }

    private fun createRecognizer() {
        try {
            recognizer = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
            } else {
                SpeechRecognizer.createSpeechRecognizer(this)
            }
            recognizer?.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) {
                    if (active) updateNotification(if (awaitingCommand) "AETHER t'écoute · parle maintenant" else "Écoute active · dis « ${WakePhrase.label(experienceStore.load().wakePhrase)} »")
                }
                override fun onBeginningOfSpeech() = Unit
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = Unit
                override fun onEvent(eventType: Int, params: Bundle?) = Unit

                override fun onError(error: Int) {
                    if (!active) return
                    if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) {
                        updateNotification("Microphone indisponible · réactive l'autorisation dans AETHER")
                        stopSelf()
                        return
                    }
                    scheduleListening(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1400L else 750L)
                }

                override fun onResults(results: Bundle?) {
                    if (!active) return
                    val phrases = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    val spoken = phrases?.firstOrNull()?.trim().orEmpty()
                    if (spoken.isBlank()) {
                        scheduleListening(450L)
                        return
                    }
                    if (awaitingCommand) {
                        awaitingCommand = false
                        handleCommand(spoken)
                        return
                    }
                    val command = extractWakeCommand(spoken)
                    if (command != null) {
                        if (command.isBlank()) {
                            awaitingCommand = true
                            sayAndResume("Oui ? Je t'écoute.")
                        } else {
                            handleCommand(command)
                        }
                    } else {
                        scheduleListening(250L)
                    }
                }

                override fun onPartialResults(partialResults: Bundle?) = Unit
            })
        } catch (_: Exception) {
            updateNotification("Reconnaissance vocale indisponible")
            stopSelf()
        }
    }

    private fun startListening() {
        if (!active || processing || recognizer == null) return
        try {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "fr-FR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1100L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 750L)
            }
            recognizer?.startListening(intent)
        } catch (_: Exception) {
            scheduleListening(1600L)
        }
    }

    private fun scheduleListening(delayMs: Long) {
        if (!active || processing || restartPosted) return
        restartPosted = true
        handler.postDelayed({
            restartPosted = false
            startListening()
        }, delayMs)
    }

    private fun handleCommand(rawCommand: String) {
        val command = rawCommand.trim().take(1200)
        if (command.isBlank() || processing) {
            scheduleListening(350L)
            return
        }
        processing = true
        updateNotification("AETHER traite ta demande…")
        conversationStore.append("user", command)

        val local = runCatching { AssistantEngine.respond(command, this, memoryStore, taskStore) }
            .getOrElse { AssistantReply("Je n'ai pas réussi à traiter cette demande localement.") }
        if (local.handled) {
            val response = if (local.action != null) {
                "${local.text} Pour réaliser cette action, ouvre AETHER et formule-la dans l'interface ; elle te demandera une confirmation."
            } else local.text
            conversationStore.append("model", response)
            processing = false
            sayAndResume(response)
            return
        }

        val configuration = aiSettingsStore.load()
        if (!configuration.isReady) {
            val response = "Je peux traiter les commandes locales, mais le moteur conversationnel n'est pas configuré. Ouvre AETHER, puis Réglages et Intelligence pour configurer ton fournisseur IA."
            conversationStore.append("model", response)
            processing = false
            sayAndResume(response)
            return
        }

        val history = conversationStore.loadAll().takeLast(14)
        val memories = AetherAiClient.relevantMemories(command, memoryStore.loadAll())
        aiClient.ask(configuration, history, memories, taskStore.loadAll(), experienceStore.load().communicationStyle) { result ->
            if (!active) return@ask
            val answer = result.getOrElse { AssistantReply("Je n'ai pas réussi à joindre le moteur IA. Vérifie la connexion et le fournisseur configuré dans AETHER.") }
            val response = buildString {
                append(answer.text)
                if (answer.action != null) append(" Pour réaliser cette action, ouvre AETHER et formule-la dans l'interface ; elle te demandera une confirmation.")
                if (answer.planSteps.size in 2..8) append(" J'ai aussi préparé un plan de ${answer.planSteps.size} étapes. Tu peux le consulter dans l'application.")
            }.take(1800)
            conversationStore.append("model", response)
            processing = false
            sayAndResume(response)
        }
    }

    private fun initializeSpeechOutput() {
        textToSpeech = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true
                textToSpeech?.let { AetherVoice.apply(it, experienceStore.load()) }
                textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) = Unit
                    override fun onError(utteranceId: String?) {
                        handler.post {
                            processing = false
                            scheduleListening(500L)
                        }
                    }
                    override fun onDone(utteranceId: String?) {
                        handler.post {
                            processing = false
                            if (active) scheduleListening(350L)
                        }
                    }
                })
                pendingSpeech?.let { text ->
                    pendingSpeech = null
                    sayAndResume(text)
                }
            }
        }
    }

    private fun sayAndResume(text: String) {
        if (!active) return
        val speech = AetherVoice.cleanForSpeech(text)
        if (speech.isBlank()) {
            processing = false
            scheduleListening(350L)
            return
        }
        if (!ttsReady || textToSpeech == null) {
            pendingSpeech = speech
            updateNotification("AETHER · réponse prête")
            return
        }
        updateNotification("AETHER répond…")
        val utteranceId = "aether-${UUID.randomUUID()}"
        textToSpeech?.let { AetherVoice.apply(it, experienceStore.load()) }
        val result = textToSpeech?.speak(speech, TextToSpeech.QUEUE_FLUSH, Bundle(), utteranceId)
        if (result == TextToSpeech.ERROR) {
            processing = false
            scheduleListening(700L)
        }
    }

    private fun extractWakeCommand(spoken: String): String? {
        val words = spoken.trim().split(Regex("\\s+")).filter { it.isNotBlank() }
        if (words.isEmpty()) return null
        val first = normalize(words[0]).trim()
        val second = words.getOrNull(1)?.let { normalize(it).trim() }.orEmpty()
        val selected = WakePhrase.safe(experienceStore.load().wakePhrase)
        val wakeWordCount = when (selected) {
            WakePhrase.JARVIS -> when {
                first in setOf("hey", "he") && second == "jarvis" -> 2
                first == "jarvis" -> 1
                else -> return null
            }
            WakePhrase.HEY_AETHER -> when {
                first in setOf("hey", "he") && second in setOf("aether", "ether") -> 2
                else -> return null
            }
            else -> when {
                first in setOf("hey", "he") && second in setOf("aether", "ether") -> 2
                first in setOf("aether", "ether") -> 1
                else -> return null
            }
        }
        return words.drop(wakeWordCount).joinToString(" ").trim().trimStart(',', '.', ':', ';', '!', '?', ' ')
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.ROOT), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9 ]+"), " ")
        .replace(Regex("\\s+"), " ")
        .trim()

    private fun acquireWakeLock() {
        try {
            val power = getSystemService(Context.POWER_SERVICE) as PowerManager
            wakeLock = power.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "AETHER:HandsFreeListening").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (_: Exception) {
            wakeLock = null
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "AETHER · mode mains libres", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Indique lorsque le microphone est utilisé par le mode mains libres AETHER."
                setShowBadge(false)
            }
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(status: String): Notification {
        val stopIntent = Intent(this, VoiceWakeService::class.java).setAction(ACTION_STOP)
        val stopPendingIntent = PendingIntent.getService(
            this, 71, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this, 72, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("AETHER · mode mains libres")
            .setContentText(status)
            .setContentIntent(openPendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(Notification.CATEGORY_SERVICE)
            .addAction(android.R.drawable.ic_media_pause, "Arrêter", stopPendingIntent)
            .build()
    }

    private fun updateNotification(status: String) {
        if (!active) return
        runCatching {
            val notification = buildNotification(status)
            (getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(NOTIFICATION_ID, notification)
        }
    }

    private fun updateRunningState(running: Boolean) {
        getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).edit().putBoolean(KEY_RUNNING, running).apply()
    }

    override fun onDestroy() {
        active = false
        updateRunningState(false)
        handler.removeCallbacksAndMessages(null)
        runCatching { recognizer?.cancel() }
        runCatching { recognizer?.destroy() }
        recognizer = null
        runCatching { textToSpeech?.stop(); textToSpeech?.shutdown() }
        textToSpeech = null
        runCatching { wakeLock?.let { if (it.isHeld) it.release() } }
        wakeLock = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) stopForeground(STOP_FOREGROUND_REMOVE) else stopForeground(true)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_START = "com.aether.assistant.voice.START"
        const val ACTION_STOP = "com.aether.assistant.voice.STOP"
        private const val CHANNEL_ID = "aether_hands_free"
        private const val NOTIFICATION_ID = 3401
        private const val PREFS_NAME = "aether_voice_state"
        private const val KEY_RUNNING = "hands_free_running"

        fun isRunning(context: Context): Boolean = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getBoolean(KEY_RUNNING, false)
    }
}

package com.aether.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Small privacy-conscious audit trail. It deliberately avoids storing message bodies, phone numbers or URLs. */
data class ActionHistoryEntry(
    val id: String,
    val label: String,
    val status: String,
    val timestamp: Long
)

class ActionHistoryStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aether_action_history", Context.MODE_PRIVATE)

    @Synchronized
    fun loadAll(): List<ActionHistoryEntry> = try {
        val array = JSONArray(prefs.getString(KEY_ENTRIES, "[]") ?: "[]")
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val label = item.optString("label")
                val status = item.optString("status")
                if (id.isNotBlank() && label.isNotBlank() && status.isNotBlank()) {
                    add(ActionHistoryEntry(id, label.take(100), status.take(40), item.optLong("timestamp")))
                }
            }
        }.sortedByDescending { it.timestamp }
    } catch (_: Exception) { emptyList() }

    @Synchronized
    fun record(action: AssistantAction, status: String) {
        val label = when (action.kind.uppercase(Locale.ROOT)) {
            "WEB" -> "Recherche Web"
            "MAP" -> "Ouverture de carte"
            "ALARM" -> "Préparation d'une alarme"
            "TIMER" -> "Préparation d'un minuteur"
            "CALENDAR" -> "Préparation d'un événement"
            "SETTINGS" -> "Ouverture des paramètres"
            "SHARE" -> "Ouverture du partage"
            "URL" -> "Ouverture d'une adresse Web"
            "APP" -> "Ouverture de ${action.first.lowercase(Locale.ROOT).take(24)}"
            "TASK" -> "Ajout d'une tâche"
            "MEMORY" -> "Enregistrement d'un souvenir"
            "DIAL" -> "Ouverture du composeur"
            "SMS" -> "Préparation d'un SMS"
            else -> "Action Android"
        }
        val entries = (loadAll() + ActionHistoryEntry(UUID.randomUUID().toString(), label, status.take(40), System.currentTimeMillis())).takeLast(MAX_ENTRIES)
        save(entries)
    }

    @Synchronized
    fun clear() = prefs.edit().remove(KEY_ENTRIES).apply()

    private fun save(entries: List<ActionHistoryEntry>) {
        val array = JSONArray()
        entries.forEach { array.put(JSONObject()
            .put("id", it.id)
            .put("label", it.label)
            .put("status", it.status)
            .put("timestamp", it.timestamp)) }
        prefs.edit().putString(KEY_ENTRIES, array.toString()).apply()
    }

    companion object {
        private const val KEY_ENTRIES = "events"
        private const val MAX_ENTRIES = 80
        fun formattedTime(timestamp: Long): String = SimpleDateFormat("dd/MM · HH:mm", Locale.FRANCE).format(Date(timestamp))
    }
}

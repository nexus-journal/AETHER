package com.aether.assistant

import android.content.Context

object WakePhrase {
    const val AETHER = "AETHER"
    const val HEY_AETHER = "HEY_AETHER"
    const val JARVIS = "JARVIS"

    fun label(value: String): String = when (value) {
        HEY_AETHER -> "Hey AETHER"
        JARVIS -> "JARVIS"
        else -> "AETHER"
    }

    fun safe(value: String): String = when (value) {
        HEY_AETHER, JARVIS -> value
        else -> AETHER
    }
}

/** Préférences d'expérience non sensibles, stockées localement sur l'appareil. */
data class ExperiencePreferences(
    val hapticsEnabled: Boolean = true,
    val voiceRepliesEnabled: Boolean = false,
    val compactDashboard: Boolean = false,
    val fontScale: Float = 1.0f,
    val voiceProfile: String = AetherVoice.PROFILE_JARVIS,
    val speechRate: Float = AetherVoice.JARVIS_RATE,
    val speechPitch: Float = AetherVoice.JARVIS_PITCH,
    val communicationStyle: String = AetherVoice.STYLE_JARVIS,
    val wakePhrase: String = WakePhrase.AETHER
)

class ExperiencePreferencesStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aether_experience", Context.MODE_PRIVATE)

    fun load(): ExperiencePreferences = ExperiencePreferences(
        hapticsEnabled = prefs.getBoolean(KEY_HAPTICS, true),
        voiceRepliesEnabled = prefs.getBoolean(KEY_VOICE, false),
        compactDashboard = prefs.getBoolean(KEY_COMPACT, false),
        fontScale = prefs.getFloat(KEY_FONT_SCALE, 1.0f).coerceIn(0.85f, 1.20f),
        voiceProfile = prefs.getString(KEY_VOICE_PROFILE, AetherVoice.PROFILE_JARVIS) ?: AetherVoice.PROFILE_JARVIS,
        speechRate = prefs.getFloat(KEY_SPEECH_RATE, AetherVoice.JARVIS_RATE).coerceIn(0.75f, 1.25f),
        speechPitch = prefs.getFloat(KEY_SPEECH_PITCH, AetherVoice.JARVIS_PITCH).coerceIn(0.75f, 1.25f),
        communicationStyle = prefs.getString(KEY_STYLE, AetherVoice.STYLE_JARVIS) ?: AetherVoice.STYLE_JARVIS,
        wakePhrase = WakePhrase.safe(prefs.getString(KEY_WAKE_PHRASE, WakePhrase.AETHER) ?: WakePhrase.AETHER)
    )

    fun save(value: ExperiencePreferences) {
        prefs.edit()
            .putBoolean(KEY_HAPTICS, value.hapticsEnabled)
            .putBoolean(KEY_VOICE, value.voiceRepliesEnabled)
            .putBoolean(KEY_COMPACT, value.compactDashboard)
            .putFloat(KEY_FONT_SCALE, value.fontScale.coerceIn(0.85f, 1.20f))
            .putString(KEY_VOICE_PROFILE, value.voiceProfile)
            .putFloat(KEY_SPEECH_RATE, value.speechRate.coerceIn(0.75f, 1.25f))
            .putFloat(KEY_SPEECH_PITCH, value.speechPitch.coerceIn(0.75f, 1.25f))
            .putString(KEY_STYLE, value.communicationStyle)
            .putString(KEY_WAKE_PHRASE, WakePhrase.safe(value.wakePhrase))
            .apply()
    }

    companion object {
        private const val KEY_HAPTICS = "haptics_enabled"
        private const val KEY_VOICE = "voice_replies_enabled"
        private const val KEY_COMPACT = "compact_dashboard"
        private const val KEY_FONT_SCALE = "font_scale"
        private const val KEY_VOICE_PROFILE = "voice_profile"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_SPEECH_PITCH = "speech_pitch"
        private const val KEY_STYLE = "communication_style"
        private const val KEY_WAKE_PHRASE = "wake_phrase"
    }
}

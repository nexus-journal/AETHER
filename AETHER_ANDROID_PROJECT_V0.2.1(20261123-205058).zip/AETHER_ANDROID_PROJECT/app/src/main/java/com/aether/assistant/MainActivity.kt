package com.aether.assistant

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import android.speech.SpeechRecognizer
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF07111F)
private val Panel = Color(0xFF101F31)
private val PanelRaised = Color(0xFF152940)
private val Cyan = Color(0xFF62D9F5)
private val Muted = Color(0xFF91A7BC)
private val MainText = Color(0xFFEAF4FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan,
                onPrimary = Night,
                background = Night,
                surface = Panel,
                onSurface = MainText,
                secondary = Color(0xFF8BA9C7)
            )) { AetherApp() }
        }
    }
}

@Composable
private fun AetherApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val memoryStore = remember(context) { MemoryStore(context) }
    val taskStore = remember(context) { TaskStore(context) }
    val morphStore = remember(context) { MorphToolStore(context) }
    val routineStore = remember(context) { MorphRoutineStore(context) }
    val aiSettingsStore = remember(context) { AiSettingsStore(context) }
    val conversationStore = remember(context) { ConversationStore(context) }
    val actionHistoryStore = remember(context) { ActionHistoryStore(context) }
    val experienceStore = remember(context) { ExperiencePreferencesStore(context) }
    var experiencePreferences by remember(experienceStore) { mutableStateOf(experienceStore.load()) }
    val hapticFeedback = LocalHapticFeedback.current
    val baseDensity = LocalDensity.current
    var selectedTab by remember { mutableIntStateOf(0) }
    var pendingCommand by remember { mutableStateOf<String?>(null) }
    var pendingRoutine by remember { mutableStateOf<List<String>?>(null) }

    CompositionLocalProvider(
        LocalDensity provides Density(baseDensity.density, baseDensity.fontScale * experiencePreferences.fontScale)
    ) {
    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = MainText) {
                val labels = listOf("Accueil", "Assistant", "Mémoire", "MORPH", "Réglages")
                val marks = listOf("⌂", "◉", "▤", "✳", "⚙")
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = {
                            if (experiencePreferences.hapticsEnabled) hapticFeedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                            selectedTab = index
                        },
                        icon = { Text(marks[index], fontSize = 19.sp) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Cyan,
                            selectedTextColor = Cyan,
                            indicatorColor = PanelRaised,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
            0 -> HomeScreen(
                modifier = Modifier.padding(innerPadding),
                memoryCount = memoryStore.loadAll().size,
                taskCount = taskStore.loadAll().count { !it.done },
                memories = memoryStore.loadAll(),
                tasks = taskStore.loadAll(),
                tools = morphStore.loadAll(),
                routines = routineStore.loadAll(),
                compactDashboard = experiencePreferences.compactDashboard,
                onCommand = { pendingCommand = it; selectedTab = 1 },
                onRoutine = { pendingRoutine = it; pendingCommand = null; selectedTab = 1 }
            )
            1 -> AssistantScreen(
                modifier = Modifier.padding(innerPadding),
                memoryStore = memoryStore,
                taskStore = taskStore,
                aiSettingsStore = aiSettingsStore,
                conversationStore = conversationStore,
                routineStore = routineStore,
                actionHistoryStore = actionHistoryStore,
                experienceStore = experienceStore,
                prefillCommand = pendingCommand,
                onPrefillConsumed = { pendingCommand = null },
                prefillRoutine = pendingRoutine,
                onRoutineConsumed = { pendingRoutine = null },
                onExecuteAction = { executeAssistantAction(context, it) }
            )
            2 -> MemoryScreen(Modifier.padding(innerPadding), memoryStore)
            3 -> MorphScreen(Modifier.padding(innerPadding), morphStore, routineStore, onRunTool = { pendingCommand = it; selectedTab = 1 }, onRunRoutine = { pendingRoutine = it; pendingCommand = null; selectedTab = 1 })
            else -> SettingsScreen(
                modifier = Modifier.padding(innerPadding),
                aiSettingsStore = aiSettingsStore,
                conversationStore = conversationStore,
                memoryStore = memoryStore,
                taskStore = taskStore,
                morphStore = morphStore,
                routineStore = routineStore,
                actionHistoryStore = actionHistoryStore,
                experienceStore = experienceStore,
                onPreferencesChanged = { experiencePreferences = it }
            )
        }
    }
    }
}

private data class Feature(
    val name: String,
    val detail: String,
    val status: String,
    val mark: String
)

private val features = listOf(
    Feature("Agent local", "Commandes ciblées, briefing personnel et état batterie", "ACTIF", "A"),
    Feature("Mémoire centrale", "Souvenirs, favoris, recherche et contexte IA", "ACTIF", "M"),
    Feature("Tâches", "Liste locale, suivi et briefing des priorités", "ACTIF", "T"),
    Feature("MORPH Studio", "Compétences intégrées, outils personnels et routines guidées", "ACTIF", "✳"),
    Feature("Registre de compétences", "Modules préconfigurés reliés aux fonctions réelles d’AETHER", "ACTIF", "◇"),
    Feature("Recherche locale unifiée", "Retrouve les souvenirs, tâches, outils et routines depuis l'accueil", "ACTIF", "⌕"),
    Feature("Outils hors ligne", "Calculatrice sécurisée et conversions courantes sans clé API", "ACTIF", "∑"),
    Feature("Actions Android", "Web, cartes, agenda, appels, messages et applications", "ACTIF", "↗"),
    Feature("IA et planification", "Plans complexes de 2 à 8 étapes, lancés sous contrôle", "CONFIGURABLE", "◇"),
    Feature("Voice Studio", "Profils vocaux, aperçu, réglages TTS et personnalité JARVIS", "ACTIF", "♫"),
    Feature("Mot d’activation réglable", "Choisis AETHER, Hey AETHER ou JARVIS pour le mode mains libres", "ACTIF", "◉"),
    Feature("Minuteur Android", "Prépare un compte à rebours dans Horloge après confirmation", "ACTIF", "◷"),
    Feature("Diagnostic API", "Distingue les erreurs de clé, modèle, requête et quota", "ACTIF", "◇"),
    Feature("Routines guidées", "Workflows de 2 à 8 commandes avec validation étape par étape", "ACTIF", "↻"),
    Feature("Sauvegarde restaurable", "Export et restauration JSON des données personnelles, sans clé API", "ACTIF", "↗"),
    Feature("Préférences persistantes", "Retour haptique, réponses vocales et accueil compact", "ACTIF", "⚙"),
    Feature("Centre de confidentialité", "Effacement confirmé de toutes les données locales", "ACTIF", "⌑"),
    Feature("Mode mains libres", "Mot d’activation réglable, notification visible et réponse parlée", "BÊTA", "🎙")
)

private data class DashboardSearchResult(
    val id: String,
    val title: String,
    val detail: String,
    val command: String = "Mes statistiques",
    val routineSteps: List<String> = emptyList()
)

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    memoryCount: Int,
    taskCount: Int,
    memories: List<MemoryEntry>,
    tasks: List<TaskEntry>,
    tools: List<MorphTool>,
    routines: List<MorphRoutine>,
    compactDashboard: Boolean,
    onCommand: (String) -> Unit,
    onRoutine: (List<String>) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val searchResults = remember(searchQuery, memories, tasks, tools, routines) {
        val query = searchQuery.trim()
        if (query.length < 2) emptyList() else buildList {
            memories.filter { it.title.contains(query, true) || it.content.contains(query, true) || it.category.contains(query, true) }
                .take(4).forEach { add(DashboardSearchResult("memory-${it.id}", it.title, "Mémoire · ${it.category}", "Qu'est-ce que tu sais sur ${it.title}")) }
            tasks.filter { it.title.contains(query, true) }.take(4)
                .forEach { add(DashboardSearchResult("task-${it.id}", it.title, if (it.done) "Tâche terminée" else "Tâche en attente", "Mes tâches")) }
            tools.filter { it.name.contains(query, true) || it.command.contains(query, true) }.take(4)
                .forEach { add(DashboardSearchResult("tool-${it.id}", it.name, "Outil MORPH", it.command)) }
            routines.filter { it.name.contains(query, true) || it.steps.any { step -> step.contains(query, true) } }.take(4)
                .forEach { add(DashboardSearchResult("routine-${it.id}", it.name, "Routine MORPH · ${it.steps.size} étapes", routineSteps = it.steps)) }
        }
    }
    LazyColumn(modifier = modifier.fillMaxSize().padding(horizontal = 19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("AETHER", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("PERSONAL INTELLIGENCE", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Surface(color = PanelRaised, shape = RoundedCornerShape(50)) {
                    Text("V4.0.0", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(23.dp)) {
                Column(Modifier.fillMaxWidth().padding(19.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(Cyan, CircleShape))
                        Spacer(Modifier.width(9.dp))
                        Text("NOYAU LOCAL INITIALISÉ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    }
                    Spacer(Modifier.height(13.dp))
                    Text("Bonjour.", color = MainText, fontSize = 29.sp, fontWeight = FontWeight.SemiBold)
                    Text("Ton assistant personnel, sous ton contrôle.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(15.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Metric("MÉMOIRES", memoryCount.toString(), Modifier.weight(1f))
                        Metric("TÂCHES", taskCount.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(15.dp))
                    Button(onClick = { onCommand("aide") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night), shape = RoundedCornerShape(13.dp)) {
                        Text("Ouvrir AETHER Assistant", fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onCommand("Briefing du jour") }, modifier = Modifier.weight(1f)) { Text("Briefing", color = Cyan) }
                        OutlinedButton(onClick = { onCommand("Mes tâches") }, modifier = Modifier.weight(1f)) { Text("Mes tâches", color = Cyan) }
                    }
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SectionTitle("RECHERCHE UNIFIÉE", "Retrouve souvenirs, tâches, outils et routines sur cet appareil")
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it.take(80) },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    placeholder = { Text("Rechercher dans AETHER…", color = Muted) },
                    shape = RoundedCornerShape(14.dp)
                )
                if (searchQuery.trim().length >= 2 && searchResults.isEmpty()) {
                    Text("Aucun résultat local. Essaie un autre terme.", color = Muted, fontSize = 11.sp)
                }
            }
        }
        items(searchResults, key = { it.id }) { result ->
            Card(
                colors = CardDefaults.cardColors(containerColor = Panel),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth().clickable {
                    if (result.routineSteps.size >= 2) onRoutine(result.routineSteps) else onCommand(result.command)
                }
            ) {
                Row(Modifier.fillMaxWidth().padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(result.title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text(result.detail, color = Muted, fontSize = 10.sp)
                    }
                    Text("OUVRIR  ›", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        if (!compactDashboard) {
            item { SectionTitle("CAPACITÉS DU NOYAU", "Les fonctions réellement disponibles dans cette version") }
            items(features) { FeatureCard(it) }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(17.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("UNE IA QUI RESTE TRANSPARENTE", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("AETHER traite les commandes simples localement. Une IA distante peut enrichir les conversations et proposer des actions ; chaque action externe demande ta confirmation.", color = MainText, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = PanelRaised, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun FeatureCard(feature: Feature) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(40.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(feature.mark, color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(feature.name, color = MainText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(feature.detail, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Text(feature.status, color = if (feature.status == "ACTIF") Cyan else Color(0xFFFFC56B), fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingsScreen(
    modifier: Modifier = Modifier,
    aiSettingsStore: AiSettingsStore,
    conversationStore: ConversationStore,
    memoryStore: MemoryStore,
    taskStore: TaskStore,
    morphStore: MorphToolStore,
    routineStore: MorphRoutineStore,
    actionHistoryStore: ActionHistoryStore,
    experienceStore: ExperiencePreferencesStore,
    onPreferencesChanged: (ExperiencePreferences) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val history = remember(actionHistoryStore) { mutableStateListOf<ActionHistoryEntry>().apply { addAll(actionHistoryStore.loadAll().take(15)) } }
    var showClearHistory by remember { mutableStateOf(false) }
    var showClearActions by remember { mutableStateOf(false) }
    var showWipeAll by remember { mutableStateOf(false) }
    var pendingRestore by remember { mutableStateOf<String?>(null) }
    var restorePreview by remember { mutableStateOf<BackupImporter.Preview?>(null) }
    var showRestoreConfirmation by remember { mutableStateOf(false) }
    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            runCatching {
                val json = BackupExporter.createJson(memoryStore, taskStore, morphStore, routineStore, conversationStore)
                context.contentResolver.openOutputStream(uri)?.use { output -> output.write(json.toByteArray(Charsets.UTF_8)) }
                    ?: error("Impossible d'écrire le fichier.")
                Toast.makeText(context, "Sauvegarde AETHER enregistrée.", Toast.LENGTH_LONG).show()
            }.onFailure { Toast.makeText(context, it.message ?: "Échec de l'export.", Toast.LENGTH_LONG).show() }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            runCatching {
                val raw = context.contentResolver.openInputStream(uri)?.use { input ->
                    val output = java.io.ByteArrayOutputStream()
                    val buffer = ByteArray(8192)
                    var total: Int = 0
                    while (true) {
                        val readCount: Int = input.read(buffer)
                        if (readCount < 0) break
                        total += readCount
                        require(total <= 5_000_000) { "Le fichier dépasse la taille maximale de 5 Mo." }
                        output.write(buffer, 0, readCount)
                    }
                    output.toString(Charsets.UTF_8.name())
                } ?: error("Impossible de lire ce fichier.")
                val parsed = BackupImporter.parse(raw)
                pendingRestore = raw
                restorePreview = parsed.preview()
                showRestoreConfirmation = true
            }.onFailure { Toast.makeText(context, it.message ?: "Sauvegarde invalide.", Toast.LENGTH_LONG).show() }
        }
    }
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(19.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("RÉGLAGES", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("Contrôle et intelligence", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        AiSettingsCard(aiSettingsStore)
        ExperienceSettingsCard(experienceStore, onPreferencesChanged)
        VoiceStudioCard(experienceStore)
        SettingRow("Traitement hybride", "Les commandes simples restent locales. Les conversations libres utilisent le fournisseur IA configuré, lorsque la connexion est disponible.")
        SettingRow("Mémoire et contexte", "AETHER sélectionne quelques souvenirs pertinents et les tâches en attente pour enrichir le contexte envoyé au modèle. Tu conserves le contrôle de tes souvenirs.")
        SettingRow("Clé API", "La clé enregistrée est chiffrée avec Android Keystore sur cet appareil. Cela ne remplace pas un serveur privé : une clé utilisée par une application mobile peut toujours être exposée en cas de compromission de l'appareil.")
        SettingRow("Données envoyées", "Les messages récents et les souvenirs sélectionnés sont transmis au fournisseur IA. Ne partage pas d'informations sensibles. Les conditions et quotas dépendent du fournisseur choisi.")
        SettingRow("Actions Android", "Les actions proposées par l'IA sont limitées à une liste autorisée et doivent être confirmées. Les appels et SMS restent dans les applications Android ; rien n'est envoyé automatiquement.")
        HandsFreeControlCard(experienceStore)
        SettingRow("Voix", "Dictée et synthèse vocale Android. Le mode mains libres utilise le service de reconnaissance installé ; un modèle local est choisi lorsqu'il est disponible, sinon le fournisseur vocal Android peut traiter l'audio.")
        SettingRow("Agent et plans", "Pour les demandes complexes, le fournisseur IA peut proposer un plan de 2 à 8 étapes. Tu démarres chaque étape manuellement, et les actions externes gardent leur confirmation.")
        SettingRow("Journal d'actions", "AETHER conserve localement les actions confirmées ou annulées. Le journal masque volontairement le contenu des SMS, les numéros de téléphone et les URL complètes.")
        SettingRow("Sauvegarde complète", "Exporte ou restaure les souvenirs, tâches, conversations, outils et routines depuis un fichier JSON. La restauration remplace ces collections locales. Les clés API et le journal d'actions ne sont pas inclus.")
        SettingRow("Confidentialité", "La sauvegarde est traitée sur l'appareil. Vérifie le fichier avant de le partager : il peut contenir des notes personnelles et des échanges privés.")
        SettingRow("Compétences MORPH", "Le registre rassemble les fonctions locales, les actions Android à confirmer et les demandes qui nécessitent le fournisseur IA configuré. Les compétences sont des commandes sûres, pas du code téléchargé.")
        SettingRow("Version", "AETHER 4.0.0 — mots d’activation personnalisables, minuteur Android, diagnostic API détaillé et Voice Studio.")
        OutlinedButton(onClick = { showWipeAll = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Supprimer toutes les données locales", color = Color(0xFFFFB1A8))
        }
        if (showWipeAll) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showWipeAll = false },
                title = { Text("Tout supprimer sur cet appareil ?") },
                text = { Text("Cette opération efface définitivement les souvenirs, tâches, outils MORPH, routines, conversations et le journal d'actions locaux. Elle ne peut pas être annulée. La configuration et la clé API resteront enregistrées.") },
                confirmButton = {
                    Button(onClick = {
                        memoryStore.saveAll(emptyList())
                        taskStore.replaceAll(emptyList())
                        morphStore.replaceAll(emptyList())
                        routineStore.replaceAll(emptyList())
                        conversationStore.clear()
                        actionHistoryStore.clear()
                        history.clear()
                        showWipeAll = false
                        Toast.makeText(context, "Données locales supprimées.", Toast.LENGTH_LONG).show()
                    }, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB94C58))) { Text("Tout supprimer") }
                },
                dismissButton = { androidx.compose.material3.TextButton(onClick = { showWipeAll = false }) { Text("Annuler") } }
            )
        }
        Button(onClick = {
            val date = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.FRANCE).format(java.util.Date())
            exportLauncher.launch("AETHER-sauvegarde-$date.json")
        }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)) {
            Text("Exporter mes données locales")
        }
        OutlinedButton(onClick = { restoreLauncher.launch(arrayOf("application/json", "text/json", "text/plain")) }, modifier = Modifier.fillMaxWidth()) {
            Text("Restaurer depuis un fichier JSON", color = Cyan)
        }
        if (showRestoreConfirmation && restorePreview != null) {
            val preview = restorePreview!!
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showRestoreConfirmation = false; pendingRestore = null; restorePreview = null },
                title = { Text("Confirmer la restauration") },
                text = { Text("Cette sauvegarde contient : ${preview.memories} souvenir(s), ${preview.tasks} tâche(s), ${preview.morphTools} outil(s) MORPH, ${preview.morphRoutines} routine(s) et ${preview.conversations} message(s).\n\nCes collections remplaceront les données correspondantes sur cet appareil. La configuration IA et les clés API ne seront pas modifiées.") },
                confirmButton = {
                    Button(onClick = {
                        runCatching {
                            val raw = pendingRestore ?: error("Fichier de sauvegarde introuvable.")
                            val result = BackupImporter.restore(raw, memoryStore, taskStore, morphStore, routineStore, conversationStore)
                            Toast.makeText(context, "Restauration terminée : ${result.memories} souvenir(s), ${result.tasks} tâche(s).", Toast.LENGTH_LONG).show()
                        }.onFailure { Toast.makeText(context, it.message ?: "Échec de la restauration.", Toast.LENGTH_LONG).show() }
                        showRestoreConfirmation = false
                        pendingRestore = null
                        restorePreview = null
                    }) { Text("Restaurer") }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = { showRestoreConfirmation = false; pendingRestore = null; restorePreview = null }) { Text("Annuler") }
                }
            )
        }
        Text("JOURNAL DES ACTIONS", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
        if (history.isEmpty()) {
            SettingRow("Aucune action enregistrée", "Les actions confirmées ou annulées apparaîtront ici.")
        } else {
            history.forEach { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(13.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.label, color = MainText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Text(ActionHistoryStore.formattedTime(entry.timestamp), color = Muted, fontSize = 10.sp)
                        }
                        Text(entry.status, color = if (entry.status == "Annulée" || entry.status == "Échec de lancement") Color(0xFFFFB1A8) else Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        OutlinedButton(onClick = { showClearActions = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Effacer le journal d'actions", color = Muted)
        }
        OutlinedButton(onClick = { showClearHistory = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Effacer l'historique de conversation", color = Muted)
        }
        if (showClearActions) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showClearActions = false },
                title = { Text("Effacer le journal ?") },
                text = { Text("Les événements du journal d'actions seront supprimés. Les souvenirs, tâches et conversations resteront intacts.") },
                confirmButton = {
                    Button(onClick = { actionHistoryStore.clear(); history.clear(); showClearActions = false }) { Text("Effacer") }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = { showClearActions = false }) { Text("Annuler") }
                }
            )
        }
        if (showClearHistory) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showClearHistory = false },
                title = { Text("Effacer l'historique ?") },
                text = { Text("Cette action supprime les échanges enregistrés sur cet appareil. Les souvenirs et les tâches ne seront pas supprimés.") },
                confirmButton = {
                    Button(onClick = { conversationStore.clear(); showClearHistory = false }) {
                        Text("Effacer")
                    }
                },
                dismissButton = {
                    androidx.compose.material3.TextButton(onClick = { showClearHistory = false }) { Text("Annuler") }
                }
            )
        }
    }
}

@Composable
private fun ExperienceSettingsCard(
    store: ExperiencePreferencesStore,
    onChanged: (ExperiencePreferences) -> Unit
) {
    var settings by remember(store) { mutableStateOf(store.load()) }
    fun update(next: ExperiencePreferences) {
        settings = next
        store.save(next)
        onChanged(next)
    }
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("EXPÉRIENCE PERSONNELLE", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            PreferenceSwitch("Retour haptique", "Petite vibration lors de la navigation, si le téléphone le permet.", settings.hapticsEnabled) {
                update(settings.copy(hapticsEnabled = it))
            }
            PreferenceSwitch("Réponses vocales", "AETHER lit ses réponses dans l'onglet Assistant.", settings.voiceRepliesEnabled) {
                update(settings.copy(voiceRepliesEnabled = it))
            }
            PreferenceSwitch("Tableau de bord compact", "Masque la liste détaillée des capacités pour garder l'accueil plus épuré.", settings.compactDashboard) {
                update(settings.copy(compactDashboard = it))
            }
            Text("Taille du texte · ${((settings.fontScale * 100).toInt())} %", color = MainText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Slider(
                value = settings.fontScale,
                onValueChange = { update(settings.copy(fontScale = it)) },
                valueRange = 0.85f..1.20f,
                steps = 6
            )
        }
    }
}

@Composable
private fun PreferenceSwitch(title: String, detail: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = MainText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            Text(detail, color = Muted, fontSize = 10.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
private fun WakePhraseChoice(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) PanelRaised else Color.Transparent,
        shape = RoundedCornerShape(50),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(label, color = if (selected) Cyan else Muted, fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 8.dp))
    }
}

@Composable
private fun HandsFreeControlCard(store: ExperiencePreferencesStore) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isActive by remember { mutableStateOf(VoiceWakeService.isRunning(context)) }
    var selectedWakePhrase by remember(store) { mutableStateOf(store.load().wakePhrase) }
    val permissions = buildList {
        add(Manifest.permission.RECORD_AUDIO)
        if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { grants ->
        val audioGranted = grants[Manifest.permission.RECORD_AUDIO] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        val notificationsGranted = Build.VERSION.SDK_INT < 33 || grants[Manifest.permission.POST_NOTIFICATIONS] == true ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (audioGranted && notificationsGranted && SpeechRecognizer.isRecognitionAvailable(context)) {
            runCatching {
                val startIntent = Intent(context, VoiceWakeService::class.java).setAction(VoiceWakeService.ACTION_START)
                ContextCompat.startForegroundService(context, startIntent)
                isActive = true
                Toast.makeText(context, "Mode mains libres AETHER activé.", Toast.LENGTH_LONG).show()
            }.onFailure {
                isActive = VoiceWakeService.isRunning(context)
                Toast.makeText(context, "Impossible de démarrer le mode vocal : ${it.message ?: "vérifie les autorisations"}", Toast.LENGTH_LONG).show()
            }
        } else {
            Toast.makeText(context, "Le microphone et les notifications sont nécessaires pour rendre l'écoute visible et contrôlable.", Toast.LENGTH_LONG).show()
        }
    }

    Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(19.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.weight(1f)) {
                    Text("MODE MAINS LIBRES", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("Activation vocale « ${WakePhrase.label(selectedWakePhrase)} »", color = MainText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                Text(if (isActive) "ACTIF" else "ARRÊTÉ", color = if (isActive) Cyan else Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
            Text(
                "Active l'écoute ici, puis tu peux quitter l'application et verrouiller l'écran. Une notification permanente indique que le microphone est utilisé ; son bouton Arrêter coupe immédiatement l'écoute.",
                color = Muted, fontSize = 12.sp
            )
            Text("MOT D’ACTIVATION", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                WakePhraseChoice("AETHER", selectedWakePhrase == WakePhrase.AETHER) {
                    selectedWakePhrase = WakePhrase.AETHER
                    store.save(store.load().copy(wakePhrase = WakePhrase.AETHER))
                }
                WakePhraseChoice("Hey AETHER", selectedWakePhrase == WakePhrase.HEY_AETHER) {
                    selectedWakePhrase = WakePhrase.HEY_AETHER
                    store.save(store.load().copy(wakePhrase = WakePhrase.HEY_AETHER))
                }
                WakePhraseChoice("JARVIS", selectedWakePhrase == WakePhrase.JARVIS) {
                    selectedWakePhrase = WakePhrase.JARVIS
                    store.save(store.load().copy(wakePhrase = WakePhrase.JARVIS))
                }
            }
            Text("Le moteur vocal Android doit reconnaître le mot choisi. La précision dépend de la langue et du service vocal installé.", color = Muted, fontSize = 10.sp)
            Text(
                "Mode expérimental : la reconnaissance vocale Android tourne en boucle et peut consommer de la batterie. Le traitement local est utilisé lorsqu'il est disponible ; sinon le service vocal installé peut traiter l'audio. Le mode ne redémarre pas tout seul après un arrêt ou un redémarrage du téléphone.",
                color = Muted, fontSize = 11.sp
            )
            if (!isActive) {
                Button(
                    onClick = {
                        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                            Toast.makeText(context, "Aucun service de reconnaissance vocale n'est disponible sur cet appareil.", Toast.LENGTH_LONG).show()
                            return@Button
                        }
                        val missing = permissions.filter { ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED }
                        if (missing.isEmpty()) {
                            runCatching {
                                ContextCompat.startForegroundService(context, Intent(context, VoiceWakeService::class.java).setAction(VoiceWakeService.ACTION_START))
                                isActive = true
                                Toast.makeText(context, "Mode mains libres AETHER activé.", Toast.LENGTH_LONG).show()
                            }.onFailure { Toast.makeText(context, it.message ?: "Démarrage impossible.", Toast.LENGTH_LONG).show() }
                        } else permissionLauncher.launch(missing.toTypedArray())
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)
                ) { Text("Activer le mode mains libres", fontWeight = FontWeight.Bold) }
            } else {
                OutlinedButton(
                    onClick = {
                        context.stopService(Intent(context, VoiceWakeService::class.java))
                        isActive = false
                        Toast.makeText(context, "Écoute AETHER arrêtée.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Arrêter l'écoute", color = Color(0xFFFFB1A8)) }
            }
        }
    }
}

@Composable
private fun SettingRow(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(title, color = MainText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}

package com.aether.assistant

/**
 * Catalogue local des compétences intégrées.
 * Une compétence est un raccourci typé vers le moteur AETHER existant ; elle ne télécharge
 * ni n'exécute de code arbitraire. Les actions externes passent toujours par la confirmation
 * déjà présente dans AssistantScreen.
 */
enum class SkillMode(val label: String) {
    LOCAL("LOCAL"),
    CONFIRMATION("À CONFIRMER"),
    AI("IA CONFIGURABLE")
}

data class AssistantSkill(
    val id: String,
    val title: String,
    val description: String,
    val category: String,
    val command: String,
    val mode: SkillMode
)

object SkillRegistry {
    val all: List<AssistantSkill> = listOf(
        AssistantSkill(
            id = "daily-briefing", title = "Briefing personnel",
            description = "Date, tâches en attente, tâches terminées et état de ta mémoire.",
            category = "Organisation", command = "Briefing du jour", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "task-list", title = "Gestion des tâches",
            description = "Retrouve les tâches encore en attente.",
            category = "Organisation", command = "Mes tâches", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "quick-task", title = "Ajouter une tâche",
            description = "Démarre l’ajout d’une tâche et te demande son intitulé.",
            category = "Organisation", command = "Ajoute une tâche", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "memory-search", title = "Mémoire personnelle",
            description = "Retrouve les derniers souvenirs enregistrés dans la mémoire locale.",
            category = "Mémoire", command = "Recherche dans ma mémoire", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "device-status", title = "État du téléphone",
            description = "Consulte le niveau de batterie et l'état de charge disponibles.",
            category = "Appareil", command = "Quel est le niveau de batterie ?", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "clock", title = "Date et heure",
            description = "Obtient la date ou l'heure locale du téléphone.",
            category = "Appareil", command = "Quelle heure est-il ?", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "calculator", title = "Calculatrice",
            description = "Ouvre la calculatrice installée sur le téléphone.",
            category = "Appareil", command = "Ouvre la calculatrice", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "web-research", title = "Recherche Web",
            description = "Prépare une recherche Web ; vérifie les sources dans le navigateur.",
            category = "Recherche", command = "Cherche les dernières actualités scientifiques", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "navigation", title = "Navigation et cartes",
            description = "Ouvre une destination dans l'application de cartographie disponible.",
            category = "Déplacements", command = "Itinéraire vers la Tour Eiffel", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "alarm", title = "Préparer une alarme",
            description = "Prépare une alarme dans Horloge ; l'application te laisse vérifier avant validation.",
            category = "Organisation", command = "Mets une alarme à 7h30", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "timer", title = "Minuteur",
            description = "Prépare un minuteur dans l'application Horloge ; tu vérifies et démarres toi-même le compte à rebours.",
            category = "Organisation", command = "Lance un minuteur de 5 minutes", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "calendar", title = "Calendrier",
            description = "Ouvre le calendrier installé pour consulter ou créer un événement.",
            category = "Organisation", command = "Ouvre le calendrier", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "project-planner", title = "Planificateur intelligent",
            description = "Demande à l'IA configurée de structurer un projet en étapes vérifiables.",
            category = "Intelligence", command = "Aide-moi à organiser un projet en étapes claires", mode = SkillMode.AI
        ),
        AssistantSkill(
            id = "memory-library", title = "Bibliothèque de souvenirs",
            description = "Affiche les souvenirs récents enregistrés localement.",
            category = "Mémoire", command = "Mes souvenirs", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "memory-favorites", title = "Souvenirs favoris",
            description = "Retrouve les éléments marqués comme favoris dans la mémoire.",
            category = "Mémoire", command = "Mes favoris", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "personal-stats", title = "Statistiques personnelles",
            description = "Affiche un aperçu local des souvenirs et des tâches.",
            category = "Organisation", command = "Mes statistiques", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "open-camera", title = "Appareil photo",
            description = "Prépare l'ouverture de l'appareil photo du téléphone.",
            category = "Appareil", command = "Ouvre appareil photo", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "open-whatsapp", title = "WhatsApp",
            description = "Ouvre WhatsApp si l'application est installée.",
            category = "Communication", command = "Ouvre WhatsApp", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "open-messages", title = "Messages",
            description = "Ouvre l'application SMS sans envoyer de message.",
            category = "Communication", command = "Ouvre Messages", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "open-gmail", title = "Gmail",
            description = "Ouvre l'application de messagerie disponible.",
            category = "Communication", command = "Ouvre Gmail", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "open-files", title = "Gestionnaire de fichiers",
            description = "Ouvre le gestionnaire de fichiers installé sur le téléphone.",
            category = "Appareil", command = "Ouvre mes fichiers", mode = SkillMode.CONFIRMATION
        ),
        AssistantSkill(
            id = "personal-overview", title = "Bilan personnel",
            description = "Résume le volume des souvenirs et des tâches enregistrés localement.",
            category = "Organisation", command = "Statistiques personnelles", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "local-calculator", title = "Calculatrice locale",
            description = "Effectue les opérations de base et les calculs avec parenthèses sans connexion.",
            category = "Outils", command = "Calcule 125*(4+3)", mode = SkillMode.LOCAL
        ),
        AssistantSkill(
            id = "unit-converter", title = "Convertisseur d'unités",
            description = "Convertit les distances, masses, longueurs et températures courantes hors ligne.",
            category = "Outils", command = "Convertis 10 km en miles", mode = SkillMode.LOCAL
        )
    )

    fun promptSummary(): String = all.joinToString("\n") { skill ->
        "- ${skill.title} (${skill.mode.label}) : ${skill.description} Exemple de commande : « ${skill.command} »."
    }
}

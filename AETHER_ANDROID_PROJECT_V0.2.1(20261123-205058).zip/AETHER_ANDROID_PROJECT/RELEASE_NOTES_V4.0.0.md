# AETHER V4.0.0 — Intelligence & Voice Upgrade

## Nouveautés

- Mot d’activation réglable : AETHER, Hey AETHER ou JARVIS.
- Le service mains libres suit le mot choisi et conserve une notification de premier plan visible avec commande d’arrêt.
- Compétence Minuteur : AETHER prépare un compte à rebours dans l’application Horloge Android ; l’utilisateur vérifie et démarre lui-même le minuteur.
- Le modèle Groq prérempli est aligné sur `openai/gpt-oss-20b`.
- Diagnostics HTTP plus utiles : distinction des erreurs 400, 401/403, 404 et 429, et affichage des en-têtes de renouvellement lorsque le fournisseur les communique.
- Conservation des capacités précédentes : mémoire locale, tâches, historique, MORPH, routines guidées, plans IA, Voice Studio, sauvegarde/restauration, outils locaux et actions Android confirmées.

## Sécurité et limites

- Le microphone mains libres n’est jamais caché : activation volontaire, permission Android, notification persistante et arrêt manuel.
- Le service de reconnaissance vocale reste expérimental et peut consommer de la batterie ; la détection dépend du moteur vocal installé.
- Les actions externes demandent toujours une confirmation dans l’application. Le minuteur ouvre Horloge avec l’interface de validation, sans démarrer silencieusement le compte à rebours.
- Aucun code arbitraire ni module distant n’est exécuté par MORPH.
- Les appels API restent soumis aux modèles, quotas, conditions et éventuels coûts du fournisseur choisi.

## Version

- `versionCode`: 40
- `versionName`: 4.0.0
- Namespace : `com.aether.assistant`
- JDK 17 · compileSdk 36 · Gradle 8.13.2

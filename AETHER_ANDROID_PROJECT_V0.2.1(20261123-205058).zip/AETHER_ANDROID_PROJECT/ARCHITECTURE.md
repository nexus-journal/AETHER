# Architecture AETHER 4.0.0

## Couches

- **Interface Compose** : accueil, assistant, mémoire, MORPH et réglages.
- **Routage local** : `AssistantEngine` traite les commandes explicites, les souvenirs, les tâches, la date/heure, le briefing personnel et l'état de batterie.
- **Planificateur IA** : `AetherAiClient` peut renvoyer une proposition `plan` de 2 à 8 commandes. L'interface attend un déclenchement manuel pour chacune.
- **Exécution Android** : `executeAssistantAction` ne traite que les actions autorisées et est appelée après confirmation. Son résultat indique si Android a accepté le lancement de l'intention, sans prétendre que l'action est achevée dans l'application cible.
- **MORPH** : outils et routines stockés localement ; les plans IA peuvent devenir des routines.
- **Journal privé** : `ActionHistoryStore` conserve les actions confirmées ou annulées, sans corps de SMS, numéro, URL ou contenu privé complet.
- **Sauvegarde** : `BackupExporter` crée un JSON local (souvenirs, tâches, conversations, outils, routines). `BackupImporter` valide le format, la version et les limites de chaque collection avant de remplacer les collections importées. Les paramètres IA, secrets et journal d'actions sont exclus.
- **Secrets** : clé API chiffrée avec AES/GCM et Android Keystore.

## Séquence d'une demande

1. La commande est traitée localement si elle correspond à une capacité déterministe.
2. Le briefing personnel local synthétise la date/heure, les tâches et le volume de souvenirs sans appel réseau.
3. Sinon, si une clé est configurée, le fournisseur IA reçoit l'historique récent et une sélection de souvenirs.
4. Le modèle peut répondre, proposer une action typée ou proposer un plan de 2 à 8 étapes.
5. Les actions externes sont soumises à confirmation. Les étapes d'un plan ne sont envoyées à l'assistant qu'après appui de l'utilisateur.

## Restauration

1. L'utilisateur sélectionne un fichier JSON via le sélecteur Android.
2. Le fichier est limité à 5 Mo et analysé en mémoire.
3. `BackupImporter` vérifie le format `AETHER_LOCAL_BACKUP`, la version du schéma et les limites des collections.
4. L'interface affiche un aperçu et demande confirmation.
5. Les collections sauvegardées sont remplacées ; la configuration IA et les clés API ne sont jamais modifiées.

## Confidentialité et limites

- Les souvenirs, tâches, routines, outils, conversations et journal sont stockés dans les préférences privées de l'application.
- L'utilisation de l'IA transmet le message, des échanges récents et des souvenirs sélectionnés au fournisseur configuré.
- La sauvegarde est manuelle. Elle n'inclut pas les clés API. Les fichiers JSON peuvent contenir du contenu personnel et doivent être protégés.
- AETHER n'inclut pas de modèle local, de service cloud, de synchronisation, de surveillance permanente, d'exécution de code arbitraire ou de contrôle sans limites d'autres applications.


## Mode mains libres V3.0

`VoiceWakeService` est un service Android au premier plan de type `microphone`. L'utilisateur le démarre depuis Réglages après avoir accordé `RECORD_AUDIO` et, à partir d'Android 13, les notifications. Le service affiche une notification persistante avec une action Arrêter et utilise `SpeechRecognizer` par sessions répétées pour repérer le mot d’activation sélectionné (AETHER, Hey AETHER ou JARVIS). Il choisit le recognizer local lorsque le système en annonce un ; sinon le recognizer Android par défaut peut traiter l'audio.

Après activation, le service peut rester actif lorsque l'interface est quittée ou l'écran verrouillé, sous réserve des restrictions du fabricant et d'Android. Il utilise un `PARTIAL_WAKE_LOCK` pendant l'écoute, ce qui augmente la consommation électrique. Le mode ne démarre pas au boot et n'est pas caché. Les demandes sont enregistrées dans `ConversationStore`; les commandes locales passent par `AssistantEngine`; les demandes libres utilisent le fournisseur IA déjà configuré. Les actions externes ne sont jamais lancées depuis le service vocal : l'utilisateur doit ouvrir l'application et confirmer la proposition.

Cette version est un mode mains libres expérimental basé sur la reconnaissance vocale générale, pas un véritable détecteur matériel de mot-clé basse consommation. La précision et la disponibilité écran verrouillé dépendent du service de reconnaissance présent sur le téléphone.


## V3.2 — Recherche, outils locaux et préférences

- `HomeScreen` compose une recherche locale sur les collections mémoire, tâches, outils et routines. Les résultats déclenchent uniquement une commande connue ou une routine guidée.
- `SafeArithmeticParser` évalue une grammaire arithmétique limitée (nombres, parenthèses, addition, soustraction, multiplication, division) ; aucun code n'est exécuté.
- Le convertisseur traite une liste fixe d'unités courantes, sans réseau.
- `ExperiencePreferencesStore` conserve les réglages de retour haptique, de synthèse vocale et de densité du tableau de bord et de taille de texte dans les préférences privées de l'application.
- Le centre de confidentialité demande une confirmation explicite puis vide les collections locales choisies. Il conserve volontairement la configuration fournisseur et la clé API.


## V4.0 — Voice et minuterie

- `ExperiencePreferences.wakePhrase` mémorise l'un des trois mots d'activation pris en charge : `AETHER`, `HEY_AETHER` ou `JARVIS`.
- `VoiceWakeService` lit ce choix lorsqu'il analyse chaque résultat vocal. La capture du microphone reste volontaire, visible via une notification persistante et arrêtable depuis cette notification.
- `AssistantEngine` reconnaît les demandes de minuteur et prépare une action `TIMER` en secondes. `executeAssistantAction` ouvre `AlarmClock.ACTION_SET_TIMER` avec l'interface de l'application Horloge ; le démarrage du compte à rebours reste sous contrôle de l'utilisateur.
- `AetherAiClient` distingue les erreurs HTTP de clé, modèle, requête et quota. Les en-têtes `Retry-After` et `x-ratelimit-reset-*` sont présentés lorsqu'ils sont renvoyés par le fournisseur.

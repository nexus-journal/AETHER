# Architecture AETHER 2.0.0

## Couches

- **Interface Compose** : accueil, assistant, mémoire, MORPH et réglages.
- **Routage local** : `AssistantEngine` traite les commandes explicites, les souvenirs, les tâches, la date/heure, le briefing personnel et l'état de batterie.
- **Planificateur IA** : `AetherAiClient` peut renvoyer une proposition `plan` de 2 à 8 commandes. L'interface attend un déclenchement manuel pour chacune.
- **Exécution Android** : `executeAssistantAction` ne traite que les actions autorisées et est appelée après confirmation. Son résultat indique si Android a accepté le lancement de l'intention, sans prétendre que l'action est achevée dans l'application cible.
- **MORPH** : outils et routines stockés localement ; les plans IA peuvent devenir des routines.
- **Journal privé** : `ActionHistoryStore` conserve les actions confirmées ou annulées, sans corps de SMS, numéro, URL ou contenu privé complet.
- **Sauvegarde** : `BackupExporter` crée un JSON local (souvenirs, tâches, conversations, outils, routines). `BackupImporter` valide le format, la version et les limites de chaque collection avant de remplacer les collections importées. Les paramètres IA, secrets et journal d'actions sont exclus.
- **Secrets** : clé API chiffrée avec AES/GCM et Android Keystore.

## Séquence d'une demande

1. La commande est traitée localement si elle correspond à une capacité déterministe.
2. Le briefing personnel local synthétise la date/heure, les tâches et le volume de souvenirs sans appel réseau.
3. Sinon, si une clé est configurée, le fournisseur IA reçoit l'historique récent et une sélection de souvenirs.
4. Le modèle peut répondre, proposer une action typée ou proposer un plan de 2 à 8 étapes.
5. Les actions externes sont soumises à confirmation. Les étapes d'un plan ne sont envoyées à l'assistant qu'après appui de l'utilisateur.

## Restauration

1. L'utilisateur sélectionne un fichier JSON via le sélecteur Android.
2. Le fichier est limité à 5 Mo et analysé en mémoire.
3. `BackupImporter` vérifie le format `AETHER_LOCAL_BACKUP`, la version du schéma et les limites des collections.
4. L'interface affiche un aperçu et demande confirmation.
5. Les collections sauvegardées sont remplacées ; la configuration IA et les clés API ne sont jamais modifiées.

## Confidentialité et limites

- Les souvenirs, tâches, routines, outils, conversations et journal sont stockés dans les préférences privées de l'application.
- L'utilisation de l'IA transmet le message, des échanges récents et des souvenirs sélectionnés au fournisseur configuré.
- La sauvegarde est manuelle. Elle n'inclut pas les clés API. Les fichiers JSON peuvent contenir du contenu personnel et doivent être protégés.
- AETHER n'inclut pas de modèle local, de service cloud, de synchronisation, de surveillance permanente, d'exécution de code arbitraire ou de contrôle sans limites d'autres applications.

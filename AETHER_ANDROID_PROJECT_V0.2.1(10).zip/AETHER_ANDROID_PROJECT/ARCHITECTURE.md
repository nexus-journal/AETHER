# Architecture AETHER 1.5.0

## Couches

- **Interface Compose** : accueil, assistant, mémoire, MORPH et réglages.
- **Routage local** : `AssistantEngine` traite les commandes explicites, les souvenirs, les tâches, l'heure/date et l'état de batterie.
- **Planificateur IA** : `AetherAiClient` peut renvoyer une proposition `plan` de 2 à 8 commandes AETHER. L'interface attend un déclenchement manuel pour chacune.
- **Exécution Android** : `executeAssistantAction` ne traite que les actions autorisées et est appelée après confirmation. Son résultat booléen indique si Android a accepté le lancement de l'intention, sans prétendre que l'action est achevée dans l'application cible.
- **MORPH** : outils et routines stockés localement ; les plans IA peuvent devenir des routines.
- **Journal privé** : `ActionHistoryStore` conserve les actions confirmées ou annulées, sans corps de SMS, numéro, URL ou contenu privé complet.
- **Sauvegarde** : `BackupExporter` produit un JSON des données locales (souvenirs, tâches, conversations, outils, routines). Les clés API sont exclues.
- **Secrets** : clé API chiffrée avec AES/GCM et Android Keystore.

## Séquence d'une demande

1. La commande est traitée localement si elle correspond à une capacité déterministe.
2. Sinon, si une clé est configurée, le fournisseur IA reçoit l'historique récent et une sélection de souvenirs.
3. Le modèle peut répondre, proposer une action typée ou proposer un plan de 2 à 8 étapes.
4. Les actions externes sont soumises à confirmation. Les étapes d'un plan ne sont envoyées à l'assistant qu'après appui de l'utilisateur.

## Confidentialité et limites

- Les souvenirs, tâches, routines, outils, conversations et journal sont stockés dans les préférences privées de l'application.
- L'utilisation de l'IA transmet le message, des échanges récents et des souvenirs sélectionnés au fournisseur configuré.
- La sauvegarde est manuelle, partage son contenu via Android et exclut les clés API. L'import n'est pas fourni dans cette version.
- AETHER n'inclut pas de modèle local, de service cloud, de synchronisation, de surveillance permanente, d'exécution de code arbitraire ou de contrôle sans limites d'autres applications.

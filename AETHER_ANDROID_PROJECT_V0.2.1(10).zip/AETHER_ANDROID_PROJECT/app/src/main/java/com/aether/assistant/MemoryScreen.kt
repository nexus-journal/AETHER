package com.aether.assistant

import android.content.Intent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val MemoryCyan = Color(0xFF62D9F5)
private val MemoryPanel = Color(0xFF101F31)
private val MemoryRaised = Color(0xFF152940)
private val MemoryText = Color(0xFFEAF4FC)
private val MemoryMuted = Color(0xFF91A7BC)
private val MemoryBackground = Color(0xFF07111F)

@Composable
fun MemoryScreen(modifier: Modifier = Modifier, store: MemoryStore) {
    val context = LocalContext.current
    val entries = remember(store) { mutableStateListOf<MemoryEntry>().apply { addAll(store.loadAll()) } }
    var search by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Tout") }
    var showEditor by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<MemoryEntry?>(null) }
    var deletingEntry by remember { mutableStateOf<MemoryEntry?>(null) }
    var showImport by remember { mutableStateOf(false) }
    var importText by remember { mutableStateOf("") }
    var importError by remember { mutableStateOf("") }

    val categories = entries.map { it.category }.distinct().sorted()
    val filterChoices = listOf("Tout", "Favoris") + categories
    val filteredEntries = entries.filter { entry ->
        val needle = search.trim()
        (needle.isEmpty() || entry.title.contains(needle, true) || entry.content.contains(needle, true) || entry.category.contains(needle, true)) &&
            (filter == "Tout" || (filter == "Favoris" && entry.favorite) || entry.category == filter)
    }.sortedWith(compareByDescending<MemoryEntry> { it.favorite }.thenByDescending { it.updatedAt })

    Column(modifier = modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Column {
            Text("MÉMOIRE CENTRALE · V0.4", color = MemoryCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Spacer(Modifier.height(5.dp))
            Text("Tout ce qui mérite d’être retenu.", color = MemoryText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Text("Une mémoire personnelle, enregistrée sur cet appareil.", color = MemoryMuted, fontSize = 12.sp)
        }
        Card(colors = CardDefaults.cardColors(containerColor = MemoryPanel), shape = RoundedCornerShape(16.dp)) {
            Row(Modifier.fillMaxWidth().padding(15.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("ÉLÉMENTS EN MÉMOIRE", color = MemoryMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(entries.size.toString(), color = MemoryText, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                    Text("${entries.count { it.favorite }} favori(s)", color = MemoryMuted, fontSize = 11.sp)
                }
                Text("LOCAL  •  HORS LIGNE", color = MemoryCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            placeholder = { Text("Rechercher dans la mémoire…", color = MemoryMuted) }, label = { Text("Recherche") })
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { editingEntry = null; showEditor = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = MemoryCyan, contentColor = MemoryBackground), shape = RoundedCornerShape(14.dp)) { Text("+ Ajouter", fontWeight = FontWeight.Bold) }
            OutlinedAction("Exporter") {
                val share = Intent(Intent.ACTION_SEND).apply { type = "application/json"; putExtra(Intent.EXTRA_TEXT, store.exportJson()) }
                context.startActivity(Intent.createChooser(share, "Exporter la mémoire AETHER"))
            }
            OutlinedAction("Importer") { importText = ""; importError = ""; showImport = true }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            filterChoices.take(4).forEach { choice -> FilterPill(choice, filter == choice) { filter = choice } }
        }
        if (filterChoices.size > 4) {
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) { filterChoices.drop(4).take(4).forEach { choice -> FilterPill(choice, filter == choice) { filter = choice } } }
        }
        if (filteredEntries.isEmpty()) {
            Card(modifier = Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MemoryPanel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
                    Text(if (entries.isEmpty()) "La mémoire est vide" else "Aucun résultat", color = MemoryText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(7.dp)); Text(if (entries.isEmpty()) "Ajoute une information utile, une idée ou une note. Elle restera disponible après la fermeture de l’application." else "Essaie un autre mot ou filtre.", color = MemoryMuted, fontSize = 13.sp)
                }
            }
        } else {
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(filteredEntries, key = { it.id }) { entry ->
                    MemoryEntryCard(entry, onOpen = { editingEntry = entry; showEditor = true }, onDelete = { deletingEntry = entry }, onFavorite = {
                        val updated = entry.copy(favorite = !entry.favorite, updatedAt = System.currentTimeMillis())
                        val index = entries.indexOfFirst { it.id == entry.id }; if (index >= 0) entries[index] = updated
                        store.saveAll(entries.toList())
                    })
                }
            }
        }
        Text("Stockage privé local · non chiffré · aucune synchronisation", color = MemoryMuted, fontSize = 10.sp)
    }

    if (showEditor) MemoryEditorDialog(entry = editingEntry, onDismiss = { showEditor = false }, onSave = { title, category, content ->
        val now = System.currentTimeMillis(); val old = editingEntry
        val updated = MemoryEntry(id = old?.id ?: MemoryStore.newId(), title = title.trim(), category = category.trim().ifBlank { "Général" }, content = content.trim(), createdAt = old?.createdAt ?: now, updatedAt = now, favorite = old?.favorite ?: false)
        val index = entries.indexOfFirst { it.id == updated.id }; if (index >= 0) entries[index] = updated else entries.add(updated)
        store.saveAll(entries.toList()); showEditor = false
    })
    deletingEntry?.let { entry -> AlertDialog(onDismissRequest = { deletingEntry = null }, containerColor = MemoryPanel, title = { Text("Supprimer ce souvenir ?", color = MemoryText) }, text = { Text("« ${entry.title} » sera supprimé de la mémoire locale.", color = MemoryMuted) }, confirmButton = { TextButton(onClick = { entries.removeAll { it.id == entry.id }; store.saveAll(entries.toList()); deletingEntry = null }) { Text("Supprimer", color = Color(0xFFFF8F8F)) } }, dismissButton = { TextButton(onClick = { deletingEntry = null }) { Text("Annuler", color = MemoryCyan) } }) }
    if (showImport) AlertDialog(onDismissRequest = { showImport = false }, containerColor = MemoryPanel, title = { Text("Importer une sauvegarde", color = MemoryText) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Colle ici le contenu JSON d’un export AETHER. Les souvenirs importés seront fusionnés avec ceux déjà présents.", color = MemoryMuted, fontSize = 12.sp)
            OutlinedTextField(value = importText, onValueChange = { importText = it; importError = "" }, modifier = Modifier.fillMaxWidth(), minLines = 5, maxLines = 8, label = { Text("JSON") })
            if (importError.isNotBlank()) Text(importError, color = Color(0xFFFF8F8F), fontSize = 12.sp)
        }
    }, confirmButton = { TextButton(onClick = { try { val merged = store.importJson(importText); entries.clear(); entries.addAll(merged); showImport = false } catch (_: Exception) { importError = "Fichier JSON invalide ou format non reconnu." } }, enabled = importText.isNotBlank()) { Text("Importer", color = MemoryCyan) } }, dismissButton = { TextButton(onClick = { showImport = false }) { Text("Annuler", color = MemoryMuted) } })
}

@Composable
private fun FilterPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) MemoryRaised else MemoryPanel, shape = RoundedCornerShape(50), modifier = Modifier.clickable(onClick = onClick)) {
        Text(label, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp), color = if (selected) MemoryCyan else MemoryMuted, fontSize = 11.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun OutlinedAction(label: String, onClick: () -> Unit) {
    androidx.compose.material3.OutlinedButton(onClick = onClick, modifier = Modifier.width(92.dp), shape = RoundedCornerShape(14.dp)) { Text(label, fontSize = 12.sp, color = MemoryCyan) }
}

@Composable
private fun MemoryEntryCard(entry: MemoryEntry, onOpen: () -> Unit, onDelete: () -> Unit, onFavorite: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen), colors = CardDefaults.cardColors(containerColor = MemoryPanel), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Surface(color = MemoryRaised, shape = RoundedCornerShape(50)) { Text(entry.category, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = MemoryCyan, fontSize = 10.sp) }
                Text(formatMemoryDate(entry.updatedAt), color = MemoryMuted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(8.dp)); Text(entry.title, color = MemoryText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp)); Text(entry.content, color = MemoryMuted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onFavorite) { Text(if (entry.favorite) "★ Favori" else "☆ Favori", color = MemoryCyan, fontSize = 11.sp) }
                TextButton(onClick = onDelete) { Text("Supprimer", color = Color(0xFFFF8F8F), fontSize = 11.sp) }
                TextButton(onClick = onOpen) { Text("Modifier", color = MemoryCyan, fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun MemoryEditorDialog(entry: MemoryEntry?, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var title by remember(entry?.id) { mutableStateOf(entry?.title.orEmpty()) }
    var category by remember(entry?.id) { mutableStateOf(entry?.category ?: "Général") }
    var content by remember(entry?.id) { mutableStateOf(entry?.content.orEmpty()) }
    AlertDialog(onDismissRequest = onDismiss, containerColor = MemoryPanel, title = { Text(if (entry == null) "Nouvelle mémoire" else "Modifier la mémoire", color = MemoryText) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
            OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Titre") })
            OutlinedTextField(value = category, onValueChange = { category = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Catégorie") }, placeholder = { Text("Général, projet, idée…") })
            OutlinedTextField(value = content, onValueChange = { content = it }, modifier = Modifier.fillMaxWidth(), minLines = 4, maxLines = 7, label = { Text("Contenu") })
        }
    }, confirmButton = { TextButton(enabled = title.isNotBlank() && content.isNotBlank(), onClick = { onSave(title, category, content) }) { Text("Enregistrer", color = MemoryCyan) } }, dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = MemoryMuted) } })
}

private fun formatMemoryDate(timestamp: Long): String = if (timestamp <= 0L) "Date inconnue" else SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))

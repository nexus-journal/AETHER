package com.aether.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Guided multi-step routines. Steps are launched one at a time so every external action stays under user control. */
data class MorphRoutine(
    val id: String,
    val name: String,
    val steps: List<String>,
    val updatedAt: Long
)

class MorphRoutineStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aether_morph_routines", Context.MODE_PRIVATE)

    @Synchronized
    fun loadAll(): List<MorphRoutine> = try {
        val array = JSONArray(prefs.getString(KEY_ROUTINES, "[]") ?: "[]")
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id")
                val name = item.optString("name").trim()
                val rawSteps = item.optJSONArray("steps") ?: JSONArray()
                val steps = buildList {
                    for (j in 0 until rawSteps.length()) {
                        val step = rawSteps.optString(j).trim().take(300)
                        if (step.isNotBlank()) add(step)
                    }
                }.take(8)
                if (id.isNotBlank() && name.isNotBlank() && steps.size >= 2) {
                    add(MorphRoutine(id, name.take(48), steps, item.optLong("updatedAt")))
                }
            }
        }.sortedByDescending { it.updatedAt }
    } catch (_: Exception) { emptyList() }

    @Synchronized
    fun add(name: String, steps: List<String>): Boolean {
        val cleanName = name.trim().take(48)
        val cleanSteps = steps.map { it.trim().take(300) }.filter { it.isNotBlank() }.take(8)
        if (cleanName.isBlank() || cleanSteps.size !in 2..8) return false
        val updated = listOf(MorphRoutine(UUID.randomUUID().toString(), cleanName, cleanSteps, System.currentTimeMillis())) + loadAll()
        save(updated.take(30))
        return true
    }

    @Synchronized
    fun delete(id: String) = save(loadAll().filterNot { it.id == id })

    private fun save(routines: List<MorphRoutine>) {
        val array = JSONArray()
        routines.forEach { routine ->
            val steps = JSONArray()
            routine.steps.forEach { steps.put(it) }
            array.put(JSONObject().put("id", routine.id).put("name", routine.name).put("steps", steps).put("updatedAt", routine.updatedAt))
        }
        prefs.edit().putString(KEY_ROUTINES, array.toString()).apply()
    }

    companion object { private const val KEY_ROUTINES = "routines_json" }
}

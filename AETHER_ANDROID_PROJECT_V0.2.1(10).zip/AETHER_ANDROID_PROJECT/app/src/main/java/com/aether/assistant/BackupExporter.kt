package com.aether.assistant

import org.json.JSONArray
import org.json.JSONObject

/** Creates a manual export of user-owned local data. API credentials are intentionally excluded. */
object BackupExporter {
    fun createJson(
        memoryStore: MemoryStore,
        taskStore: TaskStore,
        morphToolStore: MorphToolStore,
        routineStore: MorphRoutineStore,
        conversationStore: ConversationStore
    ): String {
        val memories = JSONArray().apply {
            memoryStore.loadAll().forEach { item -> put(JSONObject()
                .put("id", item.id).put("title", item.title).put("content", item.content)
                .put("category", item.category).put("createdAt", item.createdAt)
                .put("updatedAt", item.updatedAt).put("favorite", item.favorite)) }
        }
        val tasks = JSONArray().apply {
            taskStore.loadAll().forEach { item -> put(JSONObject()
                .put("id", item.id).put("title", item.title)
                .put("createdAt", item.createdAt).put("done", item.done)) }
        }
        val tools = JSONArray().apply {
            morphToolStore.loadAll().forEach { item -> put(JSONObject()
                .put("id", item.id).put("name", item.name).put("command", item.command)) }
        }
        val routines = JSONArray().apply {
            routineStore.loadAll().forEach { item -> put(JSONObject()
                .put("id", item.id).put("name", item.name)
                .put("steps", JSONArray(item.steps)).put("updatedAt", item.updatedAt)) }
        }
        val conversations = JSONArray().apply {
            conversationStore.loadAll().forEach { item -> put(JSONObject()
                .put("role", item.role).put("text", item.text).put("timestamp", item.timestamp)) }
        }
        return JSONObject()
            .put("format", "AETHER_LOCAL_BACKUP")
            .put("schemaVersion", 1)
            .put("exportedAt", System.currentTimeMillis())
            .put("notice", "API keys and secrets are excluded from this backup.")
            .put("memories", memories)
            .put("tasks", tasks)
            .put("morphTools", tools)
            .put("morphRoutines", routines)
            .put("conversation", conversations)
            .toString(2)
    }
}

package com.aether.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val MorphBg = Color(0xFF07111F)
private val MorphPanel = Color(0xFF101F31)
private val MorphRaised = Color(0xFF152940)
private val MorphCyan = Color(0xFF62D9F5)
private val MorphText = Color(0xFFEAF4FC)
private val MorphMuted = Color(0xFF91A7BC)

@Composable
fun MorphScreen(
    modifier: Modifier = Modifier,
    store: MorphToolStore,
    routineStore: MorphRoutineStore,
    onRunTool: (String) -> Unit,
    onRunRoutine: (List<String>) -> Unit
) {
    val tools = remember(store) { mutableStateListOf<MorphTool>().apply { addAll(store.loadAll()) } }
    val routines = remember(routineStore) { mutableStateListOf<MorphRoutine>().apply { addAll(routineStore.loadAll()) } }
    var activeView by remember { mutableStateOf("Outils") }
    var showToolCreator by remember { mutableStateOf(false) }
    var showRoutineCreator by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(11.dp)) {
        Text("MORPH · TOOL STUDIO", color = MorphCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
        Text("Construis tes propres workflows.", color = MorphText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text("Des raccourcis simples aux routines guidées, tout reste stocké localement.", color = MorphMuted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            MorphTab("Outils", activeView == "Outils") { activeView = "Outils" }
            MorphTab("Routines", activeView == "Routines") { activeView = "Routines" }
        }
        if (activeView == "Outils") {
            Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(17.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("RACCOURCIS PERSONNELS", color = MorphCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("Associe un nom à une commande AETHER. Le lancement repasse par l'assistant et ses confirmations.", color = MorphText, fontSize = 12.sp)
                }
            }
            Button(onClick = { showToolCreator = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MorphCyan, contentColor = MorphBg), shape = RoundedCornerShape(14.dp)) {
                Text("+ Créer un outil", fontWeight = FontWeight.Bold)
            }
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (tools.isEmpty()) item { EmptyMorphCard("Aucun outil créé", "Exemple : nomme-le « Briefing spatial » et associe-lui « Cherche les actualités spatiales ».") }
                items(tools, key = { it.id }) { tool ->
                    Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(tool.name, color = MorphText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text(tool.command, color = MorphMuted, fontSize = 12.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { onRunTool(tool.command) }, colors = ButtonDefaults.buttonColors(containerColor = MorphCyan, contentColor = MorphBg)) { Text("Lancer", fontSize = 11.sp) }
                                TextButton(onClick = { store.delete(tool.id); tools.removeAll { it.id == tool.id } }) { Text("Supprimer", color = Color(0xFFFF9B9B), fontSize = 11.sp) }
                            }
                        }
                    }
                }
            }
        } else {
            Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(17.dp)) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("ROUTINES GUIDÉES", color = MorphCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Text("Enregistre de 2 à 8 étapes. AETHER les présente une par une : aucune action externe n'est exécutée sans ta confirmation.", color = MorphText, fontSize = 12.sp)
                }
            }
            Button(onClick = { showRoutineCreator = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MorphCyan, contentColor = MorphBg), shape = RoundedCornerShape(14.dp)) {
                Text("+ Créer une routine", fontWeight = FontWeight.Bold)
            }
            LazyColumn(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                if (routines.isEmpty()) item { EmptyMorphCard("Ton premier workflow", "Exemple : « Préparer ma journée » avec les étapes météo, agenda et tâches.") }
                items(routines, key = { it.id }) { routine ->
                    Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(routine.name, color = MorphText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                    Text("${routine.steps.size} étapes", color = MorphCyan, fontSize = 10.sp)
                                }
                                TextButton(onClick = { routineStore.delete(routine.id); routines.removeAll { it.id == routine.id } }) { Text("Supprimer", color = Color(0xFFFF9B9B), fontSize = 11.sp) }
                            }
                            routine.steps.forEachIndexed { index, step ->
                                Row(verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Surface(color = MorphRaised, shape = RoundedCornerShape(8.dp)) {
                                        Text("${index + 1}", color = MorphCyan, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                                    }
                                    Text(step, color = MorphMuted, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                }
                            }
                            Button(onClick = { onRunRoutine(routine.steps) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MorphCyan, contentColor = MorphBg)) {
                                Text("Démarrer la routine", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    if (showToolCreator) MorphToolDialog(
        onDismiss = { showToolCreator = false },
        onSave = { name, command -> store.add(name, command); tools.clear(); tools.addAll(store.loadAll()); showToolCreator = false }
    )
    if (showRoutineCreator) MorphRoutineDialog(
        onDismiss = { showRoutineCreator = false },
        onSave = { name, steps ->
            if (routineStore.add(name, steps)) { routines.clear(); routines.addAll(routineStore.loadAll()); showRoutineCreator = false }
        }
    )
}

@Composable
private fun MorphTab(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) MorphRaised else MorphPanel, shape = RoundedCornerShape(50), modifier = Modifier.clickable(onClick = onClick)) {
        Text(label, color = if (selected) MorphCyan else MorphMuted, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp))
    }
}

@Composable
private fun EmptyMorphCard(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(17.dp)) {
        Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(title, color = MorphText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(detail, color = MorphMuted, fontSize = 12.sp)
        }
    }
}

@Composable
private fun MorphToolDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = MorphPanel,
        title = { Text("Nouvel outil MORPH", color = MorphText) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom de l'outil") }, placeholder = { Text("Briefing du matin") })
                OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 5, label = { Text("Commande AETHER") }, placeholder = { Text("Cherche les dernières actualités scientifiques") })
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name, command) }, enabled = name.isNotBlank() && command.isNotBlank()) { Text("Enregistrer", color = MorphCyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = MorphMuted) } }
    )
}

@Composable
private fun MorphRoutineDialog(onDismiss: () -> Unit, onSave: (String, List<String>) -> Unit) {
    var name by remember { mutableStateOf("") }
    var stepsText by remember { mutableStateOf("") }
    val steps = stepsText.lines().map { it.trim() }.filter { it.isNotBlank() }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = MorphPanel,
        title = { Text("Nouvelle routine guidée", color = MorphText) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it.take(48) }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom") }, placeholder = { Text("Préparer ma journée") })
                OutlinedTextField(value = stepsText, onValueChange = { stepsText = it.take(2400) }, modifier = Modifier.fillMaxWidth(), minLines = 5, maxLines = 8, label = { Text("Une commande par ligne (2 à 8)") }, placeholder = { Text("Quelle est la date et l'heure ?\nMes tâches\nCherche les actualités principales") })
                Text("${steps.size}/8 étapes · Chaque commande sera lancée séparément.", color = MorphMuted, fontSize = 10.sp)
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name, steps) }, enabled = name.isNotBlank() && steps.size in 2..8) { Text("Enregistrer", color = MorphCyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = MorphMuted) } }
    )
}

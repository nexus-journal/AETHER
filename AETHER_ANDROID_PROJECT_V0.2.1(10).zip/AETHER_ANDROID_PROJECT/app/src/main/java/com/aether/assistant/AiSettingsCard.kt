package com.aether.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val AiCyan = Color(0xFF62D9F5)
private val AiPanel = Color(0xFF101F31)
private val AiRaised = Color(0xFF152940)
private val AiText = Color(0xFFEAF4FC)
private val AiMuted = Color(0xFF91A7BC)

@Composable
fun AiSettingsCard(store: AiSettingsStore) {
    val initial = remember(store) { store.load() }
    var provider by remember { mutableStateOf(initial.provider) }
    var model by remember { mutableStateOf(initial.model) }
    var endpoint by remember { mutableStateOf(initial.endpoint) }
    var apiKey by remember { mutableStateOf("") }
    var hasSavedKey by remember { mutableStateOf(initial.apiKey.isNotBlank()) }
    var status by remember { mutableStateOf(if (initial.apiKey.isNotBlank()) "Une clé API est enregistrée et chiffrée sur cet appareil." else "Aucune clé API configurée. Le mode local reste disponible.") }
    var showEndpoint by remember { mutableStateOf(provider == AiSettingsStore.PROVIDER_OPENAI) }

    Card(colors = CardDefaults.cardColors(containerColor = AiPanel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("INTELLIGENCE CONVERSATIONNELLE", color = AiCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("Connecter le cerveau d'AETHER", color = AiText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("Choisis un fournisseur. Gemini est préconfiguré ; l'alternative accepte les API compatibles avec OpenAI (par exemple OpenRouter ou Groq).", color = AiMuted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ProviderChoice("Gemini", provider == AiSettingsStore.PROVIDER_GEMINI) {
                    provider = AiSettingsStore.PROVIDER_GEMINI
                    apiKey = ""
                    model = AiSettingsStore.DEFAULT_GEMINI_MODEL
                    showEndpoint = false
                    hasSavedKey = store.hasApiKey(AiSettingsStore.PROVIDER_GEMINI)
                }
                ProviderChoice("API compatible", provider == AiSettingsStore.PROVIDER_OPENAI) {
                    provider = AiSettingsStore.PROVIDER_OPENAI
                    apiKey = ""
                    model = AiSettingsStore.DEFAULT_OPENAI_MODEL
                    endpoint = AiSettingsStore.DEFAULT_OPENAI_ENDPOINT
                    showEndpoint = true
                    hasSavedKey = store.hasApiKey(AiSettingsStore.PROVIDER_OPENAI)
                }
            }
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it.take(300) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(if (hasSavedKey) "Nouvelle clé API (laisser vide pour conserver)" else "Clé API") },
                placeholder = { Text("Colle ta clé ici") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
            OutlinedTextField(
                value = model,
                onValueChange = { model = it.take(120) },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("Modèle") },
                singleLine = true
            )
            if (showEndpoint) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PresetChoice("OpenRouter") { endpoint = "https://openrouter.ai/api/v1"; model = "openrouter/free" }
                        PresetChoice("Groq") { endpoint = "https://api.groq.com/openai/v1"; model = "openai/gpt-oss-120b" }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        PresetChoice("Mistral") { endpoint = "https://api.mistral.ai/v1"; model = "mistral-small-latest" }
                        PresetChoice("Personnalisé") { endpoint = AiSettingsStore.DEFAULT_OPENAI_ENDPOINT; model = "openrouter/free" }
                    }
                }
                OutlinedTextField(
                    value = endpoint,
                    onValueChange = { endpoint = it.take(300) },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Adresse de l'API") },
                    singleLine = true
                )
            }
            Button(
                onClick = {
                    store.save(provider, model, endpoint, apiKey)
                    apiKey = ""
                    hasSavedKey = store.load().apiKey.isNotBlank()
                    status = if (hasSavedKey) "Configuration enregistrée. La clé est chiffrée avec Android Keystore." else "Aucune clé enregistrée."
                },
                enabled = model.isNotBlank() && (!showEndpoint || endpoint.startsWith("https://")),
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = AiCyan, contentColor = Color(0xFF07111F)),
                shape = RoundedCornerShape(12.dp)
            ) { Text("Enregistrer la configuration", fontWeight = FontWeight.Bold) }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = {
                    store.clearApiKey()
                    apiKey = ""
                    hasSavedKey = false
                    status = "Clé API supprimée. AETHER repasse en mode local."
                }) { Text("Effacer la clé", color = AiMuted, fontSize = 11.sp) }
                Surface(color = AiRaised, shape = RoundedCornerShape(10.dp), modifier = Modifier.weight(1f)) {
                    Text(status, color = AiText, fontSize = 10.sp, modifier = Modifier.padding(10.dp))
                }
            }
            Spacer(Modifier.height(2.dp))
            Text("Confidentialité : les messages et les souvenirs sélectionnés pour le contexte sont envoyés au fournisseur choisi. Le stockage chiffre la clé sur cet appareil, mais une clé utilisée directement par une application mobile n'est pas aussi protégée qu'une clé conservée sur un serveur privé. N'enregistre pas de mots de passe ou de données sensibles dans la mémoire.", color = AiMuted, fontSize = 10.sp)
            Text("Les modèles et quotas des fournisseurs peuvent changer. Vérifie le nom du modèle et les conditions de confidentialité sur le site du fournisseur avant utilisation. Les contenus envoyés à un fournisseur externe quittent cet appareil : n'y envoie pas de données sensibles.", color = AiMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun ProviderChoice(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) AiRaised else Color.Transparent,
        shape = RoundedCornerShape(50),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(
            label,
            color = if (selected) AiCyan else AiMuted,
            fontSize = 11.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 9.dp)
        )
    }
}

@Composable
private fun PresetChoice(label: String, onClick: () -> Unit) {
    Surface(color = AiRaised, shape = RoundedCornerShape(50), modifier = Modifier.clickable(onClick = onClick)) {
        Text(label, color = AiCyan, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
    }
}

package com.aether.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Stockage privé local de la mémoire AETHER. Aucun accès réseau. */
class MemoryStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(PREFERENCES_NAME, Context.MODE_PRIVATE)

    fun loadAll(): List<MemoryEntry> {
        val raw = preferences.getString(KEY_ENTRIES, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
                    val title = item.optString("title").takeIf { it.isNotBlank() } ?: continue
                    add(MemoryEntry(
                        id = id, title = title, content = item.optString("content"),
                        category = item.optString("category", "Général"),
                        createdAt = item.optLong("createdAt"), updatedAt = item.optLong("updatedAt"),
                        favorite = item.optBoolean("favorite", false)
                    ))
                }
            }.sortedByDescending { it.updatedAt }
        } catch (_: Exception) { emptyList() }
    }

    fun saveAll(entries: List<MemoryEntry>) {
        preferences.edit().putString(KEY_ENTRIES, entriesToJson(entries).toString()).apply()
    }

    fun exportJson(): String = entriesToJson(loadAll()).toString(2)

    /** Import validates JSON and merges by ID; title/content entries with missing IDs get new IDs. */
    fun importJson(raw: String): List<MemoryEntry> {
        val root = JSONArray(raw)
        val imported = buildList {
            for (i in 0 until root.length()) {
                val item = root.optJSONObject(i) ?: continue
                val title = item.optString("title").trim()
                val content = item.optString("content").trim()
                if (title.isBlank() || content.isBlank()) continue
                val now = System.currentTimeMillis()
                add(MemoryEntry(
                    id = item.optString("id").takeIf { it.isNotBlank() } ?: newId(),
                    title = title, content = content,
                    category = item.optString("category", "Général").ifBlank { "Général" },
                    createdAt = item.optLong("createdAt", now), updatedAt = item.optLong("updatedAt", now),
                    favorite = item.optBoolean("favorite", false)
                ))
            }
        }
        val current = loadAll().associateBy { it.id }.toMutableMap()
        imported.forEach { current[it.id] = it }
        val merged = current.values.sortedByDescending { it.updatedAt }
        saveAll(merged)
        return merged
    }

    private fun entriesToJson(entries: List<MemoryEntry>): JSONArray = JSONArray().apply {
        entries.forEach { entry -> put(JSONObject()
            .put("id", entry.id).put("title", entry.title).put("content", entry.content)
            .put("category", entry.category).put("createdAt", entry.createdAt)
            .put("updatedAt", entry.updatedAt).put("favorite", entry.favorite)) }
    }

    companion object {
        private const val PREFERENCES_NAME = "aether_local_memory"
        private const val KEY_ENTRIES = "entries_json"
        fun newId(): String = UUID.randomUUID().toString()
    }
}

data class MemoryEntry(
    val id: String,
    val title: String,
    val content: String,
    val category: String,
    val createdAt: Long,
    val updatedAt: Long,
    val favorite: Boolean = false
)

# AETHER Android — V1.5.0

**AETHER** est un assistant Android personnel hybride : les commandes déterministes, souvenirs, tâches, raccourcis et routines sont gérés localement ; les conversations libres peuvent utiliser un fournisseur IA externe configuré par l'utilisateur.

## Fonctionnalités

- **Assistant conversationnel** : commandes locales, historique de conversation sur l'appareil, réponses vocales facultatives et dictée via le service de reconnaissance vocale Android.
- **IA configurable** : Gemini ou API compatible OpenAI. Des préréglages d'adresse sont proposés pour OpenRouter, Groq et Mistral ; le modèle exact doit être vérifié auprès du fournisseur et reste modifiable.
- **Clé API** : chiffrement AES/GCM avec une clé conservée dans Android Keystore. Une clé utilisée dans une application mobile n'est jamais aussi isolée qu'une clé conservée sur un serveur privé.
- **Mémoire personnelle** : création, recherche, favoris, catégories et import/export JSON local.
- **Tâches** : liste locale, ajout et suivi des tâches.
- **Actions Android confirmées** : recherche Web, carte, alarme via Horloge, événement via Calendrier, composeur téléphonique, SMS prérempli, partage, paramètres et ouverture d'applications prises en charge (YouTube, Spotify, Maps, Chrome, caméra, galerie, Gmail, WhatsApp, Messages, Calendrier, Horloge, Fichiers et Calculatrice selon les applications installées).
- **MORPH Studio** : raccourcis AETHER personnalisés.
- **Routines guidées** : 2 à 8 commandes exécutées étape par étape. Chaque action externe reste soumise à une confirmation distincte.
- **Agent planificateur** : proposition IA de plans complexes (2 à 8 étapes), avec lancement manuel de chaque étape et enregistrement possible dans MORPH.
- **Journal d’actions** : historique local minimaliste des actions confirmées ou annulées, sans contenu de SMS, numéro ni URL complète.
- **État de l’appareil** : consultation locale du niveau de batterie et de l’état de charge.
- **Export JSON** : sauvegarde manuelle des souvenirs, tâches, conversations, outils et routines ; les clés API ne sont jamais exportées.
- **Interface** : tableau de bord et navigation sombre adaptée au mobile.

## Limites importantes

- La qualité des conversations libres dépend du modèle choisi, de sa disponibilité, des quotas, de la connexion Internet et de la clé API configurée. Aucun modèle externe n'est inclus dans l'APK.
- Les offres gratuites, les identifiants de modèles et les conditions d'utilisation des fournisseurs peuvent changer. AETHER ne garantit pas un accès gratuit permanent.
- Les actions Android passent par les interfaces et applications Android disponibles. AETHER ne contourne pas les permissions, ne lit pas les contenus privés d'autres applications et n'exécute pas de commandes système arbitraires.
- MORPH crée des raccourcis et des routines guidées ; il n'exécute pas du code arbitraire ni des modules téléchargés.
- La dictée et la synthèse vocale dépendent des services vocaux installés sur le téléphone.
- Les données mémoire, tâches, routines et conversations sont stockées localement dans les préférences privées de l'application. La désinstallation peut les supprimer.

## Construction de l'APK

Le dépôt GitHub utilise GitHub Actions pour construire l'APK debug à partir de l'archive `AETHER_ANDROID_PROJECT_V0.2.1.zip`.

1. Remplacer l'archive existante à la racine du dépôt par le ZIP de cette version, sans la décompresser ni la renommer.
2. Valider l'envoi sur la branche `main`.
3. Ouvrir l'onglet **Actions** et vérifier que le workflow **AETHER Android Build** termine en vert.
4. Télécharger l'artefact **AETHER-debug-APK** généré par cette exécution.

Projet Gradle : `AETHER_ANDROID_PROJECT/`  
Application : `app/`  
Namespace : `com.aether.assistant`  
Version : `1.5.0` (versionCode 15)  
JDK : 17  
SDK : compileSdk 36  
Gradle attendu par le workflow : 8.13


## Contrôles V1.5.0

L’intégrité de l’archive ZIP et les contrôles statiques des sources ont été vérifiés. La compilation Android complète reste à valider par le workflow GitHub Actions. L’export JSON est manuel ; aucune restauration n’est fournie dans cette version.

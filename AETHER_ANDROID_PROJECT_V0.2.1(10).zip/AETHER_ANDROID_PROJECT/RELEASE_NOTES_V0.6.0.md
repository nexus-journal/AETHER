# AETHER 0.6.0 — Intelligence conversationnelle

## Nouveautés
- Connexion à Gemini REST et aux fournisseurs compatibles OpenAI Chat Completions.
- Modèle Gemini par défaut : `gemini-3.8-flash`.
- Routage automatique : commandes déterministes traitées localement ; demandes libres envoyées au modèle configuré.
- Historique local des conversations (80 messages, 14 derniers échanges fournis au modèle).
- Contexte de mémoire pertinent (jusqu'à 6 souvenirs) et liste des tâches ouvertes.
- Actions structurées JSON soumises à validation locale et à confirmation explicite.
- Ajout de tâches et mémorisation par action confirmée.
- Ouverture encadrée de YouTube, Spotify, Maps, Chrome, Camera et Gallery.
- Clé API chiffrée avec AES/GCM et Android Keystore.
- Écran Réglages enrichi : fournisseur, modèle, endpoint, saisie/effacement de clé, avertissements de confidentialité et suppression de l'historique.
- Permission Internet ajoutée ; trafic HTTP en clair désactivé.

## Compatibilité
- Archive attendue par le workflow : `AETHER_ANDROID_PROJECT_V0.2.1.zip` (nom conservé pour éviter de modifier le workflow).
- Application : version 0.6.0, versionCode 6.
- Java 17, Android SDK 36, Gradle 8.13.

## À vérifier sur appareil
- Enregistrer une clé API valide dans Réglages → Intelligence.
- Envoyer une question libre pour tester le flux IA.
- Tester une action comme « ouvre YouTube » et vérifier que l'action ne se lance qu'après confirmation.
- Tester le mode local en effaçant la clé API.

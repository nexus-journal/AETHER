# AETHER 1.0.0 — plateforme personnelle consolidée

## Nouveautés
- MORPH Studio regroupe les raccourcis personnalisés et les routines guidées multi-étapes.
- Création de routines de 2 à 8 commandes, lancement guidé dans l'assistant et passage manuel à l'étape suivante.
- Plus d'applications Android prises en charge : Gmail, WhatsApp, Messages, Calendrier, Horloge, Fichiers et Calculatrice, en plus des applications déjà présentes.
- Préréglages de fournisseurs API compatibles : OpenRouter, Groq, Mistral et configuration personnalisée.
- Écran d'accueil et paramètres mis à jour pour afficher la version 1.0.0.
- Documentation d'architecture, de confidentialité, de limites et de construction mise à jour.

## Conservé et consolidé
- Assistant local et IA distante facultative.
- Mémoire personnelle locale avec recherche, favoris et import/export.
- Tâches locales et historique de conversation.
- Dictée Android et synthèse vocale facultative.
- Actions Android préparées puis confirmées par l'utilisateur.
- Clés API chiffrées avec Android Keystore.

## Limites assumées
Cette version ne fournit pas un accès total au système Android, une écoute permanente, une exécution autonome en arrière-plan, un cloud privé, ni l'exécution de code arbitraire généré par MORPH. Les capacités accessibles sont limitées par les API et permissions Android, les applications installées et le fournisseur IA choisi.

## Version
- versionName : 1.0.0
- versionCode : 10

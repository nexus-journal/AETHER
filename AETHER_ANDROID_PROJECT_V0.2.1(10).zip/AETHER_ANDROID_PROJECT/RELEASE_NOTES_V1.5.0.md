# AETHER V1.5.0

## Évolutions

- **Agent planificateur** : l'assistant IA peut proposer des plans de 2 à 8 étapes pour les demandes complexes. Rien ne démarre automatiquement ; l'utilisateur lance chaque étape manuellement.
- **Intégration MORPH** : un plan suggéré par l'IA peut être enregistré comme routine locale réutilisable.
- **Journal d'actions** : conservation locale des actions confirmées ou annulées, avec descriptions minimisées pour éviter d'archiver des SMS, numéros et URL sensibles.
- **État de l'appareil** : lecture locale du niveau de batterie et de l'état de charge, sans permission supplémentaire.
- **Export local** : export JSON des souvenirs, tâches, outils MORPH, routines et conversations. Les clés API sont explicitement exclues.
- **Version Android** : versionCode 15, versionName 1.5.0.

## Limites maintenues

- Les appels à l'IA nécessitent un fournisseur externe, une clé valide et une connexion.
- Les actions Android restent limitées aux intentions Android prévues et demandent une confirmation dans l'interface.
- Les plans ne sont pas des tâches autonomes en arrière-plan : chaque étape est déclenchée par l'utilisateur.
- L'export est manuel et partage le JSON via le sélecteur Android. L'import/restauration n'est pas encore inclus.
- Cette archive a fait l'objet de contrôles statiques et d'intégrité ZIP ; une compilation Android complète doit encore être confirmée par GitHub Actions.

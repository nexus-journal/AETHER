# AETHER 0.5.0 — Assistant Core

## Ajouts
- Nouvel onglet Assistant avec conversation et commandes locales en français.
- Dictée vocale et lecture vocale des réponses via les services Android disponibles.
- Gestion des tâches avec ajout, validation et suppression.
- Moteur de propositions d'actions Android avec confirmation manuelle.
- Actions prises en charge : recherche Web, carte, alarme, calendrier, composeur, SMS prérempli, partage, URL et paramètres.
- MORPH Studio permet de créer des raccourcis personnalisés persistants.
- Accueil actualisé avec compteurs de mémoire et de tâches.
- Documentation mise à jour et version Android passée à 0.5.0.

## À noter
L'assistant n'est pas encore relié à une IA générative. Les tâches ne déclenchent pas encore de rappels ou notifications planifiés. Les actions Android ouvrent les applications correspondantes et restent sous le contrôle de l'utilisateur.

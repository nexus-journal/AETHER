package com.aether.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val MemoryCyan = Color(0xFF62D9F5)
private val MemoryPanel = Color(0xFF101F31)
private val MemoryRaised = Color(0xFF152940)
private val MemoryText = Color(0xFFEAF4FC)
private val MemoryMuted = Color(0xFF91A7BC)
private val MemoryBackground = Color(0xFF07111F)

@Composable
fun MemoryScreen(modifier: Modifier = Modifier, store: MemoryStore) {
    val entries = remember(store) {
        mutableStateListOf<MemoryEntry>().apply { addAll(store.loadAll()) }
    }
    var search by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editingEntry by remember { mutableStateOf<MemoryEntry?>(null) }
    var deletingEntry by remember { mutableStateOf<MemoryEntry?>(null) }

    val filteredEntries = entries
        .filter { entry ->
            val needle = search.trim()
            needle.isEmpty() || entry.title.contains(needle, ignoreCase = true) ||
                entry.content.contains(needle, ignoreCase = true) ||
                entry.category.contains(needle, ignoreCase = true)
        }
        .sortedByDescending { it.updatedAt }

    Column(
        modifier = modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Column {
            Text("MÉMOIRE CENTRALE", color = MemoryCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
            Spacer(Modifier.height(5.dp))
            Text("Tout ce qui mérite d’être retenu.", color = MemoryText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(3.dp))
            Text("Une mémoire personnelle, enregistrée sur cet appareil.", color = MemoryMuted, fontSize = 12.sp)
        }

        Card(colors = CardDefaults.cardColors(containerColor = MemoryPanel), shape = RoundedCornerShape(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(15.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("ÉLÉMENTS EN MÉMOIRE", color = MemoryMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    Text(entries.size.toString(), color = MemoryText, fontSize = 25.sp, fontWeight = FontWeight.Bold)
                }
                Text("LOCAL  •  HORS LIGNE", color = MemoryCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }

        OutlinedTextField(
            value = search,
            onValueChange = { search = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Rechercher dans la mémoire…", color = MemoryMuted) },
            label = { Text("Recherche") }
        )

        Button(
            onClick = { editingEntry = null; showEditor = true },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = MemoryCyan, contentColor = MemoryBackground),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text("+  Ajouter un souvenir", fontWeight = FontWeight.Bold)
        }

        if (filteredEntries.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth().weight(1f),
                colors = CardDefaults.cardColors(containerColor = MemoryPanel),
                shape = RoundedCornerShape(18.dp)
            ) {
                Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.Center) {
                    Text(if (entries.isEmpty()) "La mémoire est vide" else "Aucun résultat", color = MemoryText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(7.dp))
                    Text(
                        if (entries.isEmpty()) "Ajoute une information utile, une idée ou une note. Elle restera disponible après la fermeture de l’application."
                        else "Essaie un autre mot ou une autre catégorie.",
                        color = MemoryMuted, fontSize = 13.sp
                    )
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(9.dp)
            ) {
                items(filteredEntries, key = { it.id }) { entry ->
                    MemoryEntryCard(
                        entry = entry,
                        onOpen = { editingEntry = entry; showEditor = true },
                        onDelete = { deletingEntry = entry }
                    )
                }
            }
        }

        Text("Les données restent dans le stockage privé de l’application. Elles ne sont pas synchronisées ni chiffrées dans cette version.", color = MemoryMuted, fontSize = 10.sp)
    }

    if (showEditor) {
        MemoryEditorDialog(
            entry = editingEntry,
            onDismiss = { showEditor = false },
            onSave = { title, category, content ->
                val now = System.currentTimeMillis()
                val old = editingEntry
                val updated = MemoryEntry(
                    id = old?.id ?: MemoryStore.newId(),
                    title = title.trim(),
                    category = category.trim().ifBlank { "Général" },
                    content = content.trim(),
                    createdAt = old?.createdAt ?: now,
                    updatedAt = now
                )
                val index = entries.indexOfFirst { it.id == updated.id }
                if (index >= 0) entries[index] = updated else entries.add(updated)
                store.saveAll(entries.toList())
                showEditor = false
            }
        )
    }

    deletingEntry?.let { entry ->
        AlertDialog(
            onDismissRequest = { deletingEntry = null },
            containerColor = MemoryPanel,
            title = { Text("Supprimer ce souvenir ?", color = MemoryText) },
            text = { Text("« ${entry.title} » sera supprimé de la mémoire locale.", color = MemoryMuted) },
            confirmButton = {
                TextButton(onClick = {
                    entries.removeAll { it.id == entry.id }
                    store.saveAll(entries.toList())
                    deletingEntry = null
                }) { Text("Supprimer", color = Color(0xFFFF8F8F)) }
            },
            dismissButton = { TextButton(onClick = { deletingEntry = null }) { Text("Annuler", color = MemoryCyan) } }
        )
    }
}

@Composable
private fun MemoryEntryCard(entry: MemoryEntry, onOpen: () -> Unit, onDelete: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        colors = CardDefaults.cardColors(containerColor = MemoryPanel),
        shape = RoundedCornerShape(17.dp)
    ) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Surface(color = MemoryRaised, shape = RoundedCornerShape(50)) {
                    Text(entry.category, modifier = Modifier.padding(horizontal = 9.dp, vertical = 5.dp), color = MemoryCyan, fontSize = 10.sp)
                }
                Text(formatMemoryDate(entry.updatedAt), color = MemoryMuted, fontSize = 10.sp)
            }
            Spacer(Modifier.height(9.dp))
            Text(entry.title, color = MemoryText, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(5.dp))
            Text(entry.content, color = MemoryMuted, fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                TextButton(onClick = onDelete) { Text("Supprimer", color = Color(0xFFFF8F8F), fontSize = 11.sp) }
                TextButton(onClick = onOpen) { Text("Modifier", color = MemoryCyan, fontSize = 11.sp) }
            }
        }
    }
}

@Composable
private fun MemoryEditorDialog(
    entry: MemoryEntry?,
    onDismiss: () -> Unit,
    onSave: (title: String, category: String, content: String) -> Unit
) {
    var title by remember(entry?.id) { mutableStateOf(entry?.title.orEmpty()) }
    var category by remember(entry?.id) { mutableStateOf(entry?.category ?: "Général") }
    var content by remember(entry?.id) { mutableStateOf(entry?.content.orEmpty()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MemoryPanel,
        title = { Text(if (entry == null) "Nouvelle mémoire" else "Modifier la mémoire", color = MemoryText) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Titre") })
                OutlinedTextField(value = category, onValueChange = { category = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Catégorie") }, placeholder = { Text("Général, projet, idée…") })
                OutlinedTextField(value = content, onValueChange = { content = it }, modifier = Modifier.fillMaxWidth(), minLines = 4, maxLines = 7, label = { Text("Contenu") })
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank() && content.isNotBlank(), onClick = { onSave(title, category, content) }) {
                Text("Enregistrer", color = MemoryCyan)
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = MemoryMuted) } }
    )
}

private fun formatMemoryDate(timestamp: Long): String {
    if (timestamp <= 0L) return "Date inconnue"
    return SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(timestamp))
}

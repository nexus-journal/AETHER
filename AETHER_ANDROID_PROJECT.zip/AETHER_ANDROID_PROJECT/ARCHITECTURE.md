# Architecture prévue

- `app`: application Android native Kotlin / Jetpack Compose.
- `core`: à ajouter pour les modèles de données, événements et préférences partagés.
- `memory`: à ajouter pour le stockage local chiffré et les contrôles de rétention.
- `morph`: à ajouter pour les spécifications, modèles et tests d'outils.
- `voice`: à ajouter après validation des contraintes Android de premier plan et de confidentialité.
- `connectors`: à ajouter pour les services en ligne optionnels.

Règles de conception : fonctionnement local quand c'est possible, permissions minimales, transparence sur les données, validation explicite des actions sensibles et distinction claire entre fonctionnalités disponibles et prévues.

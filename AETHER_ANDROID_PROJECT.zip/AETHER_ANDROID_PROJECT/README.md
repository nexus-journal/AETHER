# AETHER Android — v0.1.0

Premier socle Android natif d'AETHER, construit avec Kotlin et Jetpack Compose.

## Contenu
- Application Android lançable et interface sombre AETHER.
- Navigation Accueil / Modules / Laboratoire / Réglages.
- Première structure visuelle de MORPH et des modules envisagés.
- Compilation Debug via Gradle et GitHub Actions.

## Limites de cette version
Il s'agit d'un prototype d'interface et d'une base de compilation. La mémoire persistante, la reconnaissance vocale, les modèles locaux, la vision, les connexions réseau et les automatisations ne sont pas encore implémentés. Les libellés « PRÉVU » indiquent des fonctions futures.

## Compilation locale
Ouvrir ce dossier dans Android Studio avec JDK 17 et Android SDK 36, puis lancer la tâche `:app:assembleDebug`.

## Package
`com.aether.assistant` — version `0.1.0` — min SDK 26.

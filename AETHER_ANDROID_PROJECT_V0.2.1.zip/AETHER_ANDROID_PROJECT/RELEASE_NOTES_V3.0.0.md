# AETHER V3.0.0

## Nouveautés majeures

- Mode mains libres activable depuis Réglages avec « AETHER » / « Hey AETHER ».
- Service microphone au premier plan pour continuer l'écoute après avoir quitté l'interface et écran verrouillé, tant qu'Android conserve le service.
- Notification persistante avec bouton d'arrêt immédiat et demandes explicites des permissions nécessaires.
- Réponse vocale TTS, capture d'une commande après le mot d'appel et reprise de l'écoute après la réponse.
- Choix du moteur de reconnaissance local lorsqu'il est disponible ; sinon reconnaissance par le fournisseur vocal Android, avec préférence hors ligne lorsque supportée.
- Les conversations vocales sont ajoutées à l'historique AETHER. Les réponses libres utilisent le fournisseur IA déjà configuré.
- Les actions externes proposées à la voix exigent toujours une validation dans l'application.

## Transparence et limites

- Mode expérimental reposant sur des sessions SpeechRecognizer répétées, et non sur un détecteur matériel de mot-clé à très faible consommation.
- L'activation se fait manuellement quand l'application est visible. Pas de démarrage caché ou automatique au redémarrage.
- Une notification permanente signale l'utilisation du microphone. L'utilisateur peut arrêter le mode depuis la notification ou Réglages.
- Le service maintient un verrou CPU partiel pendant l'écoute : consommation de batterie plus élevée possible.
- Le service vocal Android peut traiter l'audio si aucun recognizer local n'est disponible.

## Conservation

Toutes les fonctions AETHER V2.0 sont conservées : mémoire, tâches, IA configurable, briefing local, import/export de sauvegarde, MORPH, agent planificateur, historique et actions Android avec confirmation.

## Vérification

L'archive doit rester nommée `AETHER_ANDROID_PROJECT_V0.2.1.zip` pour le workflow GitHub existant. La compilation Android finale doit être confirmée par GitHub Actions sur le dépôt.

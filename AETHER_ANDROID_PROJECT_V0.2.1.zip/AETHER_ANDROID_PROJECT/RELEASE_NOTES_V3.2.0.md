# AETHER Android — V3.2.0

## Nouvelle version : Hub personnel et outils locaux

### Nouveautés
- **Recherche locale unifiée** depuis l'accueil : recherche dans les titres/contenus de mémoire, les tâches, les outils MORPH et les routines ; les résultats ouvrent la fonction correspondante.
- **Calculatrice locale sécurisée** : opérations `+`, `-`, `*`, `/` et parenthèses, sans exécution de code ni connexion réseau.
- **Convertisseur hors ligne** : kilomètres/miles, kilogrammes/livres, centimètres/pouces et Celsius/Fahrenheit.
- **Compétences MORPH étendues** : bibliothèque de souvenirs, favoris, statistiques locales, applications de communication et outils hors ligne.
- **Préférences persistantes** : activation/désactivation du retour haptique, des réponses vocales, de la densité du tableau de bord et de la taille du texte.
- **Recherche de tâches** directement dans la liste de tâches.
- **Centre de confidentialité** : suppression groupée et confirmée des souvenirs, tâches, outils, routines, conversations et journal d'actions. La configuration IA et la clé API restent volontairement préservées.

### Conservé
- Mémoire locale, tâches, MORPH Studio, routines guidées, plans IA avec lancement étape par étape.
- Actions Android autorisées, soumises à confirmation.
- Export et restauration JSON.
- Mode mains libres expérimental, signalé par une notification persistante.

### Limites
- La recherche unifiée ne parcourt que les données locales accessibles à AETHER ; elle ne recherche pas dans les fichiers ou les autres applications.
- Les conversions et calculs sont traités localement et ne remplacent pas un outil de calcul spécialisé pour les usages critiques.
- Le mode mains libres reste dépendant du service vocal Android et des limites de batterie du téléphone.
- La compilation complète de l'APK doit être validée par le workflow GitHub Actions du dépôt.

# AETHER V2.0.0 — Personal Intelligence Upgrade

## Ajouts
- Briefing personnel quotidien entièrement local : date, heure, tâches en attente/terminées et aperçu de la mémoire.
- Export direct des données locales au format JSON via le sélecteur de documents Android.
- Restauration depuis un fichier JSON, avec prévisualisation des quantités et confirmation obligatoire.
- Validation du format, de la version du schéma, de la taille du fichier et des volumes de chaque collection avant restauration.
- Conservation des paramètres du fournisseur IA et des clés API pendant la restauration.
- Tableau de bord mis à jour avec accès direct au briefing.

## Compatibilité
- `applicationId` conservé : `com.aether.assistant`
- `versionCode` : 20
- `versionName` : 2.0.0
- Android minimum : API 26

## Validation
- Contrôle ZIP et contrôles statiques effectués avant livraison.
- La compilation Android complète doit être confirmée par GitHub Actions sur le dépôt du projet.

# Architecture AETHER — étape v0.3.0

- `app`: application Android native Kotlin / Jetpack Compose.
- `MemoryStore`: persistance locale de souvenirs dans le stockage privé Android.
- `MemoryScreen`: interface CRUD et recherche de la mémoire centrale.
- `morph`: à développer pour les spécifications, modèles et tests d'outils.
- `voice`: à développer après validation des contraintes Android de premier plan et de confidentialité.
- `connectors`: à développer pour les services en ligne optionnels.

## Règles de conception
Fonctionnement local quand c'est possible, permissions minimales, transparence sur les données, validation explicite des actions sensibles et distinction claire entre fonctionnalités disponibles et prévues.

## État de la mémoire (v0.3.0)
La mémoire accepte la création, la lecture, la modification, la suppression et la recherche de notes structurées. Les données persistent localement après fermeture de l'application. Le stockage n'est pas encore chiffré ; le chiffrement et une stratégie de sauvegarde feront l'objet d'une étape distincte avant d'y placer des informations sensibles.

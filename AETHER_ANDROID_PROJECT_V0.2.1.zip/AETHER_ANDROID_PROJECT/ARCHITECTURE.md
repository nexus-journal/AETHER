# Architecture AETHER 1.0.0

## Couches

- **Interface Compose** : `MainActivity.kt`, `AssistantScreen.kt`, `MemoryScreen.kt`, `MorphScreen.kt`, `AiSettingsCard.kt`.
- **Routage local** : `AssistantCore.kt` interprète un ensemble explicite de commandes déterministes et prépare des actions typées.
- **Exécution Android** : `executeAssistantAction` ne traite que les actions autorisées et n'est appelée qu'après confirmation depuis l'interface.
- **IA distante facultative** : `AetherAi.kt` envoie l'historique récent et un sous-ensemble de souvenirs pertinents au fournisseur choisi.
- **Stockage local** : `MemoryStore`, `TaskStore`, `ConversationStore`, `MorphToolStore` et `MorphRoutineStore` utilisent les préférences privées de l'application.
- **Secrets** : `ApiKeyVault` chiffre la clé API avec AES/GCM et Android Keystore.

## Séquence d'une demande

1. L'utilisateur envoie une commande.
2. `AssistantEngine` tente de la traiter localement.
3. Si la commande dépasse les règles locales et qu'une clé est configurée, `AetherAiClient` consulte le modèle externe avec contexte limité.
4. Le modèle ne peut proposer qu'une action parmi la liste fermée définie dans le prompt et validée à nouveau par le parseur.
5. Une action externe est affichée dans une carte de confirmation ; elle n'est lancée qu'après l'appui de l'utilisateur.

## Routines MORPH

Les routines contiennent de 2 à 8 commandes AETHER. Elles sont conservées localement et soumises à l'assistant une étape à la fois. Ce choix évite qu'une routine déclenche automatiquement une série d'actions externes sans contrôle intermédiaire.

## Confidentialité et limites

- Les souvenirs, tâches, raccourcis, routines et conversations sont stockés sur l'appareil.
- Lorsqu'une IA distante est utilisée, les échanges récents et les souvenirs sélectionnés sont transmis au fournisseur configuré.
- Les clés API sont chiffrées sur l'appareil, mais l'usage d'une clé dans une application distribuée n'est pas équivalent à un backend privé.
- L'application n'embarque pas de moteur IA local, de service cloud, de synchronisation, de surveillance permanente ou d'exécution de code arbitraire.
- La disponibilité des applications Android dépend des paquets installés et de la visibilité autorisée par Android.

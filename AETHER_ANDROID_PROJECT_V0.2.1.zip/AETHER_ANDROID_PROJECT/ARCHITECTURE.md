# Architecture AETHER 0.5.0

## Application Android
- `MainActivity.kt` : navigation principale, accueil et réglages.
- `AssistantScreen.kt` : conversation, dictée, lecture vocale, liste de tâches et confirmation des actions.
- `AssistantCore.kt` : moteur de commandes déterministe, modèles d'actions Android, stockage des tâches et outils MORPH.
- `MemoryScreen.kt` : interface de gestion de la mémoire personnelle.
- `MemoryStore.kt` : stockage local JSON de la mémoire, avec favoris et import/export.
- `MorphScreen.kt` : création et lancement de raccourcis utilisateur.

## Principes
1. Local en priorité : les mémoires, tâches et outils restent dans l'espace privé de l'application.
2. Contrôle utilisateur : les actions externes sont proposées puis lancées uniquement après un appui explicite.
3. Permissions minimales : les actions sont déléguées aux applications Android via des intents ; l'application ne lit pas les contacts, SMS ou journaux d'appels.
4. Transparence : l'interface distingue les fonctions présentes de celles qui nécessitent encore un moteur IA ou des services connectés.

## Capacités du noyau
- Réponses locales pour les commandes explicitement reconnues.
- Mémorisation et consultation de souvenirs.
- Gestion manuelle de tâches.
- Raccourcis MORPH composés d'un nom et d'une commande AETHER.
- Délégation d'actions au navigateur, à Maps, Horloge, Calendrier, composeur, SMS, menu de partage et paramètres Android.
- Entrée vocale via `RecognizerIntent`, sortie vocale via Android TextToSpeech.

## Non inclus / prochaine architecture
- Modèle d'IA générative et gestion sécurisée de clé/API.
- Analyse sémantique d'images et de documents.
- Indexation et vérification de sources avec citations.
- Notifications et rappels planifiés fiables.
- Synchronisation chiffrée et sauvegarde cloud.
- Automatisations multi-étapes avec permissions fines et journal d'exécution.
- Exécution de code ou génération de modules Android par MORPH.

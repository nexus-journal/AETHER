# Architecture AETHER 0.6.0

## Application Android
- `MainActivity.kt` : navigation, accueil, réglages et injection des stores.
- `AssistantScreen.kt` : conversation, historique, dictée, synthèse vocale, état de réflexion et confirmation d'actions.
- `AssistantCore.kt` : commandes locales, tâches, MORPH et exécution contrôlée des intents Android.
- `AetherAi.kt` : configuration du fournisseur, chiffrement de clé par Android Keystore, historique local, sélection de souvenirs pertinents, appels REST Gemini et OpenAI-compatible, validation des actions JSON.
- `AiSettingsCard.kt` : configuration du fournisseur, modèle, endpoint et clé API.
- `MemoryScreen.kt` / `MemoryStore.kt` : gestion de la mémoire locale.
- `MorphScreen.kt` : interface MORPH.

## Flux d'une demande
1. L'utilisateur envoie un message ou utilise la dictée Android.
2. Le routeur local traite les commandes déterministes connues (heure, mémoire explicite, tâches, alarme, SMS, etc.).
3. Pour une demande libre, l'application vérifie la configuration IA.
4. Le client construit un contexte borné à partir des 14 derniers messages, de 6 souvenirs pertinents au maximum et des tâches ouvertes.
5. La requête part vers Gemini `generateContent` ou un endpoint OpenAI-compatible.
6. La sortie est analysée comme JSON ; toute action doit appartenir à la liste autorisée et passer des validations locales.
7. Une action externe ou une écriture mémoire/tâche est présentée à l'utilisateur. Elle n'est exécutée qu'après confirmation.

## Sécurité
- Clé API chiffrée AES/GCM ; clé AES non exportable fournie par Android Keystore.
- Réseau limité à HTTPS dans les endpoints du fournisseur compatible ; `usesCleartextTraffic=false`.
- La clé API n'est jamais incluse dans l'archive du projet.
- La sortie du modèle est considérée comme non fiable : actions autorisées par liste blanche, validations de champs et confirmation utilisateur.
- Les actions d'appel et SMS délèguent à l'application système ; elles n'envoient aucun contenu directement.
- Les données personnelles envoyées au modèle sont limitées au contexte récent et aux souvenirs sélectionnés ; l'utilisateur est averti dans les réglages.

## Limites restantes
- Pas de serveur proxy pour protéger les clés d'une distribution à grande échelle.
- Pas de vision multimodale côté interface, d'écoute permanente, d'exécution d'actions en arrière-plan ni d'accès général aux autres applications.
- Pas de rappels planifiés ni de synchronisation cloud.
- MORPH reste un système de raccourcis, pas un compilateur de modules natifs.

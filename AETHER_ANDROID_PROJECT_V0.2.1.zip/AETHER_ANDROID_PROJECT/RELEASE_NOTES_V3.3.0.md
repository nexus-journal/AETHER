# AETHER Android — V3.3.0

## Voice Studio et style conversationnel

- Ajout de Voice Studio dans Réglages.
- Profils vocaux JARVIS, Naturel et Dynamique avec réglage de vitesse et de hauteur.
- Bouton d'aperçu vocal et raccourci vers les réglages de synthèse vocale Android.
- Le même profil TTS est utilisé dans la conversation et le mode mains libres.
- Personnalité conversationnelle réglable : JARVIS (posé, précis, courtois), Naturel ou Technique.
- Test de connexion du fournisseur depuis l’écran IA avec une requête courte.
- Les réglages sont enregistrés localement dans les préférences de l'application.

## Limites et transparence

Le rendu dépend du moteur et des voix TTS installés sur le téléphone. Le profil JARVIS ajuste la vitesse et la hauteur et applique un style de conversation similaire dans l'esprit, mais ne reproduit ni ne clone exactement la voix originale du personnage ou celle d'un acteur.

## Version

- versionName : 3.3.0
- versionCode : 33

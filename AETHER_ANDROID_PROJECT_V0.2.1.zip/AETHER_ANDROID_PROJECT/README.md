# AETHER Android — V3.0.0

**AETHER** est un assistant Android personnel hybride : les commandes déterministes, souvenirs, tâches, raccourcis et routines sont gérés localement ; les conversations libres peuvent utiliser un fournisseur IA externe configuré par l'utilisateur.

## Nouveautés V3.0.0

- **Mode mains libres expérimental** : un service au premier plan peut écouter volontairement le mot d'appel « AETHER », répondre par synthèse vocale, puis reprendre l'écoute. Après activation depuis Réglages, il peut continuer lorsque l'application est quittée et lorsque l'écran est verrouillé, tant qu'Android conserve le service actif.
- **Contrôle visible** : autorisations microphone et notifications demandées avant activation ; notification persistante avec bouton d'arrêt ; aucune activation automatique au démarrage du téléphone.
- **Reconnaissance locale privilégiée** : AETHER choisit le moteur de reconnaissance local si Android en signale un. Sinon il utilise le service vocal Android installé, qui peut traiter l'audio selon ses propres règles. `EXTRA_PREFER_OFFLINE` est une préférence, pas une garantie de fonctionnement hors ligne.
- **Sécurité des actions vocales** : la voix peut consulter les fonctions locales et dialoguer avec le modèle IA configuré, mais une action externe proposée doit être confirmée dans l'application.
- **Gestion batterie** : le mode garde le processeur éveillé pendant l'écoute pour améliorer la continuité écran éteint ; cela peut augmenter sensiblement la consommation. Arrête le mode depuis la notification lorsque tu n'en as plus besoin.

## Nouveautés V2.0.0 (conservées)

- **Briefing personnel local** : demande « Briefing du jour » pour obtenir l'heure et la date locales, les tâches en attente, les tâches terminées et un aperçu de la mémoire. Fonctionne sans clé API ni connexion.
- **Sauvegarde complète** : export au format JSON des souvenirs, tâches, conversations, outils MORPH et routines.
- **Restauration JSON** : sélection d'un fichier depuis le téléphone, validation du format et aperçu du contenu avant confirmation. La restauration remplace les collections sauvegardées ; les paramètres IA, clés API et journal d'actions restent sur l'appareil.
- **Validation renforcée** : taille maximale de fichier, limites par collection, validation des entrées et analyse complète avant toute écriture.

## Fonctionnalités conservées

- **Assistant conversationnel** : commandes locales, historique de conversation sur l'appareil, réponses vocales facultatives et dictée via le service de reconnaissance vocale Android.
- **IA configurable** : Gemini ou API compatible OpenAI. Des préréglages sont proposés pour OpenRouter, Groq et Mistral ; le modèle exact doit être vérifié auprès du fournisseur et reste modifiable.
- **Clé API** : chiffrement AES/GCM avec une clé conservée dans Android Keystore. Une clé utilisée dans une application mobile n'est jamais aussi isolée qu'une clé conservée sur un serveur privé.
- **Mémoire personnelle** : création, recherche, favoris, catégories et export/import via sauvegarde.
- **Tâches** : liste locale, ajout et suivi.
- **Actions Android confirmées** : recherche Web, carte, alarme via Horloge, événement via Calendrier, composeur téléphonique, SMS prérempli, partage, paramètres et ouverture d'applications prises en charge.
- **MORPH Studio** : raccourcis AETHER personnalisés et routines guidées de 2 à 8 étapes.
- **Agent planificateur** : proposition IA de plans complexes (2 à 8 étapes), avec lancement manuel de chaque étape et enregistrement possible dans MORPH.
- **Journal d’actions** : historique local minimaliste des actions confirmées ou annulées, sans contenu de SMS, numéro ni URL complète.
- **État de l’appareil** : consultation locale du niveau de batterie et de l’état de charge.
- **Interface** : tableau de bord sombre et navigation adaptée au mobile.

## Limites importantes

- Le mode mains libres V3 est expérimental : il s'appuie sur `SpeechRecognizer` et des sessions de reconnaissance répétées, pas sur un détecteur de mot-clé matériel dédié à très faible consommation. Le délai, la précision du mot « AETHER » et le fonctionnement écran verrouillé dépendent du fournisseur vocal, du modèle français installé, de Samsung/Android et des politiques de batterie.
- Le service doit être activé pendant qu'AETHER est visible et que les autorisations sont accordées. Il ne redémarre pas automatiquement après un redémarrage, un arrêt forcé ou la fermeture par le système. Android peut arrêter le service.
- Lorsque le moteur local n'est pas disponible, le fournisseur vocal installé peut recevoir l'audio. Consulte ses paramètres et ses règles de confidentialité avant d'activer le mode.

- La qualité des conversations libres dépend du modèle choisi, de sa disponibilité, des quotas, de la connexion Internet et de la clé API configurée. Aucun modèle externe n'est inclus dans l'APK.
- Les offres gratuites, les identifiants de modèles et les conditions d'utilisation des fournisseurs peuvent changer. AETHER ne garantit pas un accès gratuit permanent.
- Les actions Android passent par les interfaces et applications Android disponibles. AETHER ne contourne pas les permissions, ne lit pas les contenus privés d'autres applications et n'exécute pas de commandes système arbitraires.
- MORPH crée des raccourcis et des routines guidées ; il n'exécute pas du code arbitraire ni des modules téléchargés.
- La dictée et la synthèse vocale dépendent des services vocaux installés sur le téléphone.
- Les données mémoire, tâches, routines et conversations sont stockées localement dans les préférences privées de l'application. La désinstallation peut les supprimer. Les sauvegardes JSON peuvent contenir des données personnelles : conserve-les dans un emplacement sûr.

## Construction de l'APK

Le dépôt GitHub utilise GitHub Actions pour construire l'APK debug à partir de l'archive `AETHER_ANDROID_PROJECT_V0.2.1.zip`.

1. Remplacer l'archive existante à la racine du dépôt par le ZIP de cette version, sans la décompresser ni la renommer.
2. Valider l'envoi sur la branche `main`.
3. Ouvrir l'onglet **Actions** et vérifier que le workflow **AETHER Android Build** termine en vert.
4. Télécharger l'artefact **AETHER-debug-APK** généré par cette exécution.

Projet Gradle : `AETHER_ANDROID_PROJECT/`  
Application : `app/`  
Namespace : `com.aether.assistant`  
Version : `3.0.0` (versionCode 30)  
JDK : 17  
SDK : compileSdk 36  
Gradle attendu par le workflow : 8.13

## Vérifications locales

L'archive et les contrôles statiques doivent être validés avant publication. La compilation Android complète reste à confirmer par le workflow GitHub Actions du dépôt.

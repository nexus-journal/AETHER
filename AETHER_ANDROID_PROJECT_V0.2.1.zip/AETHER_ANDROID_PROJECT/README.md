# AETHER Android — v0.3.0

Première version fonctionnelle du module **Mémoire centrale** dans l’application Android native Kotlin / Jetpack Compose.

## Nouveautés v0.3.0
- Création de souvenirs avec titre, catégorie et contenu.
- Consultation de la liste, recherche dans les titres / catégories / contenus.
- Modification et suppression des souvenirs.
- Persistance locale entre les ouvertures de l’application via le stockage privé Android (`SharedPreferences`).
- Fonctionnement hors ligne, sans compte et sans connexion réseau.

## Confidentialité et limites
- Les données sont stockées dans l’espace privé de l’application sur l’appareil.
- **Le stockage n’est pas encore chiffré** dans cette version. Ne pas y enregistrer de mots de passe, codes, données bancaires ou informations très sensibles.
- Il n’y a pas encore de synchronisation entre appareils, sauvegarde cloud, mémoire automatique de conversation ni recherche sémantique par IA.
- La suppression des données de l’application ou sa désinstallation peut supprimer les souvenirs locaux. Aucune sauvegarde externe n’est encore prévue.

## Base technique
- Android Gradle Plugin 8.13.2
- Kotlin 2.2.21
- Jetpack Compose BOM 2025.10.00
- JDK 17 / Android SDK 36
- Package `com.aether.assistant`, min SDK 26

## Compilation
Lancer `:app:assembleDebug` dans Android Studio ou via le workflow GitHub Actions du dépôt.

# AETHER — Assistant personnel Android

**Version : 0.6.0**  
Application Android native Kotlin + Jetpack Compose. Le nom de l'archive reste `AETHER_ANDROID_PROJECT_V0.2.1.zip` pour rester compatible avec le workflow GitHub Actions existant.

## Ce qui est inclus

- **Conversation IA configurable** : Gemini REST (modèle par défaut `gemini-3.8-flash`) ou fournisseur compatible avec l'API OpenAI Chat Completions.
- **Historique conversationnel local** : conservation des 80 derniers messages et transmission des 14 derniers tours au modèle.
- **Contexte personnel sélectif** : AETHER choisit jusqu'à 6 souvenirs pertinents et transmet les tâches en attente pertinentes au modèle.
- **Protection de clé API au repos** : chiffrement AES/GCM avec une clé non exportable stockée par Android Keystore. La clé n'est pas écrite dans le code source ni dans l'archive.
- **Actions assistées** : le modèle peut proposer une recherche Web, une carte, une alarme, un événement calendrier, l'ouverture de quelques applications, le partage d'un texte, l'ajout d'une tâche ou l'enregistrement d'un souvenir. Les actions restent à confirmer par l'utilisateur.
- **Actions sensibles encadrées** : appels et SMS ne font qu'ouvrir les applications système préremplies ; aucun appel ou message n'est envoyé automatiquement.
- **Mémoire personnelle** : gestion, favoris, recherche, catégories, import et export JSON.
- **Tâches locales** : ajout, consultation, validation et suppression.
- **MORPH Studio** : création et lancement de raccourcis personnels.
- **Voix** : dictée via le service Android disponible et synthèse vocale des réponses.

## Configuration IA

Ouvrir **Réglages → Intelligence conversationnelle**.

### Gemini
- Fournisseur : Gemini
- Modèle par défaut : `gemini-3.8-flash`
- Clé API : clé personnelle compatible avec Gemini Developer API

### Fournisseur compatible OpenAI
- Fournisseur : API compatible
- Adresse par défaut : `https://openrouter.ai/api/v1`
- Modèle par défaut : `openrouter/free`
- La base URL et le modèle peuvent être changés pour un fournisseur compatible, par exemple Groq.

Le palier gratuit de Gemini 3.8 Flash propose actuellement des entrées et sorties gratuites, avec des limites et une disponibilité susceptibles d'évoluer. Google indique que les contenus envoyés au palier gratuit peuvent être utilisés pour améliorer ses produits. OpenRouter propose également un routeur de modèles gratuits (`openrouter/free`), soumis aux limites propres au service et aux modèles disponibles. Une offre gratuite ne garantit pas un accès illimité. Vérifier les conditions de confidentialité, d'âge et d'utilisation du fournisseur.

## Confidentialité et sécurité

- La clé API est chiffrée localement par AES/GCM et Android Keystore.
- Les conversations sont conservées dans l'espace privé de l'application. Les souvenirs et les tâches locaux sont également dans les préférences privées, mais ne sont pas chiffrés individuellement dans cette version.
- Les messages récents et les souvenirs sélectionnés peuvent être envoyés au fournisseur IA configuré. Ne pas y envoyer de mots de passe, codes, informations bancaires ou données sensibles. Les conditions de traitement des données du fournisseur s'appliquent.
- Le stockage chiffré de la clé ne rend pas une clé API intégrée à une application mobile inviolable. Pour une distribution publique, utiliser un serveur intermédiaire avec authentification et limites d'usage plutôt qu'une clé partagée dans chaque APK.
- Les actions IA sont limitées à une liste autorisée et demandent une confirmation. L'application ne dispose pas d'un contrôle complet du système Android et ne peut pas agir dans toutes les applications.
- Aucune permission de lecture des SMS, contacts, appels ou notifications n'est demandée.

## Limites connues

- La conversation IA nécessite une connexion Internet et une clé API valide. Sans clé, les commandes locales continuent de fonctionner.
- La compréhension et la qualité des réponses dépendent du modèle choisi, des quotas et de la connexion. Cette version ne garantit pas une intelligence identique à ChatGPT.
- La vision (analyse de l'écran ou d'images), l'écoute permanente, les automatisations arbitraires, la synchronisation cloud et la création de modules Android compilables par MORPH ne sont pas incluses.
- Les rappels de tâches ne déclenchent pas encore de notifications horaires.
- Les noms d'applications ouverts par l'action APP sont limités à YouTube, Spotify, Maps, Chrome, Camera et Gallery ; l'application doit être installée.

## Compilation

Le projet Gradle est dans `AETHER_ANDROID_PROJECT/`. Le workflow GitHub Actions utilise Java 17, Android SDK 36 et Gradle 8.13 pour produire l'APK debug.

# AETHER Android — v0.2.1

Base Android native AETHER, construite avec Kotlin et Jetpack Compose.

## Correction technique
- Compose BOM fixé à `2025.10.00` pour rester compatible avec Android Gradle Plugin `8.13.2` et `compileSdk 36`.
- Version Android : `0.2.1` (versionCode 2).
- JDK 17 et SDK Android 36.

## Contenu actuel
- Interface sombre AETHER.
- Navigation Accueil / Modules / Laboratoire / Réglages.
- Structure de démonstration de MORPH et des modules envisagés.

## Limites
Cette version reste une base d'interface. La mémoire persistante, la reconnaissance vocale, les modèles locaux, la vision, les connexions réseau et les automatisations ne sont pas encore implémentés. Les fonctions indiquées « PRÉVU » ne sont pas actives.

## Compilation
Ouvrir ce dossier dans Android Studio avec JDK 17 et Android SDK 36, puis lancer `:app:assembleDebug`.

## Package
`com.aether.assistant` — version `0.2.1` — min SDK 26.

# AETHER — Assistant personnel Android

**Version de l'application : 0.5.0**  
Projet Android natif Kotlin + Jetpack Compose. Le nom de l'archive reste `AETHER_ANDROID_PROJECT_V0.2.1.zip` afin de rester compatible avec le workflow GitHub Actions déjà configuré dans le dépôt.

## Fonctions disponibles

- **Assistant local** : commandes simples en français (heure, date, aide, mémoire et tâches) avec réponses déterministes.
- **Mémoire centrale** : création, modification, suppression, recherche, catégories, favoris, import et export JSON.
- **Tâches** : ajout, consultation, validation et suppression ; stockage local sur l'appareil.
- **MORPH Studio** : création de raccourcis personnels qui transmettent une commande à l'assistant.
- **Voix** : dictée via le service de reconnaissance vocale disponible sur le téléphone et lecture des réponses via Android Text-to-Speech.
- **Actions Android sous confirmation** : recherche Web, cartes, réglage d'alarme, ouverture du calendrier, composeur téléphonique, préparation d'un SMS, partage de texte, ouverture d'URL et paramètres Android.

## Limites importantes

Cette version fournit un noyau fonctionnel, pas encore un JARVIS doté d'une intelligence générale. L'assistant local utilise un ensemble de commandes reconnues et ne génère pas de raisonnement libre. L'IA générative, la vision (analyse réelle d'images), la recherche documentaire approfondie, les intégrations de comptes, la synchronisation cloud, les automatisations en arrière-plan et la création de véritables modules Android par MORPH ne sont pas connectées.

Les actions téléphoniques ouvrent le composeur ou l'application SMS : AETHER ne passe pas directement d'appel et n'envoie pas de message. Les événements et alarmes sont ouverts dans les applications Android correspondantes et doivent être vérifiés par l'utilisateur. Les rappels de tâches sont des éléments de liste ; ils ne déclenchent pas encore de notification horaire.

La dictée et la synthèse vocale dépendent des services configurés sur l'appareil ; leur disponibilité hors ligne n'est pas garantie.

## Confidentialité

Les souvenirs, tâches et raccourcis MORPH sont conservés dans les préférences privées de l'application, sans compte ni synchronisation réseau. Ce stockage n'est pas chiffré dans cette version. Ne pas y enregistrer de mots de passe, codes ou informations très sensibles. Aucune permission d'accès aux contacts, SMS, appels ou fichiers personnels n'est demandée.

## Compilation

Le dépôt fournit le projet Gradle dans `AETHER_ANDROID_PROJECT/`. Le workflow GitHub Actions utilise Java 17, Android SDK 36 et Gradle 8.13 pour produire l'APK debug.

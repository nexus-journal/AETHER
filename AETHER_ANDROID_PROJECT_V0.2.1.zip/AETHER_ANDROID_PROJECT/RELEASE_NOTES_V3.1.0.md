# AETHER Android — V3.1.0

## Nouvelle livraison : registre de compétences MORPH

- Ajout d'un onglet **Compétences** dans MORPH Studio.
- Catalogue de commandes préconfigurées pour le briefing personnel, les tâches, la mémoire, l'état du téléphone, la date et l'heure, la calculatrice, la recherche Web, la navigation, les alarmes, le calendrier et la planification IA.
- Chaque compétence lance le moteur conversationnel existant : les commandes locales restent locales ; les actions externes conservent leur écran de confirmation ; les demandes libres nécessitent le fournisseur IA configuré.
- Le registre est également décrit dans le contexte système transmis au fournisseur IA afin que l'assistant connaisse les modules présents.
- Aucun téléchargement ni exécution de code arbitraire n'est effectué par le registre.

## Fonctions conservées de la V3.0.0

- Mémoire personnelle locale, catégories, favoris, recherche, modification et suppression.
- Tâches locales et briefing personnel.
- MORPH Studio : outils personnels et routines guidées de 2 à 8 commandes.
- Planification IA sous forme d'étapes proposées, à lancer une par une.
- Actions Android via les interfaces autorisées, toujours sous confirmation.
- Fournisseur IA Gemini ou API compatible OpenAI, clé chiffrée via Android Keystore.
- Conversation locale persistante, dictée et synthèse vocale Android.
- Mode mains libres expérimental, activé volontairement avec notification persistante et commande d'arrêt.
- Export et restauration JSON des données locales (sans clé API ni journal d'actions).
- Journal local des actions sans conserver les contenus sensibles des SMS, numéros ni URL complètes.

## Limites à connaître

- Le mode mains libres repose sur des sessions de reconnaissance vocale Android répétées. Ce n'est pas un détecteur de mot-clé matériel à faible consommation ; précision, disponibilité écran verrouillé et autonomie dépendent du téléphone et du service vocal installé.
- La conversation libre et les plans IA nécessitent une clé API et un fournisseur disponible. Aucun modèle IA n'est embarqué dans l'application.
- Les compétences du registre sont des commandes préconfigurées vers des fonctions intégrées ; elles ne téléchargent pas de nouveaux modules exécutables.
- Les actions Android restent limitées aux intents et applications explicitement pris en charge par le projet.

package com.aether.assistant

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale
import java.util.UUID

private val AssistantBg = Color(0xFF07111F)
private val AssistantPanel = Color(0xFF101F31)
private val AssistantRaised = Color(0xFF152940)
private val AssistantCyan = Color(0xFF62D9F5)
private val AssistantText = Color(0xFFEAF4FC)
private val AssistantMuted = Color(0xFF91A7BC)
private val AssistantRed = Color(0xFFFF9B9B)

private data class ChatMessage(
    val id: String = UUID.randomUUID().toString(),
    val fromUser: Boolean,
    val text: String,
    val action: AssistantAction? = null,
    val actionDone: Boolean = false
)

@Composable
fun AssistantScreen(
    modifier: Modifier = Modifier,
    memoryStore: MemoryStore,
    taskStore: TaskStore,
    aiSettingsStore: AiSettingsStore,
    conversationStore: ConversationStore,
    routineStore: MorphRoutineStore,
    actionHistoryStore: ActionHistoryStore,
    experienceStore: ExperiencePreferencesStore,
    prefillCommand: String?,
    onPrefillConsumed: () -> Unit,
    prefillRoutine: List<String>?,
    onRoutineConsumed: () -> Unit,
    onExecuteAction: (AssistantAction) -> Boolean
) {
    val context = LocalContext.current
    var activeView by remember { mutableStateOf("Conversation") }
    var input by remember { mutableStateOf("") }
    var speakReplies by remember(experienceStore) { mutableStateOf(experienceStore.load().voiceRepliesEnabled) }
    var isThinking by remember { mutableStateOf(false) }
    val messages = remember(conversationStore) {
        val saved = conversationStore.loadAll().takeLast(60)
        mutableStateListOf<ChatMessage>().apply {
            if (saved.isEmpty()) {
                add(ChatMessage(fromUser = false, text = "AETHER est prêt. Configure un fournisseur IA dans Réglages pour activer les conversations libres. Tes tâches, souvenirs et actions locales restent disponibles."))
            } else {
                saved.forEach { add(ChatMessage(fromUser = it.role == "user", text = it.text)) }
            }
        }
    }
    val listState = rememberLazyListState()
    val routineCommands = remember { mutableStateListOf<String>() }
    var routineIndex by remember { mutableIntStateOf(0) }
    var routineSaved by remember { mutableStateOf(false) }
    val aiClient = remember { AetherAiClient() }
    var textToSpeech by remember { mutableStateOf<TextToSpeech?>(null) }
    var ttsReady by remember { mutableStateOf(false) }

    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status -> ttsReady = status == TextToSpeech.SUCCESS }
        textToSpeech = engine
        onDispose {
            engine.stop()
            engine.shutdown()
            textToSpeech = null
        }
    }

    fun speak(text: String) {
        if (speakReplies && ttsReady) {
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), "aether-${System.currentTimeMillis()}")
        }
    }

    fun addAssistantMessage(text: String, action: AssistantAction? = null) {
        messages.add(ChatMessage(fromUser = false, text = text, action = action))
        conversationStore.append("model", text)
        speak(text)
    }

    fun submitMessage(raw: String) {
        val clean = raw.trim()
        if (clean.isEmpty() || isThinking) return
        messages.add(ChatMessage(fromUser = true, text = clean))
        conversationStore.append("user", clean)
        val localReply = AssistantEngine.respond(clean, context, memoryStore, taskStore)
        input = ""
        if (localReply.handled) {
            addAssistantMessage(localReply.text, localReply.action)
            return
        }

        val configuration = aiSettingsStore.load()
        if (!configuration.isReady) {
            addAssistantMessage("Cette demande nécessite le moteur IA. Ouvre Réglages → Intelligence et configure une clé API. Les commandes locales restent disponibles sans connexion.")
            return
        }

        isThinking = true
        val loadingId = UUID.randomUUID().toString()
        messages.add(ChatMessage(id = loadingId, fromUser = false, text = "Je réfléchis à ta demande…"))
        val history = conversationStore.loadAll().takeLast(14)
        val memories = AetherAiClient.relevantMemories(clean, memoryStore.loadAll())
        val tasks = taskStore.loadAll()
        aiClient.ask(configuration, history, memories, tasks) { result ->
            val loadingIndex = messages.indexOfFirst { it.id == loadingId }
            if (loadingIndex >= 0) messages.removeAt(loadingIndex)
            isThinking = false
            val answer = result.getOrElse { error ->
                AssistantReply("Je n'ai pas réussi à joindre le moteur IA. ${error.message ?: "Vérifie ta connexion, ta clé et le quota du fournisseur."}")
            }
            addAssistantMessage(answer.text, answer.action)
            if (answer.planSteps.size in 2..8) {
                routineCommands.clear()
                routineCommands.addAll(answer.planSteps)
                routineIndex = 0
                routineSaved = false
            }
        }
    }

    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) submitMessage(spoken)
    }

    LaunchedEffect(prefillCommand) {
        val command = prefillCommand?.trim().orEmpty()
        if (command.isNotBlank()) {
            onPrefillConsumed()
            submitMessage(command)
            activeView = "Conversation"
        }
    }
    LaunchedEffect(prefillRoutine) {
        val commands = prefillRoutine.orEmpty().map { it.trim() }.filter { it.isNotBlank() }.take(8)
        if (commands.size >= 2) {
            routineCommands.clear()
            routineCommands.addAll(commands)
            routineIndex = 1
            routineSaved = false
            onRoutineConsumed()
            activeView = "Conversation"
            submitMessage(commands.first())
        }
    }
    LaunchedEffect(messages.size, activeView) {
        if (activeView == "Conversation" && messages.isNotEmpty()) listState.animateScrollToItem(messages.lastIndex)
    }

    Column(modifier.fillMaxSize().background(AssistantBg).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column {
                Text("AETHER · ASSISTANT", color = AssistantCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
                Text("Ton centre de commande personnel", color = AssistantText, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
            }
            Surface(color = AssistantRaised, shape = CircleShape, modifier = Modifier.clickable {
                val nextValue = !speakReplies
                speakReplies = nextValue
                experienceStore.save(experienceStore.load().copy(voiceRepliesEnabled = nextValue))
            }) {
                Text(if (speakReplies) "VOIX ON" else "VOIX OFF", modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp), color = AssistantCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Spacer(Modifier.height(13.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ViewPill("Conversation", activeView == "Conversation") { activeView = "Conversation" }
            ViewPill("Tâches", activeView == "Tâches") { activeView = "Tâches" }
        }
        Spacer(Modifier.height(11.dp))

        if (activeView == "Conversation" && routineCommands.isNotEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = AssistantRaised), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.fillMaxWidth().padding(11.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("ROUTINE GUIDÉE", color = AssistantCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.1.sp)
                    Text(if (routineIndex < routineCommands.size) "Étape ${routineIndex + 1}/${routineCommands.size} · ${routineCommands[routineIndex]}" else "Toutes les étapes ont été envoyées à l'assistant.", color = AssistantText, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (routineIndex < routineCommands.size) {
                            Button(onClick = { val next = routineCommands[routineIndex]; routineIndex += 1; submitMessage(next) }, enabled = !isThinking, colors = ButtonDefaults.buttonColors(containerColor = AssistantCyan, contentColor = AssistantBg)) { Text(if (routineIndex == 0) "Commencer" else "Étape suivante") }
                        } else {
                            Text("Plan terminé", color = AssistantCyan, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                        }
                        if (routineCommands.size >= 2) {
                            TextButton(
                                onClick = {
                                    routineSaved = routineStore.add("Plan AETHER ${java.text.SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE).format(java.util.Date())}", routineCommands.toList())
                                },
                                enabled = !routineSaved
                            ) { Text(if (routineSaved) "Enregistré" else "Enregistrer", color = AssistantCyan) }
                        }
                        TextButton(onClick = { routineCommands.clear(); routineIndex = 0; routineSaved = false }) { Text("Fermer", color = AssistantMuted) }
                    }
                }
            }
            Spacer(Modifier.height(2.dp))
        }

        if (activeView == "Conversation") {
            LazyColumn(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                state = listState,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { message ->
                    ChatBubble(
                        message = message,
                        onConfirm = {
                            val action = message.action
                            if (action != null) {
                                when (action.kind) {
                                    "TASK" -> {
                                        taskStore.add(action.first)
                                        actionHistoryStore.record(action, "Ajoutée localement")
                                        addAssistantMessage("C'est fait : la tâche « ${action.first} » a été ajoutée à ta liste locale.")
                                    }
                                    "MEMORY" -> {
                                        val now = System.currentTimeMillis()
                                        val title = action.first.take(54)
                                        memoryStore.saveAll(memoryStore.loadAll() + MemoryEntry(MemoryStore.newId(), title, action.first, "Ajout par AETHER", now, now))
                                        actionHistoryStore.record(action, "Enregistrée localement")
                                        addAssistantMessage("C'est enregistré dans ta mémoire locale : « $title ».")
                                    }
                                    else -> {
                                        val launched = onExecuteAction(action)
                                        actionHistoryStore.record(action, if (launched) "Transmise à Android" else "Échec de lancement")
                                        addAssistantMessage(if (launched) "L'action a été transmise à Android. Vérifie le résultat dans l'application ouverte." else "Android n'a pas pu lancer cette action. Vérifie que l'application nécessaire est installée et disponible.")
                                    }
                                }
                            }
                            val index = messages.indexOfFirst { it.id == message.id }
                            if (index >= 0) messages[index] = messages[index].copy(actionDone = true)
                        },
                        onCancel = {
                            message.action?.let { actionHistoryStore.record(it, "Annulée") }
                            val index = messages.indexOfFirst { it.id == message.id }
                            if (index >= 0) messages[index] = messages[index].copy(actionDone = true)
                        }
                    )
                }
            }
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(
                    onClick = {
                        try {
                            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "fr-FR")
                                putExtra(RecognizerIntent.EXTRA_PROMPT, "Parle à AETHER")
                            }
                            speechLauncher.launch(intent)
                        } catch (_: Exception) {
                            messages.add(ChatMessage(fromUser = false, text = "La reconnaissance vocale n'est pas disponible sur cet appareil. Tu peux toujours écrire ta demande."))
                        }
                    }, modifier = Modifier.size(52.dp), shape = RoundedCornerShape(15.dp)
                ) { Text("🎙", fontSize = 18.sp) }
                OutlinedTextField(
                    value = input,
                    onValueChange = { input = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Écris une commande…", color = AssistantMuted) },
                    maxLines = 3,
                    shape = RoundedCornerShape(15.dp)
                )
                Button(
                    onClick = { submitMessage(input) },
                    enabled = input.isNotBlank() && !isThinking,
                    modifier = Modifier.size(52.dp),
                    shape = RoundedCornerShape(15.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AssistantCyan, contentColor = AssistantBg)
                ) { Text("➤", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
            }
            Text(if (isThinking) "AETHER analyse ta demande…" else "IA connectée si configurée · actions externes soumises à confirmation", color = AssistantMuted, fontSize = 9.sp, modifier = Modifier.padding(top = 7.dp))
        } else {
            TaskList(modifier = Modifier.weight(1f), store = taskStore)
        }
    }
}

@Composable
private fun ViewPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(color = if (selected) AssistantRaised else AssistantPanel, shape = RoundedCornerShape(50), modifier = Modifier.clickable(onClick = onClick)) {
        Text(label, modifier = Modifier.padding(horizontal = 15.dp, vertical = 9.dp), color = if (selected) AssistantCyan else AssistantMuted, fontSize = 12.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
    }
}

@Composable
private fun ChatBubble(message: ChatMessage, onConfirm: () -> Unit, onCancel: () -> Unit) {
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (message.fromUser) Alignment.End else Alignment.Start) {
        Surface(
            color = if (message.fromUser) AssistantRaised else AssistantPanel,
            shape = RoundedCornerShape(18.dp)
        ) {
            Column(Modifier.fillMaxWidth(0.94f).padding(13.dp)) {
                Text(if (message.fromUser) "TOI" else "AETHER", color = if (message.fromUser) AssistantMuted else AssistantCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(Modifier.height(5.dp))
                Text(message.text, color = AssistantText, fontSize = 13.sp)
                if (message.action != null) {
                    Spacer(Modifier.height(10.dp))
                    Surface(color = AssistantRaised, shape = RoundedCornerShape(12.dp)) {
                        Column(Modifier.fillMaxWidth().padding(11.dp)) {
                            Text("ACTION À CONFIRMER", color = AssistantCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Text(actionLabel(message.action), color = AssistantText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 4.dp))
                            if (message.actionDone) {
                                Text("Action traitée ou annulée.", color = AssistantMuted, fontSize = 10.sp, modifier = Modifier.padding(top = 7.dp))
                            } else {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 7.dp)) {
                                    Button(onClick = onConfirm, colors = ButtonDefaults.buttonColors(containerColor = AssistantCyan, contentColor = AssistantBg)) { Text("Continuer", fontSize = 11.sp) }
                                    TextButton(onClick = onCancel) { Text("Annuler", color = AssistantMuted, fontSize = 11.sp) }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun actionLabel(action: AssistantAction): String = when (action.kind) {
    "WEB" -> "Recherche Web : ${action.first}"
    "MAP" -> "Ouvrir la carte : ${action.first}"
    "ALARM" -> "Créer une alarme à %02d:%02d".format(action.first.toIntOrNull() ?: 0, action.second.toIntOrNull() ?: 0)
    "DIAL" -> "Ouvrir le composeur : ${action.first}"
    "SMS" -> "Préparer un SMS pour ${action.first}"
    "CALENDAR" -> "Créer un événement : ${action.first}"
    "SETTINGS" -> "Ouvrir les paramètres Android"
    "SHARE" -> "Ouvrir le menu de partage"
    "URL" -> "Ouvrir ${action.first}"
    "APP" -> "Ouvrir ${when (action.first.lowercase()) { "youtube" -> "YouTube"; "spotify" -> "Spotify"; "maps" -> "Google Maps"; "chrome" -> "Chrome"; "camera" -> "l'appareil photo"; "gallery" -> "la galerie"; "gmail" -> "Gmail"; "whatsapp" -> "WhatsApp"; "messages" -> "Messages"; "calendar" -> "Calendrier"; "clock" -> "Horloge"; "files" -> "Fichiers"; "calculator" -> "Calculatrice"; else -> "l'application" }}"
    "TASK" -> "Ajouter à tes tâches : ${action.first}"
    "MEMORY" -> "Enregistrer dans ta mémoire : ${action.first.take(100)}"
    else -> "Action Android"
}

@Composable
private fun TaskList(modifier: Modifier, store: TaskStore) {
    val tasks = remember(store) { mutableStateListOf<TaskEntry>().apply { addAll(store.loadAll()) } }
    var newTask by remember { mutableStateOf("") }
    var taskQuery by remember { mutableStateOf("") }
    var showCompleted by remember { mutableStateOf(false) }
    val visible = tasks.filter { it.done == showCompleted && (taskQuery.isBlank() || it.title.contains(taskQuery.trim(), true)) }

    Column(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("ORGANISATION PERSONNELLE", color = AssistantCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Text("Mes tâches", color = AssistantText, fontSize = 21.sp, fontWeight = FontWeight.SemiBold)
        Text("Liste enregistrée localement sur cet appareil.", color = AssistantMuted, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(value = newTask, onValueChange = { newTask = it }, modifier = Modifier.weight(1f), singleLine = true, placeholder = { Text("Nouvelle tâche…") })
            Button(onClick = { if (newTask.isNotBlank()) { store.add(newTask); tasks.clear(); tasks.addAll(store.loadAll()); newTask = "" } }, enabled = newTask.isNotBlank(), colors = ButtonDefaults.buttonColors(containerColor = AssistantCyan, contentColor = AssistantBg)) { Text("Ajouter") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            ViewPill("En attente", !showCompleted) { showCompleted = false }
            ViewPill("Terminées", showCompleted) { showCompleted = true }
        }
        OutlinedTextField(
            value = taskQuery,
            onValueChange = { taskQuery = it.take(80) },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            placeholder = { Text("Filtrer les tâches…") }
        )
        if (visible.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = AssistantPanel), shape = RoundedCornerShape(16.dp)) {
                Text(if (showCompleted) "Aucune tâche terminée." else "Aucune tâche en attente. Ajoute une première tâche ou demande-le à AETHER.", color = AssistantMuted, fontSize = 13.sp, modifier = Modifier.padding(17.dp))
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(visible, key = { it.id }) { task ->
                    Card(colors = CardDefaults.cardColors(containerColor = AssistantPanel), shape = RoundedCornerShape(15.dp)) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 11.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = task.done, onCheckedChange = { checked -> store.setDone(task.id, checked); tasks.clear(); tasks.addAll(store.loadAll()) })
                            Text(task.title, color = if (task.done) AssistantMuted else AssistantText, fontSize = 13.sp, modifier = Modifier.weight(1f))
                            TextButton(onClick = { store.delete(task.id); tasks.removeAll { it.id == task.id } }) { Text("×", color = AssistantRed, fontSize = 19.sp) }
                        }
                    }
                }
            }
        }
    }
}

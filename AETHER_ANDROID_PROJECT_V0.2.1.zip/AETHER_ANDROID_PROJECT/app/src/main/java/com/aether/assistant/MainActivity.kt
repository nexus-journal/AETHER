package com.aether.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF07111F)
private val Panel = Color(0xFF101F31)
private val PanelRaised = Color(0xFF152940)
private val Cyan = Color(0xFF62D9F5)
private val Muted = Color(0xFF91A7BC)
private val MainText = Color(0xFFEAF4FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan,
                onPrimary = Night,
                background = Night,
                surface = Panel,
                onSurface = MainText,
                secondary = Color(0xFF8BA9C7)
            )) { AetherApp() }
        }
    }
}

@Composable
private fun AetherApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val memoryStore = remember(context) { MemoryStore(context) }
    val taskStore = remember(context) { TaskStore(context) }
    val morphStore = remember(context) { MorphToolStore(context) }
    var selectedTab by remember { mutableIntStateOf(0) }
    var pendingCommand by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = MainText) {
                val labels = listOf("Accueil", "Assistant", "Mémoire", "MORPH", "Réglages")
                val marks = listOf("⌂", "◉", "▤", "✳", "⚙")
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Text(marks[index], fontSize = 19.sp) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Cyan,
                            selectedTextColor = Cyan,
                            indicatorColor = PanelRaised,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
            0 -> HomeScreen(
                modifier = Modifier.padding(innerPadding),
                memoryCount = memoryStore.loadAll().size,
                taskCount = taskStore.loadAll().count { !it.done },
                onCommand = { pendingCommand = it; selectedTab = 1 }
            )
            1 -> AssistantScreen(
                modifier = Modifier.padding(innerPadding),
                memoryStore = memoryStore,
                taskStore = taskStore,
                prefillCommand = pendingCommand,
                onPrefillConsumed = { pendingCommand = null },
                onExecuteAction = { executeAssistantAction(context, it) }
            )
            2 -> MemoryScreen(Modifier.padding(innerPadding), memoryStore)
            3 -> MorphScreen(Modifier.padding(innerPadding), morphStore, onRunTool = { pendingCommand = it; selectedTab = 1 })
            else -> SettingsScreen(Modifier.padding(innerPadding))
        }
    }
}

private data class Feature(
    val name: String,
    val detail: String,
    val status: String,
    val mark: String
)

private val features = listOf(
    Feature("Assistant local", "Commandes ciblées et conversation guidée", "ACTIF", "A"),
    Feature("Mémoire centrale", "Souvenirs, favoris, recherche et sauvegarde", "ACTIF", "M"),
    Feature("Tâches", "Liste locale, suivi et validation", "ACTIF", "T"),
    Feature("MORPH Studio", "Création de raccourcis personnels", "ACTIF", "✳"),
    Feature("Actions Android", "Web, carte, alarme, calendrier, appel et SMS", "ACTIF", "↗"),
    Feature("IA générative et vision", "Nécessitent un moteur IA et des services dédiés", "À CONNECTER", "◇")
)

@Composable
private fun HomeScreen(modifier: Modifier = Modifier, memoryCount: Int, taskCount: Int, onCommand: (String) -> Unit) {
    LazyColumn(modifier = modifier.fillMaxSize().padding(horizontal = 19.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column {
                    Text("AETHER", color = MainText, fontSize = 26.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                    Text("PERSONAL INTELLIGENCE", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
                }
                Surface(color = PanelRaised, shape = RoundedCornerShape(50)) {
                    Text("V0.5.0", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(23.dp)) {
                Column(Modifier.fillMaxWidth().padding(19.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(9.dp).background(Cyan, CircleShape))
                        Spacer(Modifier.width(9.dp))
                        Text("NOYAU LOCAL INITIALISÉ", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    }
                    Spacer(Modifier.height(13.dp))
                    Text("Bonjour.", color = MainText, fontSize = 29.sp, fontWeight = FontWeight.SemiBold)
                    Text("Ton assistant personnel, sous ton contrôle.", color = Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(15.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Metric("MÉMOIRES", memoryCount.toString(), Modifier.weight(1f))
                        Metric("TÂCHES", taskCount.toString(), Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(15.dp))
                    Button(onClick = { onCommand("aide") }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night), shape = RoundedCornerShape(13.dp)) {
                        Text("Ouvrir AETHER Assistant", fontWeight = FontWeight.Bold)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = { onCommand("Quelle heure est-il ?") }, modifier = Modifier.weight(1f)) { Text("Heure", color = Cyan) }
                        OutlinedButton(onClick = { onCommand("Mes tâches") }, modifier = Modifier.weight(1f)) { Text("Mes tâches", color = Cyan) }
                    }
                }
            }
        }
        item { SectionTitle("CAPACITÉS DU NOYAU", "Les fonctions réellement disponibles dans cette version") }
        items(features) { FeatureCard(it) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(17.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("UNE IA QUI RESTE TRANSPARENTE", color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                    Spacer(Modifier.height(7.dp))
                    Text("AETHER exécute localement ses commandes simples. Les actions vers d'autres applications demandent une confirmation. Le raisonnement génératif avancé n'est pas encore connecté.", color = MainText, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
private fun Metric(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(modifier, color = PanelRaised, shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, color = Muted, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            Text(value, color = MainText, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun FeatureCard(feature: Feature) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(17.dp)) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(40.dp)) {
                Box(contentAlignment = Alignment.Center) { Text(feature.mark, color = Cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(feature.name, color = MainText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(feature.detail, color = Muted, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Text(feature.status, color = if (feature.status == "ACTIF") Cyan else Color(0xFFFFC56B), fontSize = 8.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(19.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("RÉGLAGES", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Text("Contrôle et transparence", color = MainText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        SettingRow("Traitement", "Les commandes simples sont traitées localement, sans compte ni serveur.")
        SettingRow("Stockage", "Mémoire, tâches et outils MORPH sont enregistrés dans l'espace privé de l'application.")
        SettingRow("Données sensibles", "Le stockage local n'est pas chiffré dans cette version. Évite d'y enregistrer des mots de passe ou des informations très sensibles.")
        SettingRow("Actions externes", "AETHER ouvre les applications Android compatibles. Il ne passe pas d'appel et n'envoie pas de SMS sans intervention de ta part.")
        SettingRow("Voix", "La dictée et la synthèse vocale utilisent les services de reconnaissance et de synthèse disponibles sur ton appareil ; leur fonctionnement hors ligne dépend de ces services.")
        SettingRow("IA générative", "Non connectée : il faudra choisir un moteur IA et configurer une connexion sécurisée avant d'obtenir des réponses ouvertes, du raisonnement avancé ou une analyse d'images.")
        SettingRow("Version", "AETHER 0.5.0 — Assistant local, tâches, mémoire, MORPH et actions Android.")
    }
}

@Composable
private fun SettingRow(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(15.dp)) {
        Column(Modifier.fillMaxWidth().padding(14.dp)) {
            Text(title, color = MainText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}

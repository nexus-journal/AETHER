package com.aether.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Stockage privé local de la mémoire AETHER. Aucun accès réseau. */
class MemoryStore(context: Context) {
    private val preferences = context.applicationContext.getSharedPreferences(
        PREFERENCES_NAME,
        Context.MODE_PRIVATE
    )

    fun loadAll(): List<MemoryEntry> {
        val raw = preferences.getString(KEY_ENTRIES, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    val id = item.optString("id").takeIf { it.isNotBlank() } ?: continue
                    val title = item.optString("title").takeIf { it.isNotBlank() } ?: continue
                    add(
                        MemoryEntry(
                            id = id,
                            title = title,
                            content = item.optString("content"),
                            category = item.optString("category", "Général"),
                            createdAt = item.optLong("createdAt"),
                            updatedAt = item.optLong("updatedAt")
                        )
                    )
                }
            }.sortedByDescending { it.updatedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveAll(entries: List<MemoryEntry>) {
        val array = JSONArray()
        entries.forEach { entry ->
            array.put(
                JSONObject()
                    .put("id", entry.id)
                    .put("title", entry.title)
                    .put("content", entry.content)
                    .put("category", entry.category)
                    .put("createdAt", entry.createdAt)
                    .put("updatedAt", entry.updatedAt)
            )
        }
        // apply() met à jour la valeur en mémoire immédiatement et écrit sur disque en arrière-plan.
        preferences.edit().putString(KEY_ENTRIES, array.toString()).apply()
    }

    companion object {
        private const val PREFERENCES_NAME = "aether_local_memory"
        private const val KEY_ENTRIES = "entries_json"

        fun newId(): String = UUID.randomUUID().toString()
    }
}

data class MemoryEntry(
    val id: String,
    val title: String,
    val content: String,
    val category: String,
    val createdAt: Long,
    val updatedAt: Long
)

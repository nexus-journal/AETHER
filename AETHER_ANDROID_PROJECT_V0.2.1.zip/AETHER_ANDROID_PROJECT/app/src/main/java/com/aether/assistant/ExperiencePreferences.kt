package com.aether.assistant

import android.content.Context

/** Préférences d'expérience non sensibles, stockées localement sur l'appareil. */
data class ExperiencePreferences(
    val hapticsEnabled: Boolean = true,
    val voiceRepliesEnabled: Boolean = false,
    val compactDashboard: Boolean = false,
    val fontScale: Float = 1.0f
)

class ExperiencePreferencesStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aether_experience", Context.MODE_PRIVATE)

    fun load(): ExperiencePreferences = ExperiencePreferences(
        hapticsEnabled = prefs.getBoolean(KEY_HAPTICS, true),
        voiceRepliesEnabled = prefs.getBoolean(KEY_VOICE, false),
        compactDashboard = prefs.getBoolean(KEY_COMPACT, false),
        fontScale = prefs.getFloat(KEY_FONT_SCALE, 1.0f).coerceIn(0.85f, 1.20f)
    )

    fun save(value: ExperiencePreferences) {
        prefs.edit()
            .putBoolean(KEY_HAPTICS, value.hapticsEnabled)
            .putBoolean(KEY_VOICE, value.voiceRepliesEnabled)
            .putBoolean(KEY_COMPACT, value.compactDashboard)
            .putFloat(KEY_FONT_SCALE, value.fontScale.coerceIn(0.85f, 1.20f))
            .apply()
    }

    companion object {
        private const val KEY_HAPTICS = "haptics_enabled"
        private const val KEY_VOICE = "voice_replies_enabled"
        private const val KEY_COMPACT = "compact_dashboard"
        private const val KEY_FONT_SCALE = "font_scale"
    }
}

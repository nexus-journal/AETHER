package com.aether.assistant

import android.content.Intent
import android.provider.Settings
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private val VoiceCyan = Color(0xFF62D9F5)
private val VoicePanel = Color(0xFF101F31)
private val VoiceRaised = Color(0xFF152940)
private val VoiceText = Color(0xFFEAF4FC)
private val VoiceMuted = Color(0xFF91A7BC)

@Composable
fun VoiceStudioCard(store: ExperiencePreferencesStore) {
    val context = LocalContext.current
    var settings by remember(store) { mutableStateOf(store.load()) }
    var engine by remember { mutableStateOf<TextToSpeech?>(null) }
    var engineReady by remember { mutableStateOf(false) }
    var previewStatus by remember { mutableStateOf("Voix fournie par le moteur de synthèse vocale Android.") }

    DisposableEffect(context) {
        val tts = TextToSpeech(context) { status ->
            engineReady = status == TextToSpeech.SUCCESS
            if (engineReady) engine?.let { AetherVoice.apply(it, settings) }
        }
        engine = tts
        onDispose {
            tts.stop()
            tts.shutdown()
            engine = null
            engineReady = false
        }
    }

    fun update(next: ExperiencePreferences) {
        settings = next
        store.save(next)
        engine?.let { AetherVoice.apply(it, next) }
    }

    Card(colors = CardDefaults.cardColors(containerColor = VoicePanel), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text("VOICE STUDIO", color = VoiceCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
            Text("La voix d'AETHER", color = VoiceText, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
            Text("Le profil JARVIS donne une diction plus posée et une tonalité légèrement plus grave. Le timbre exact dépend des voix françaises installées sur ton Samsung : AETHER ne clone pas la voix originale d'un acteur.", color = VoiceMuted, fontSize = 11.sp)

            Text("PROFIL VOCAL", color = VoiceCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                VoiceChoice("JARVIS", settings.voiceProfile == AetherVoice.PROFILE_JARVIS) {
                    val values = AetherVoice.applyPreset(AetherVoice.PROFILE_JARVIS)
                    update(settings.copy(voiceProfile = AetherVoice.PROFILE_JARVIS, speechRate = values.first, speechPitch = values.second, communicationStyle = AetherVoice.STYLE_JARVIS))
                }
                VoiceChoice("Naturel", settings.voiceProfile == AetherVoice.PROFILE_NATURAL) {
                    val values = AetherVoice.applyPreset(AetherVoice.PROFILE_NATURAL)
                    update(settings.copy(voiceProfile = AetherVoice.PROFILE_NATURAL, speechRate = values.first, speechPitch = values.second, communicationStyle = AetherVoice.STYLE_NATURAL))
                }
                VoiceChoice("Dynamique", settings.voiceProfile == AetherVoice.PROFILE_RAPID) {
                    val values = AetherVoice.applyPreset(AetherVoice.PROFILE_RAPID)
                    update(settings.copy(voiceProfile = AetherVoice.PROFILE_RAPID, speechRate = values.first, speechPitch = values.second))
                }
            }

            Text("Vitesse · ${String.format(Locale.FRANCE, "%.2f", settings.speechRate)}×", color = VoiceText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Slider(value = settings.speechRate, onValueChange = { update(settings.copy(speechRate = it)) }, valueRange = 0.75f..1.25f)
            Text("Hauteur · ${String.format(Locale.FRANCE, "%.2f", settings.speechPitch)}×", color = VoiceText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Slider(value = settings.speechPitch, onValueChange = { update(settings.copy(speechPitch = it)) }, valueRange = 0.75f..1.25f)

            Text("FAÇON DE PARLER", color = VoiceCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                VoiceChoice("JARVIS", settings.communicationStyle == AetherVoice.STYLE_JARVIS) {
                    update(settings.copy(communicationStyle = AetherVoice.STYLE_JARVIS))
                }
                VoiceChoice("Naturel", settings.communicationStyle == AetherVoice.STYLE_NATURAL) {
                    update(settings.copy(communicationStyle = AetherVoice.STYLE_NATURAL))
                }
                VoiceChoice("Technique", settings.communicationStyle == AetherVoice.STYLE_TECHNICAL) {
                    update(settings.copy(communicationStyle = AetherVoice.STYLE_TECHNICAL))
                }
            }

            Button(
                onClick = {
                    val tts = engine
                    if (tts != null && engineReady) {
                        AetherVoice.apply(tts, settings)
                        tts.speak("Bonjour. Systèmes opérationnels. Je suis prêt à vous assister.", TextToSpeech.QUEUE_FLUSH, null, "aether-voice-preview")
                        previewStatus = "Aperçu vocal lancé. Le résultat dépend du moteur et de la voix sélectionnés dans Android."
                    } else previewStatus = "Le moteur vocal n'est pas encore prêt. Vérifie la synthèse vocale Android."
                },
                modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.buttonColors(containerColor = VoiceCyan, contentColor = Color(0xFF07111F))
            ) { Text("Écouter un aperçu", fontWeight = FontWeight.Bold) }
            OutlinedButton(
                onClick = {
                    runCatching { context.startActivity(Intent("com.android.settings.TTS_SETTINGS")) }
                        .onFailure { runCatching { context.startActivity(Intent(Settings.ACTION_SETTINGS)) } }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Choisir la voix Android", color = VoiceCyan) }
            Text(previewStatus, color = VoiceMuted, fontSize = 10.sp)
            Text("Astuce : dans les réglages de synthèse vocale Samsung/Google, télécharge une voix française de bonne qualité, puis reviens ici pour écouter le profil JARVIS.", color = VoiceMuted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun VoiceChoice(label: String, selected: Boolean, onClick: () -> Unit) {
    Surface(
        color = if (selected) VoiceRaised else Color.Transparent,
        shape = RoundedCornerShape(50),
        modifier = Modifier.clickable(onClick = onClick)
    ) {
        Text(label, color = if (selected) VoiceCyan else VoiceMuted, fontSize = 10.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.padding(horizontal = 11.dp, vertical = 8.dp))
    }
}


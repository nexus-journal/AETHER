package com.aether.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val MorphBg = Color(0xFF07111F)
private val MorphPanel = Color(0xFF101F31)
private val MorphRaised = Color(0xFF152940)
private val MorphCyan = Color(0xFF62D9F5)
private val MorphText = Color(0xFFEAF4FC)
private val MorphMuted = Color(0xFF91A7BC)

@Composable
fun MorphScreen(modifier: Modifier = Modifier, store: MorphToolStore, onRunTool: (String) -> Unit) {
    val tools = remember(store) { mutableStateListOf<MorphTool>().apply { addAll(store.loadAll()) } }
    var showCreator by remember { mutableStateOf(false) }

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 13.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("MORPH · TOOL STUDIO", color = MorphCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.7.sp)
        Text("Tes outils, à ta façon.", color = MorphText, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
        Text("Crée des raccourcis personnels à partir des commandes AETHER. Ils restent sur cet appareil.", color = MorphMuted, fontSize = 12.sp)
        Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(17.dp)) {
            Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Text("COMMENT ÇA FONCTIONNE", color = MorphCyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
                Text("Donne un nom à un outil, puis associe-lui une commande AETHER. Un appui transmettra cette commande à l'assistant, qui te demandera confirmation avant toute action externe.", color = MorphText, fontSize = 12.sp)
                Text("MORPH crée ici des raccourcis configurables, pas du code Android arbitraire ni des modules autonomes.", color = MorphMuted, fontSize = 11.sp)
            }
        }
        Button(onClick = { showCreator = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = MorphCyan, contentColor = MorphBg), shape = RoundedCornerShape(14.dp)) {
            Text("+ Créer un outil", fontWeight = FontWeight.Bold)
        }
        if (tools.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(17.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Ton studio est prêt", color = MorphText, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                    Text("Exemples de commandes : « Cherche les actualités spatiales », « Ajoute une tâche réviser l'anglais » ou « Quelle heure est-il ? »", color = MorphMuted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                items(tools, key = { it.id }) { tool ->
                    Card(colors = CardDefaults.cardColors(containerColor = MorphPanel), shape = RoundedCornerShape(16.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                            Text(tool.name, color = MorphText, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                            Text(tool.command, color = MorphMuted, fontSize = 12.sp)
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Button(onClick = { onRunTool(tool.command) }, colors = ButtonDefaults.buttonColors(containerColor = MorphCyan, contentColor = MorphBg)) { Text("Lancer", fontSize = 11.sp) }
                                TextButton(onClick = { store.delete(tool.id); tools.removeAll { it.id == tool.id } }) { Text("Supprimer", color = Color(0xFFFF9B9B), fontSize = 11.sp) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showCreator) MorphToolDialog(
        onDismiss = { showCreator = false },
        onSave = { name, command ->
            store.add(name, command)
            tools.clear(); tools.addAll(store.loadAll())
            showCreator = false
        }
    )
}

@Composable
private fun MorphToolDialog(onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var command by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MorphPanel,
        title = { Text("Nouvel outil MORPH", color = MorphText) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(value = name, onValueChange = { name = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Nom de l'outil") }, placeholder = { Text("Briefing du matin") })
                OutlinedTextField(value = command, onValueChange = { command = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, maxLines = 5, label = { Text("Commande AETHER") }, placeholder = { Text("Cherche les dernières actualités scientifiques") })
            }
        },
        confirmButton = { TextButton(onClick = { onSave(name, command) }, enabled = name.isNotBlank() && command.isNotBlank()) { Text("Enregistrer", color = MorphCyan) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler", color = MorphMuted) } }
    )
}

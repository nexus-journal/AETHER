package com.aether.assistant

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.net.Uri
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.provider.Settings
import android.widget.Toast
import org.json.JSONArray
import org.json.JSONObject
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

/** Small, deterministic on-device command router. It does not pretend to be a generative AI model. */
object AssistantEngine {
    fun respond(raw: String, context: Context, memoryStore: MemoryStore, taskStore: TaskStore): AssistantReply {
        val input = raw.trim()
        if (input.isBlank()) return AssistantReply("Écris une demande ou utilise le bouton micro.")
        val normalized = normalize(input)

        val memoryPrefix = listOf("souviens toi que", "memorise que", "memorise", "note que")
            .firstOrNull { normalized.startsWith(it) }
        if (memoryPrefix != null) {
            val content = input.drop(memoryPrefix.length).trim().trimStart(':', ',', ' ')
            if (content.isBlank()) return AssistantReply("Que souhaites-tu que je mémorise ?")
            val now = System.currentTimeMillis()
            val title = content.take(54).let { if (content.length > 54) "$it…" else it }
            val current = memoryStore.loadAll().toMutableList()
            current.add(MemoryEntry(MemoryStore.newId(), title, content, "Ajout rapide", now, now))
            memoryStore.saveAll(current)
            return AssistantReply("C'est enregistré dans ta mémoire locale : « $title ». Tu peux le retrouver dans l'onglet Mémoire.")
        }

        if (normalized.startsWith("recherche dans ma memoire") || normalized.startsWith("qu est ce que tu sais sur")) {
            val query = if (normalized.startsWith("recherche dans ma memoire")) input.substringAfter("mémoire", input).trim() else input.substringAfter("sur", input).trim()
            val matches = memoryStore.loadAll().filter {
                it.title.contains(query, true) || it.content.contains(query, true) || it.category.contains(query, true)
            }.take(4)
            return if (matches.isEmpty()) AssistantReply("Je n'ai pas trouvé de souvenir correspondant. Essaie un autre terme dans l'onglet Mémoire.")
            else AssistantReply("Voici ce que j'ai retrouvé :\n" + matches.joinToString("\n\n") { "• ${it.title}\n${it.content.take(220)}" })
        }

        val addTaskPrefix = listOf("ajoute une tache", "ajouter une tache", "nouvelle tache", "tache", "rappelle moi de")
            .firstOrNull { normalized.startsWith(it) }
        if (addTaskPrefix != null) {
            val title = input.drop(addTaskPrefix.length).trim().trimStart(':', ',', ' ')
            if (title.isBlank()) return AssistantReply("Quelle tâche veux-tu ajouter ?")
            taskStore.add(title)
            val extra = if (normalized.startsWith("rappelle moi de")) " Je l'ai ajoutée à ta liste ; aucune alerte horaire n'est programmée automatiquement." else ""
            return AssistantReply("Tâche ajoutée : « $title ». Tu la retrouveras dans Assistant → Tâches.$extra")
        }

        if (normalized.contains("mes taches") || normalized == "liste taches" || normalized == "liste mes taches") {
            val active = taskStore.loadAll().filterNot { it.done }
            return if (active.isEmpty()) AssistantReply("Tu n'as aucune tâche en attente.")
            else AssistantReply("Tes tâches en attente :\n" + active.take(12).joinToString("\n") { "• ${it.title}" })
        }

        if (normalized in setOf("briefing", "briefing du jour", "bilan du jour", "fais mon briefing", "quoi de prevu", "qu est ce que j ai a faire", "resume ma journee")) {
            val allTasks = taskStore.loadAll()
            val pending = allTasks.filterNot { it.done }
            val completed = allTasks.count { it.done }
            val memories = memoryStore.loadAll()
            val now = SimpleDateFormat("EEEE d MMMM · HH:mm", Locale.FRANCE).format(Date())
            val taskSummary = if (pending.isEmpty()) "Aucune tâche en attente."
                else pending.take(6).joinToString("\n") { "• ${it.title}" } + if (pending.size > 6) "\n• et ${pending.size - 6} autre(s)" else ""
            val memorySummary = when {
                memories.isEmpty() -> "Aucun souvenir enregistré pour le moment."
                else -> "${memories.size} souvenir(s) enregistré(s), dont ${memories.count { it.favorite }} favori(s)."
            }
            return AssistantReply("BRIEFING PERSONNEL · $now\n\nÀ FAIRE (${pending.size})\n$taskSummary\n\nTERMINÉES · $completed\n$memorySummary\n\nJe peux aussi approfondir un sujet, retrouver un souvenir ou préparer un plan d'action.")
        }

        if (normalized.startsWith("termine la tache") || normalized.startsWith("termine tache")) {
            val needle = input.substringAfter("tâche", input.substringAfter("tache", "")).trim()
            val match = taskStore.loadAll().firstOrNull { !it.done && (needle.isBlank() || it.title.contains(needle, true)) }
            return if (match == null) AssistantReply("Je ne trouve pas cette tâche dans ta liste.")
            else {
                taskStore.setDone(match.id, true)
                AssistantReply("C'est noté : « ${match.title} » est terminée.")
            }
        }

        if (normalized.contains("quelle heure") || normalized == "heure") {
            return AssistantReply("Il est ${SimpleDateFormat("HH:mm", Locale.FRANCE).format(Date())}.")
        }
        if (normalized.contains("quelle date") || normalized.contains("quel jour") || normalized == "date") {
            return AssistantReply("Nous sommes le ${SimpleDateFormat("EEEE d MMMM yyyy", Locale.FRANCE).format(Date())}.")
        }
        if (normalized.contains("batterie") || normalized.contains("niveau de charge") || normalized.contains("etat du telephone") || normalized.contains("etat de mon telephone")) {
            val battery = runCatching {
                val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
                val percentage = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
                val charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL
                percentage to charging
            }.getOrNull()
            if (battery == null || battery.first !in 0..100) return AssistantReply("Je n'arrive pas à lire l'état de la batterie sur cet appareil.")
            val chargeText = if (battery.second) "en charge" else "sur batterie"
            return AssistantReply("La batterie est à ${battery.first} % ($chargeText). Android ${Build.VERSION.RELEASE}.")
        }
        if (normalized in listOf("bonjour", "salut", "hello", "bonsoir", "hey")) {
            return AssistantReply("Bonjour. Je suis prêt. Tu peux me demander de gérer ta mémoire, tes tâches ou de préparer une action sur ton téléphone.")
        }
        if (normalized in listOf("aide", "aide moi", "que peux tu faire", "que sais tu faire", "commandes")) {
            return AssistantReply(
                "Voici mes fonctions disponibles dans cette version :\n" +
                    "• Mémoriser une information : « Souviens-toi que… »\n" +
                    "• Ajouter une tâche : « Ajoute une tâche… »\n" +
                    "• Consulter les tâches : « Mes tâches »\n" +
                    "• Obtenir un briefing personnel : « Briefing du jour »\n" +
                    "• Vérifier la batterie : « Quel est le niveau de batterie ? »\n" +
                    "• Rechercher sur le Web : « Cherche… »\n" +
                    "• Ouvrir une application : YouTube, Spotify, Maps, Chrome, Appareil photo, Galerie, Gmail, WhatsApp, Messages, Calendrier ou Horloge\n" +
                    "• Ouvrir un itinéraire : « Itinéraire vers… »\n" +
                    "• Préparer une alarme : « Mets une alarme à 7h30 »\n" +
                    "• Préparer un appel : « Appelle 06… »\n" +
                    "• Préparer un SMS : « SMS 06… : ton message »\n" +
                    "• Préparer un événement : « Ajoute au calendrier… »\n" +
                    "Chaque action externe demande ta confirmation."
            )
        }

        if (normalized.startsWith("cherche ") || normalized.startsWith("recherche ") || normalized.startsWith("google ")) {
            val query = input.substringAfter(' ').trim()
            if (query.isBlank()) return AssistantReply("Que veux-tu rechercher ?")
            return AssistantReply("Je peux ouvrir une recherche Web pour : « $query ». Vérifie les sources et les dates des résultats.", AssistantAction("WEB", query))
        }

        if (normalized.startsWith("itineraire vers ") || normalized.startsWith("itineraire pour ") || normalized.startsWith("carte ") || normalized.startsWith("navigue vers ")) {
            val destination = input.substringAfter(' ').trim().let { if (normalize(it).startsWith("vers ")) it.drop(5) else if (normalize(it).startsWith("pour ")) it.drop(5) else it }
            if (destination.isBlank()) return AssistantReply("Quelle destination dois-je ouvrir dans la carte ?")
            return AssistantReply("Je vais ouvrir la carte pour « $destination ». Vérifie l'itinéraire avant de partir.", AssistantAction("MAP", destination))
        }

        if (normalized.contains("alarme") || normalized.startsWith("reveil ") || normalized.startsWith("reveille moi")) {
            val time = Regex("(\\d{1,2})(?:\\s*[h:]\\s*(\\d{1,2}))?").find(normalized)
            if (time != null) {
                val hour = time.groupValues[1].toIntOrNull()
                val minute = time.groupValues.getOrNull(2)?.toIntOrNull() ?: 0
                if (hour != null && hour in 0..23 && minute in 0..59) {
                    return AssistantReply("Je peux demander à l'application Horloge de régler une alarme à %02d:%02d. Confirme pour ouvrir Horloge.".format(hour, minute), AssistantAction("ALARM", hour.toString(), minute.toString()))
                }
            }
            return AssistantReply("Indique une heure au format 7h30 ou 07:30.")
        }

        if (normalized.startsWith("appelle ") || normalized.startsWith("telephone a ") || normalized.startsWith("telephoner a ")) {
            val number = Regex("[+0-9][0-9 .-]{5,}").find(input)?.value?.trim()
            if (number.isNullOrBlank()) return AssistantReply("Indique un numéro de téléphone. Je préparerai l'appel sans le lancer directement.")
            return AssistantReply("Je vais ouvrir le composeur avec le numéro $number. Tu gardes la main pour lancer ou annuler l'appel.", AssistantAction("DIAL", number))
        }

        if (normalized.startsWith("sms ") || normalized.startsWith("message ")) {
            val match = Regex("(?:sms|message)\\s+([+0-9][0-9 .-]{5,})\\s*[:,-]\\s*(.+)", RegexOption.IGNORE_CASE).find(input)
            if (match != null) {
                val number = match.groupValues[1].trim()
                val body = match.groupValues[2].trim()
                return AssistantReply("Je vais ouvrir un nouveau SMS adressé à $number avec ton texte prérempli. Rien ne sera envoyé sans ton action.", AssistantAction("SMS", number, body))
            }
            return AssistantReply("Utilise le format : SMS 0612345678 : ton message.")
        }

        if (normalized.startsWith("ajoute au calendrier") || normalized.startsWith("cree un evenement")) {
            val title = input.replace(Regex("(?i)^(ajoute au calendrier|cree un evenement|crée un événement)\\s*"), "").trim().ifBlank { "Événement AETHER" }
            val timeMatch = Regex("(?:a|vers)\\s+(\\d{1,2})[:h](\\d{2})").find(normalized)
                ?: return AssistantReply("Pour préparer cet événement, indique au moins une heure précise, par exemple : « Ajoute au calendrier rendez-vous demain à 14h30 ».")
            val hour = timeMatch.groupValues[1].toIntOrNull()
            val minute = timeMatch.groupValues[2].toIntOrNull()
            if (hour == null || hour !in 0..23 || minute == null || minute !in 0..59) return AssistantReply("L'heure indiquée n'est pas valide. Utilise par exemple 14h30.")
            val now = Calendar.getInstance()
            if (normalized.contains("apres demain")) now.add(Calendar.DAY_OF_YEAR, 2)
            else if (normalized.contains("demain")) now.add(Calendar.DAY_OF_YEAR, 1)
            now.set(Calendar.HOUR_OF_DAY, hour)
            now.set(Calendar.MINUTE, minute)
            now.set(Calendar.SECOND, 0)
            now.set(Calendar.MILLISECOND, 0)
            if (now.timeInMillis <= System.currentTimeMillis()) now.add(Calendar.DAY_OF_YEAR, 1)
            val begin = now.timeInMillis
            return AssistantReply("Je peux préparer l'événement « $title » dans ton calendrier, autour du ${SimpleDateFormat("dd/MM à HH:mm", Locale.FRANCE).format(Date(begin))}. Vérifie ou ajuste les détails avant l'enregistrement.", AssistantAction("CALENDAR", title, begin.toString()))
        }

        if (normalized.startsWith("ouvre ") || normalized.startsWith("lance ") || normalized.startsWith("demarre ")) {
            val target = normalized.substringAfter(' ').trim()
            val alias = when {
                target.startsWith("youtube") -> "youtube"
                target.startsWith("spotify") -> "spotify"
                target.startsWith("google maps") || target.startsWith("maps") || target.startsWith("carte") -> "maps"
                target.startsWith("chrome") || target.startsWith("navigateur") -> "chrome"
                target.startsWith("appareil photo") || target.startsWith("camera") || target.startsWith("caméra") -> "camera"
                target.startsWith("galerie") || target.startsWith("photos") -> "gallery"
                target.startsWith("gmail") || target.startsWith("mail") -> "gmail"
                target.startsWith("whatsapp") -> "whatsapp"
                target.startsWith("messages") || target.startsWith("sms") -> "messages"
                target.startsWith("calendrier") || target.startsWith("calendar") -> "calendar"
                target.startsWith("horloge") || target.startsWith("clock") || target.startsWith("alarme") -> "clock"
                target.startsWith("fichiers") || target.startsWith("mes fichiers") -> "files"
                target.startsWith("calculatrice") || target.startsWith("calculator") -> "calculator"
                else -> null
            }
            if (alias != null) return AssistantReply("Je peux ouvrir $alias sur ton téléphone. Confirme pour continuer.", AssistantAction("APP", alias))
        }

        if (normalized.startsWith("ouvre les parametres") || normalized.startsWith("ouvre parametres") || normalized == "parametres du telephone") {
            return AssistantReply("Je peux ouvrir les paramètres Android.", AssistantAction("SETTINGS"))
        }

        if (normalized.startsWith("partage ")) {
            val content = input.substringAfter(' ').trim()
            if (content.isBlank()) return AssistantReply("Que souhaites-tu partager ?")
            return AssistantReply("Je peux ouvrir le menu de partage Android avec ce texte.", AssistantAction("SHARE", content))
        }

        if (normalized.startsWith("ouvre https://") || normalized.startsWith("ouvre http://")) {
            val url = input.substringAfter(' ').trim()
            return AssistantReply("Je peux ouvrir cette adresse dans ton navigateur. Vérifie qu'elle est fiable.", AssistantAction("URL", url))
        }

        return AssistantReply(
            "Je n'ai pas de réponse locale fiable pour cette demande.",
            handled = false
        )
    }

    private fun normalize(value: String): String = Normalizer.normalize(value.lowercase(Locale.FRANCE), Normalizer.Form.NFD)
        .replace(Regex("\\p{Mn}+"), "")
        .replace(Regex("[^a-z0-9+:/ .-]"), " ")
        .replace("-", " ")
        .replace(Regex("\\s+"), " ").trim()
}

data class AssistantReply(val text: String, val action: AssistantAction? = null, val handled: Boolean = true, val planSteps: List<String> = emptyList())
data class AssistantAction(val kind: String, val first: String = "", val second: String = "")

data class TaskEntry(val id: String, val title: String, val createdAt: Long, val done: Boolean = false)

class TaskStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aether_tasks", Context.MODE_PRIVATE)

    fun loadAll(): List<TaskEntry> {
        return try {
            val array = JSONArray(prefs.getString("items", "[]"))
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.optJSONObject(i) ?: continue
                    val id = item.optString("id")
                    val title = item.optString("title")
                    if (id.isNotBlank() && title.isNotBlank()) add(TaskEntry(id, title, item.optLong("createdAt"), item.optBoolean("done")))
                }
            }.sortedWith(compareBy<TaskEntry> { it.done }.thenByDescending { it.createdAt })
        } catch (_: Exception) { emptyList() }
    }

    fun add(title: String) {
        val clean = title.trim().take(180)
        if (clean.isBlank()) return
        save(loadAll() + TaskEntry(UUID.randomUUID().toString(), clean, System.currentTimeMillis()))
    }

    fun setDone(id: String, done: Boolean) = save(loadAll().map { if (it.id == id) it.copy(done = done) else it })
    fun delete(id: String) = save(loadAll().filterNot { it.id == id })
    fun replaceAll(items: List<TaskEntry>) = save(items.take(500))

    private fun save(items: List<TaskEntry>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("id", it.id).put("title", it.title).put("createdAt", it.createdAt).put("done", it.done)) }
        prefs.edit().putString("items", array.toString()).apply()
    }
}

data class MorphTool(val id: String, val name: String, val command: String)

class MorphToolStore(context: Context) {
    private val prefs = context.applicationContext.getSharedPreferences("aether_morph_tools", Context.MODE_PRIVATE)
    fun loadAll(): List<MorphTool> = try {
        val array = JSONArray(prefs.getString("tools", "[]"))
        buildList {
            for (i in 0 until array.length()) {
                val item = array.optJSONObject(i) ?: continue
                val id = item.optString("id"); val name = item.optString("name"); val command = item.optString("command")
                if (id.isNotBlank() && name.isNotBlank() && command.isNotBlank()) add(MorphTool(id, name, command))
            }
        }
    } catch (_: Exception) { emptyList() }

    fun add(name: String, command: String) {
        val items = loadAll().toMutableList()
        items.add(0, MorphTool(UUID.randomUUID().toString(), name.trim().take(42), command.trim().take(300)))
        save(items.take(30))
    }
    fun delete(id: String) = save(loadAll().filterNot { it.id == id })
    fun replaceAll(items: List<MorphTool>) = save(items.take(30))
    private fun save(items: List<MorphTool>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("id", it.id).put("name", it.name).put("command", it.command)) }
        prefs.edit().putString("tools", array.toString()).apply()
    }
}

/** Execute only after the user taps the confirmation button in the chat. */
fun executeAssistantAction(context: Context, action: AssistantAction): Boolean {
    return try {
        val intent = when (action.kind) {
            "WEB" -> Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=${Uri.encode(action.first)}"))
            "MAP" -> Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=${Uri.encode(action.first)}"))
            "ALARM" -> Intent(AlarmClock.ACTION_SET_ALARM)
                .putExtra(AlarmClock.EXTRA_HOUR, action.first.toInt())
                .putExtra(AlarmClock.EXTRA_MINUTES, action.second.toInt())
                .putExtra(AlarmClock.EXTRA_MESSAGE, "AETHER")
                .putExtra(AlarmClock.EXTRA_SKIP_UI, false)
            "DIAL" -> Intent(Intent.ACTION_DIAL, Uri.parse("tel:${action.first.filter { it.isDigit() || it == '+' }}"))
            "SMS" -> Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${action.first.filter { it.isDigit() || it == '+' }}"))
                .putExtra("sms_body", action.second)
            "CALENDAR" -> {
                val begin = action.second.toLongOrNull() ?: System.currentTimeMillis()
                Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                    .putExtra(CalendarContract.Events.TITLE, action.first)
                    .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, begin)
                    .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, begin + 60 * 60 * 1000L)
            }
            "APP" -> {
                val packageNames = when (action.first.lowercase()) {
                    "youtube" -> listOf("com.google.android.youtube")
                    "spotify" -> listOf("com.spotify.music")
                    "maps" -> listOf("com.google.android.apps.maps")
                    "chrome" -> listOf("com.android.chrome")
                    "camera" -> listOf("com.sec.android.app.camera", "com.android.camera2")
                    "gallery" -> listOf("com.sec.android.gallery3d", "com.google.android.apps.photos")
                    "gmail" -> listOf("com.google.android.gm")
                    "whatsapp" -> listOf("com.whatsapp")
                    "messages" -> listOf("com.samsung.android.messaging", "com.google.android.apps.messaging")
                    "calendar" -> listOf("com.google.android.calendar", "com.samsung.android.calendar")
                    "clock" -> listOf("com.sec.android.app.clockpackage", "com.google.android.deskclock")
                    "files" -> listOf("com.sec.android.app.myfiles", "com.google.android.documentsui")
                    "calculator" -> listOf("com.sec.android.app.popupcalculator", "com.google.android.calculator")
                    else -> emptyList()
                }
                val launch = packageNames.firstNotNullOfOrNull { context.packageManager.getLaunchIntentForPackage(it) }
                if (launch == null) {
                    Toast.makeText(context, "Cette application n'est pas installée ou n'est pas accessible.", Toast.LENGTH_LONG).show()
                    return false
                }
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launch)
                return true
            }
            "SETTINGS" -> Intent(Settings.ACTION_SETTINGS)
            "SHARE" -> Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, action.first)
            "URL" -> Intent(Intent.ACTION_VIEW, Uri.parse(action.first))
            else -> null
        }
        if (intent == null) {
            Toast.makeText(context, "Action non reconnue.", Toast.LENGTH_SHORT).show()
            false
        } else {
            val launchIntent = if (action.kind == "SHARE") Intent.createChooser(intent, "Partager avec…") else intent
            context.startActivity(launchIntent)
            true
        }
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(context, "Aucune application compatible n'a été trouvée.", Toast.LENGTH_LONG).show()
        false
    } catch (_: Exception) {
        Toast.makeText(context, "Impossible d'ouvrir cette action sur cet appareil.", Toast.LENGTH_LONG).show()
        false
    }
}

package com.aether.assistant

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Validates a complete AETHER backup before replacing any local collection. API credentials are never imported. */
object BackupImporter {
    data class Preview(
        val memories: Int,
        val tasks: Int,
        val morphTools: Int,
        val morphRoutines: Int,
        val conversations: Int
    )

    data class ParsedBackup(
        val memories: List<MemoryEntry>,
        val tasks: List<TaskEntry>,
        val morphTools: List<MorphTool>,
        val morphRoutines: List<MorphRoutine>,
        val conversations: List<ConversationEntry>
    ) {
        fun preview() = Preview(memories.size, tasks.size, morphTools.size, morphRoutines.size, conversations.size)
    }

    fun parse(raw: String): ParsedBackup {
        require(raw.isNotBlank() && raw.length <= MAX_BACKUP_CHARS) { "Le fichier est vide ou trop volumineux." }
        val root = JSONObject(raw)
        require(root.optString("format") == "AETHER_LOCAL_BACKUP") { "Ce fichier n'est pas une sauvegarde AETHER reconnue." }
        val version = root.optInt("schemaVersion", -1)
        require(version in 1..CURRENT_SCHEMA) { "Version de sauvegarde non prise en charge." }
        val requiredCollections = listOf("memories", "tasks", "morphTools", "morphRoutines", "conversation")
        require(requiredCollections.all { root.optJSONArray(it) != null }) { "La sauvegarde est incomplète ou endommagée." }

        val memories = parseArray(root.optJSONArray("memories"), MAX_MEMORIES) { item, index ->
            val title = item.optString("title").trim().take(120)
            val content = item.optString("content").trim().take(6000)
            if (title.isBlank() || content.isBlank()) return@parseArray null
            MemoryEntry(
                id = safeId(item.optString("id"), index), title = title, content = content,
                category = item.optString("category", "Général").trim().take(60).ifBlank { "Général" },
                createdAt = item.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = item.optLong("updatedAt", System.currentTimeMillis()),
                favorite = item.optBoolean("favorite", false)
            )
        }
        val tasks = parseArray(root.optJSONArray("tasks"), MAX_TASKS) { item, index ->
            val title = item.optString("title").trim().take(180)
            if (title.isBlank()) null else TaskEntry(safeId(item.optString("id"), index), title,
                item.optLong("createdAt", System.currentTimeMillis()), item.optBoolean("done", false))
        }
        val tools = parseArray(root.optJSONArray("morphTools"), MAX_TOOLS) { item, index ->
            val name = item.optString("name").trim().take(42)
            val command = item.optString("command").trim().take(300)
            if (name.isBlank() || command.isBlank()) null else MorphTool(safeId(item.optString("id"), index), name, command)
        }
        val routines = parseArray(root.optJSONArray("morphRoutines"), MAX_ROUTINES) { item, index ->
            val name = item.optString("name").trim().take(48)
            val rawSteps = item.optJSONArray("steps") ?: JSONArray()
            val steps = buildList {
                for (stepIndex in 0 until minOf(rawSteps.length(), 8)) {
                    val step = rawSteps.optString(stepIndex).trim().take(300)
                    if (step.isNotBlank()) add(step)
                }
            }
            if (name.isBlank() || steps.size !in 2..8) null
            else MorphRoutine(safeId(item.optString("id"), index), name, steps, item.optLong("updatedAt", System.currentTimeMillis()))
        }
        val conversations = parseArray(root.optJSONArray("conversation"), MAX_CONVERSATIONS) { item, _ ->
            val role = item.optString("role")
            val text = item.optString("text").trim().take(5000)
            if (role !in setOf("user", "model") || text.isBlank()) null
            else ConversationEntry(role, text, item.optLong("timestamp", System.currentTimeMillis()))
        }
        return ParsedBackup(memories, tasks, tools, routines, conversations)
    }

    fun restore(raw: String, memoryStore: MemoryStore, taskStore: TaskStore,
                morphToolStore: MorphToolStore, routineStore: MorphRoutineStore,
                conversationStore: ConversationStore): Preview {
        // Parse and validate all collections before writing anything.
        val parsed = parse(raw)
        memoryStore.saveAll(parsed.memories)
        taskStore.replaceAll(parsed.tasks)
        morphToolStore.replaceAll(parsed.morphTools)
        routineStore.replaceAll(parsed.morphRoutines)
        conversationStore.replaceAll(parsed.conversations)
        return parsed.preview()
    }

    private inline fun <T> parseArray(array: JSONArray?, maximum: Int, transform: (JSONObject, Int) -> T?): List<T> {
        val source = array ?: JSONArray()
        require(source.length() <= maximum) { "La sauvegarde contient trop d'éléments dans une catégorie." }
        return buildList {
            for (index in 0 until source.length()) {
                val item = source.optJSONObject(index) ?: continue
                transform(item, index)?.let(::add)
            }
        }
    }

    private fun safeId(raw: String, index: Int): String = raw.trim().take(80).ifBlank { "restored-${index}-${UUID.randomUUID()}" }

    private const val CURRENT_SCHEMA = 1
    private const val MAX_BACKUP_CHARS = 5_000_000
    private const val MAX_MEMORIES = 500
    private const val MAX_TASKS = 500
    private const val MAX_TOOLS = 30
    private const val MAX_ROUTINES = 30
    private const val MAX_CONVERSATIONS = 80
}

package com.aether.assistant

import android.speech.tts.TextToSpeech
import java.util.Locale

/** Voice profiles tune the Android TTS engine; the actual timbre depends on installed system voices. */
object AetherVoice {
    const val PROFILE_JARVIS = "JARVIS"
    const val PROFILE_NATURAL = "NATUREL"
    const val PROFILE_RAPID = "DYNAMIQUE"

    const val STYLE_JARVIS = "JARVIS"
    const val STYLE_NATURAL = "NATUREL"
    const val STYLE_TECHNICAL = "TECHNIQUE"

    const val JARVIS_RATE = 0.90f
    const val JARVIS_PITCH = 0.88f

    fun apply(engine: TextToSpeech, settings: ExperiencePreferences) {
        runCatching {
            engine.language = Locale.FRANCE
            engine.setSpeechRate(settings.speechRate.coerceIn(0.75f, 1.25f))
            engine.setPitch(settings.speechPitch.coerceIn(0.75f, 1.25f))
        }
    }

    fun cleanForSpeech(value: String): String = value
        .replace(Regex("```[\\s\\S]*?```"), "bloc de code omis")
        .replace(Regex("\\[([^]]+)]\\([^)]*\\)"), "$1")
        .replace(Regex("https?://\\S+"), "lien")
        .replace(Regex("[*_#`>]"), "")
        .replace(Regex("\\s+"), " ")
        .trim()
        .take(1800)

    fun applyPreset(profile: String): Pair<Float, Float> = when (profile) {
        PROFILE_NATURAL -> 1.0f to 1.0f
        PROFILE_RAPID -> 1.08f to 1.02f
        else -> JARVIS_RATE to JARVIS_PITCH
    }

    fun styleInstruction(style: String): String = when (style) {
        STYLE_NATURAL -> "Style de communication : naturel, chaleureux sans familiarité excessive, direct et facile à comprendre."
        STYLE_TECHNICAL -> "Style de communication : analytique et technique, précis, structuré, avec les détails utiles et les limites clairement indiquées."
        else -> "Style de communication : assistant de bord haut de gamme inspiré des interfaces de science-fiction, calme, posé, courtois, très précis et légèrement élégant. Privilégie les réponses claires et efficaces, avec une touche d'esprit discrète si le contexte s'y prête. Ne copie pas des répliques de films et ne prétends pas être un personnage fictif."
    }
}

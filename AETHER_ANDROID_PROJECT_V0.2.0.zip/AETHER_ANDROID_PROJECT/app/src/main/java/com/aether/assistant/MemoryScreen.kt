package com.aether.assistant

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun MemoryScreen(store: MemoryStore, modifier: Modifier = Modifier) {
    var memories by remember { mutableStateOf(store.getAll()) }
    var query by remember { mutableStateOf("") }
    var showEditor by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<MemoryItem?>(null) }
    var pendingDelete by remember { mutableStateOf<MemoryItem?>(null) }

    val visible = memories.filter {
        query.isBlank() || it.title.contains(query, true) || it.content.contains(query, true) || it.category.contains(query, true)
    }

    Column(modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 14.dp)) {
        Text("MÉMOIRE CENTRALE", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(5.dp))
        Text("Une mémoire privée, stockée sur cet appareil.", color = Muted, fontSize = 13.sp)
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("Rechercher") },
                shape = RoundedCornerShape(14.dp)
            )
            Button(
                onClick = { editing = null; showEditor = true },
                colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night),
                modifier = Modifier.padding(top = 6.dp)
            ) { Text("＋") }
        }
        Spacer(Modifier.height(14.dp))
        Text("${memories.size} information(s) enregistrée(s)", color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(8.dp))
        if (visible.isEmpty()) {
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                    Text(if (memories.isEmpty()) "Ta mémoire est encore vide." else "Aucun résultat.", color = MainText, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(5.dp))
                    Text(if (memories.isEmpty()) "Ajoute une première information avec le bouton +." else "Essaie un autre mot-clé.", color = Muted, fontSize = 12.sp)
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(visible, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { editing = item; showEditor = true },
                        colors = CardDefaults.cardColors(containerColor = Panel),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Column(Modifier.padding(15.dp)) {
                            Text(item.category.uppercase(), color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(item.title, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                            Spacer(Modifier.height(5.dp))
                            Text(item.content, color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(8.dp))
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                TextButton(onClick = { editing = item; showEditor = true }) { Text("Modifier", color = Cyan) }
                                TextButton(onClick = { pendingDelete = item }) { Text("Supprimer", color = Color(0xFFFF8D8D)) }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showEditor) {
        MemoryEditorDialog(
            initial = editing,
            onDismiss = { showEditor = false },
            onSave = { title, content, category ->
                store.save(editing?.id, title, content, category)
                memories = store.getAll()
                showEditor = false
            }
        )
    }
    pendingDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Supprimer cette information ?") },
            text = { Text("« ${item.title} » sera supprimée de la mémoire locale.") },
            confirmButton = {
                TextButton(onClick = {
                    store.delete(item.id)
                    memories = store.getAll()
                    pendingDelete = null
                }) { Text("Supprimer", color = Color(0xFFFF8D8D)) }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Annuler") } }
        )
    }
}

@Composable
private fun MemoryEditorDialog(
    initial: MemoryItem?,
    onDismiss: () -> Unit,
    onSave: (String, String, String) -> Unit
) {
    var title by remember(initial?.id) { mutableStateOf(initial?.title.orEmpty()) }
    var content by remember(initial?.id) { mutableStateOf(initial?.content.orEmpty()) }
    var category by remember(initial?.id) { mutableStateOf(initial?.category ?: "Général") }
    val valid = title.isNotBlank() && content.isNotBlank()

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "Nouvelle information" else "Modifier l'information") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Titre") }, singleLine = true)
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("Information à retenir") }, minLines = 3)
                OutlinedTextField(value = category, onValueChange = { category = it }, label = { Text("Catégorie") }, singleLine = true)
                Text("Enregistré uniquement dans le stockage privé de l'application.", color = Muted, fontSize = 10.sp)
            }
        },
        confirmButton = {
            TextButton(enabled = valid, onClick = { onSave(title, content, category) }) { Text("Enregistrer", color = Cyan) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

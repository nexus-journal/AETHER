package com.aether.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Night = Color(0xFF07111F)
private val Panel = Color(0xFF101F31)
private val PanelRaised = Color(0xFF152940)
private val Cyan = Color(0xFF62D9F5)
private val Muted = Color(0xFF91A7BC)
private val MainText = Color(0xFFEAF4FC)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                primary = Cyan,
                onPrimary = Night,
                background = Night,
                surface = Panel,
                onSurface = MainText,
                secondary = Color(0xFF8BA9C7)
            )) {
                AetherApp()
            }
        }
    }
}

private data class AetherModule(
    val name: String,
    val tagline: String,
    val state: String,
    val mark: String
)

private val modules = listOf(
    AetherModule("MORPH", "Créer et façonner des outils", "STUDIO", "M"),
    AetherModule("Mémoire centrale", "Organiser les informations utiles", "LOCAL", "M"),
    AetherModule("Truth Engine", "Vérifier les faits et les sources", "PRÉVU", "T"),
    AetherModule("Vision", "Comprendre les images et documents", "PRÉVU", "V"),
    AetherModule("Autopilot", "Préparer des actions avec validation", "PRÉVU", "A")
)

@Composable
private fun AetherApp() {
    var selectedTab by remember { mutableIntStateOf(0) }
    val context = LocalContext.current
    val memoryStore = remember { MemoryStore(context.applicationContext) }
    var assistantMessage by remember { mutableStateOf("Je suis prêt. Que souhaites-tu explorer ?") }

    Scaffold(
        containerColor = Night,
        bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = MainText) {
                val labels = listOf("Accueil", "Mémoire", "Modules", "Laboratoire", "Réglages")
                val marks = listOf("⌂", "▤", "◇", "✳", "⚙")
                labels.forEachIndexed { index, label ->
                    NavigationBarItem(
                        selected = selectedTab == index,
                        onClick = { selectedTab = index },
                        icon = { Text(marks[index], fontSize = 19.sp) },
                        label = { Text(label, fontSize = 10.sp, maxLines = 1) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Cyan,
                            selectedTextColor = Cyan,
                            indicatorColor = PanelRaised,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted
                        )
                    )
                }
            }
        }
    ) { innerPadding ->
        when (selectedTab) {
            0 -> HomeScreen(
                modifier = Modifier.padding(innerPadding),
                assistantMessage = assistantMessage,
                onQuickAction = { assistantMessage = it }
            )
            1 -> MemoryScreen(memoryStore, Modifier.padding(innerPadding))
            2 -> ModulesScreen(Modifier.padding(innerPadding))
            3 -> LabScreen(Modifier.padding(innerPadding))
            else -> SettingsScreen(Modifier.padding(innerPadding))
        }
    }
}

@Composable
private fun HomeScreen(
    modifier: Modifier = Modifier,
    assistantMessage: String,
    onQuickAction: (String) -> Unit
) {
    LazyColumn(
        modifier = modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Spacer(Modifier.height(12.dp))
            Header()
        }
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Panel)
            ) {
                Column(Modifier.padding(20.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier.size(10.dp).background(Cyan, CircleShape)
                        )
                        Spacer(Modifier.width(9.dp))
                        Text("SYSTÈME INITIALISÉ", color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
                    }
                    Spacer(Modifier.height(18.dp))
                    Text("Bonjour.", color = MainText, fontSize = 29.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(6.dp))
                    Text("AETHER est ton espace d'assistance personnel.", color = Muted, fontSize = 14.sp)
                    Spacer(Modifier.height(18.dp))
                    Surface(color = PanelRaised, shape = RoundedCornerShape(16.dp)) {
                        Text(assistantMessage, modifier = Modifier.fillMaxWidth().padding(14.dp), color = MainText, fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(16.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = { onQuickAction("Interface de conversation : prochaine étape de développement.") },
                            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Night)
                        ) { Text("Démarrer") }
                        OutlinedButton(onClick = { onQuickAction("MORPH est le studio intégré de création d'outils.") }) {
                            Text("Ouvrir MORPH", color = Cyan)
                        }
                    }
                }
            }
        }
        item { SectionTitle("CAPACITÉS EN CONSTRUCTION", "Une architecture modulaire, pensée pour évoluer") }
        items(modules.take(3)) { module -> ModuleCard(module) }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = PanelRaised), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("PRINCIPE FONDATEUR", color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.3.sp)
                    Spacer(Modifier.height(8.dp))
                    Text("Utile, transparent et sous ton contrôle.", color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
                    Spacer(Modifier.height(5.dp))
                    Text("Les actions sensibles demanderont une validation. Les capacités marquées « prévu » ne sont pas encore actives.", color = Muted, fontSize = 13.sp)
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }
}

@Composable
private fun Header() {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("AETHER", color = MainText, fontSize = 25.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("PERSONAL INTELLIGENCE", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp)
        }
        Surface(color = PanelRaised, shape = RoundedCornerShape(50)) {
            Text("V0.2.0", modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp), color = Cyan, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String) {
    Column {
        Text(title, color = Cyan, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.5.sp)
        Spacer(Modifier.height(5.dp))
        Text(subtitle, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun ModuleCard(module: AetherModule) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp), modifier = Modifier.size(42.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Text(module.mark, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 18.sp)
                }
            }
            Spacer(Modifier.width(13.dp))
            Column(Modifier.weight(1f)) {
                Text(module.name, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                Text(module.tagline, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Text(module.state, color = Cyan, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp)
        }
    }
}

@Composable
private fun ModulesScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header()
        Spacer(Modifier.height(4.dp))
        SectionTitle("MODULES", "Les briques qui composeront AETHER")
        modules.forEach { ModuleCard(it) }
    }
}

@Composable
private fun LabScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header()
        Spacer(Modifier.height(4.dp))
        SectionTitle("MORPH STUDIO", "Le laboratoire intégré de création")
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("Donner forme à une idée", color = MainText, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                Text("MORPH deviendra l'espace où décrire un besoin, concevoir un outil, puis le tester avant de l'ajouter à AETHER.", color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(14.dp))
                Surface(color = PanelRaised, shape = RoundedCornerShape(12.dp)) {
                    Text("Studio de démonstration — génération réelle d'outils non activée dans cette version.", modifier = Modifier.padding(14.dp), color = Cyan, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(modifier: Modifier = Modifier) {
    Column(modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Header()
        Spacer(Modifier.height(4.dp))
        SectionTitle("RÉGLAGES", "Contrôle et transparence")
        InfoRow("Confidentialité", "Les fonctions connectées seront optionnelles")
        InfoRow("Automatisations", "Validation avant toute action sensible")
        InfoRow("Version", "AETHER 0.2.0 — mémoire locale active")
        InfoRow("État du projet", "Base technique initiale")
    }
}

@Composable
private fun InfoRow(title: String, detail: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp)) {
            Text(title, color = MainText, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Spacer(Modifier.height(4.dp))
            Text(detail, color = Muted, fontSize = 12.sp)
        }
    }
}

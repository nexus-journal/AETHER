package com.aether.assistant

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/** Local-only persistent memory. Data stays in the app's private SharedPreferences. */
class MemoryStore(context: Context) {
    private val preferences = context.getSharedPreferences("aether_memory", Context.MODE_PRIVATE)

    @Synchronized
    fun getAll(): List<MemoryItem> {
        val raw = preferences.getString(KEY_ITEMS, "[]") ?: "[]"
        return try {
            val array = JSONArray(raw)
            buildList {
                for (index in 0 until array.length()) {
                    val item = array.optJSONObject(index) ?: continue
                    add(
                        MemoryItem(
                            id = item.optString("id"),
                            title = item.optString("title"),
                            content = item.optString("content"),
                            category = item.optString("category", "Général"),
                            updatedAt = item.optLong("updatedAt")
                        )
                    )
                }
            }.filter { it.id.isNotBlank() && it.title.isNotBlank() && it.content.isNotBlank() }
                .sortedByDescending { it.updatedAt }
        } catch (_: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(id: String?, title: String, content: String, category: String) {
        val items = getAll().toMutableList()
        val item = MemoryItem(
            id = id ?: UUID.randomUUID().toString(),
            title = title.trim(),
            content = content.trim(),
            category = category.trim().ifBlank { "Général" },
            updatedAt = System.currentTimeMillis()
        )
        val existing = items.indexOfFirst { it.id == item.id }
        if (existing >= 0) items[existing] = item else items.add(item)
        persist(items)
    }

    @Synchronized
    fun delete(id: String) {
        persist(getAll().filterNot { it.id == id })
    }

    @Synchronized
    fun clear() = persist(emptyList())

    private fun persist(items: List<MemoryItem>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("content", item.content)
                put("category", item.category)
                put("updatedAt", item.updatedAt)
            })
        }
        preferences.edit().putString(KEY_ITEMS, array.toString()).apply()
    }

    private companion object { const val KEY_ITEMS = "items_json" }
}

data class MemoryItem(
    val id: String,
    val title: String,
    val content: String,
    val category: String,
    val updatedAt: Long
)
